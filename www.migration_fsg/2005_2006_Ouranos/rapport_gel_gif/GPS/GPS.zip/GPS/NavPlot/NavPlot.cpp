/***********************************************************************
 *
 *  CANADIAN MARCONI COMPANY
 *
 *  Copyright (c) 1997 Canadian Marconi Company.  All rights reserved.
 *  May be used only in accordance with a valid Source Code License
 *  Agreement with CMC.
 *
 *  COMPONENT: NavPlot.cpp
 *
 *  Purpose:   Contain Graphic functions used to plot the position
 *                                                                            
 * $Workfile: NavPlot.cpp $, $  $
 *
 * $Author: Coopoem $,  $
 *
 * $Modtime: 6/22/99 10:35a $             
 *
 * $Log: /GPS/Allstar/Code/Utilities/ProjetASV/NavPlot.cpp $                 
 * 
 * 1     8/06/99 12:49p Coopoem
 * Projet ASV, premiere version archive dans Source Safe. Les classes
 * ASVWnd, OperatingUnit et ScriptParser sont assez avancees. Script
 * Parser operationnel pour un premier set de commande (test�).
 * 
 * 6     4/26/99 8:02p Stlevesq
 * Change Navigation state color
 * Fix bug in calculus for X and Y Coor in UpdateNavPlotData function
 * 
 * 5     2/23/99 9:41a Stlevesq
 * Show current position point in black (INVALID_NAV_MODE)
 * 
 * 4     12/22/98 3:22p Stlevesq
 * Implementation of navigation plot window.
 * 
 * 3     12/02/97 5:02p Stlevesq
 * Remove compilation warnings ( use temporary variables)
 * 
 * 2     9/08/97 5:31p Sdortun
 * Input serial port Bugged fixed in mainfrm.cpp
 * In Timer function , comment RTS/CTS flow control
 * 
 * 1     9/03/97 4:03p Sdortun
 * Nav plot window frame added to toolbar and config
 * 
 ***********************************************************************/
#pragma warning( disable:4005)
/*-----------------------------------------------------------------------
 *                    * * * * *  INCLUDES  * * * * *                     
 *----------------------------------------------------------------------*/

#include <math.h>
#include "stdafx.h"
#include "NavPlot.h"
#include "mainfrm.h"
#include "CMCType.h"
#include "config.h"
#include "resource.h"

/*------------------------------------------------------------------------
 *                    * * * * *  DEFINITIONS  * * * * *                  
 *----------------------------------------------------------------------*/

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

#define PI           3.1415926535897932
#define EARTH_RADIUS 6378160            // meters

#define MOUSELEFT    1
#define MOUSETOP     1

#define LEFTBORDER   15
#define TOPBORDER    15

/*------------------------------------------------------------------------  
 *                 * * * * *  STRUCTURES & CLASSES  * * * * *             
 *----------------------------------------------------------------------*/
extern TConfiguration Config;

typedef struct{
   BYTE r;
   BYTE g;
   BYTE b;
} RgB;

IMPLEMENT_DYNCREATE(CNavPlotWnd, CFrameWnd)


/********************************************************************************
 *
 * NAME:            DrawCircles
 *
 * DESCRIPTION:     Draw 3 circles: one with the biggest radius that the window
 *                                  can display, one with the radius divided by 2  
 *                                  and a last one with the radius divided by 10. 
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::DrawCircles(void)
{
   CRect     Rect; 
   CClientDC DC(this);
   CPen      Pen(PS_SOLID,1,RGB(0,0,0));    // Black color
	CPen     *OldPen=DC.SelectObject(&Pen);
   int       iVerticalRadius, iHorizontalRadius;
   char      aString[80];
   double    dZoom;
   int       iRadius;

   GetClientRect(&Rect);
 	DC.SelectObject(m_Font);

   iVerticalRadius   = (Rect.right  - Rect.left) / 2;
   iHorizontalRadius = (Rect.bottom - Rect.top)  / 2;

   if(iVerticalRadius < iHorizontalRadius)
        m_iBiggestRadius = iVerticalRadius   - 20; // 20 is substract to have some space to write
   else m_iBiggestRadius = iHorizontalRadius - 20;

   // Draw the biggest circle
   Rect.left   = m_iWindowXCenter - m_iBiggestRadius;
   Rect.top    = m_iWindowYCenter - m_iBiggestRadius; 
   Rect.right  = m_iWindowXCenter + m_iBiggestRadius;
   Rect.bottom = m_iWindowYCenter + m_iBiggestRadius;
   DC.Ellipse(Rect);
   
   // display the radius value for this circle 
   sprintf(aString,"%dm", m_iZoomValue);
   DC.TextOut(m_iWindowXCenter, m_iWindowYCenter + m_iBiggestRadius, aString);

   // Draw the middle circle
   iRadius     = (int)(m_iBiggestRadius / 2);
   Rect.left   = m_iWindowXCenter - iRadius;
   Rect.top    = m_iWindowYCenter - iRadius;
   Rect.right  = m_iWindowXCenter + iRadius;
   Rect.bottom = m_iWindowYCenter + iRadius;
   DC.Ellipse(Rect);

   // display the radius value for this circle 
   dZoom = (double)m_iZoomValue / 2;
   if(dZoom < 1){
      sprintf(aString,"%1.1fm", dZoom); 
   }
   else{
      sprintf(aString,"%dm", (int)dZoom); 
   }
   DC.TextOut(m_iWindowXCenter, m_iWindowYCenter + (m_iBiggestRadius / 2), aString);
   
   // Draw the smallest circle
   iRadius     = (int)(m_iBiggestRadius / 10);
   Rect.left   = m_iWindowXCenter - iRadius;
   Rect.top    = m_iWindowYCenter - iRadius;
   Rect.right  = m_iWindowXCenter + iRadius;
   Rect.bottom = m_iWindowYCenter + iRadius;
   DC.Ellipse(Rect);

   // display the radius value for this circle 
   dZoom = (double)m_iZoomValue / 10;
   if(dZoom < 1){
      sprintf(aString,"%1.1fm", dZoom); 
   }
   else{
      sprintf(aString,"%dm", (int)dZoom); 
   }
   DC.TextOut(m_iWindowXCenter, m_iWindowYCenter + (m_iBiggestRadius /10), aString);

	DC.SelectObject(OldPen);
}

/********************************************************************************
 *
 * NAME:            DrawGrid
 *
 * DESCRIPTION:     Draw or hide grid.     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::DrawGrid(BOOLEAN bVisible){
   CClientDC DC(this);
   
   CPen      BlackPen(PS_DOT,1,RGB(0,0,0));          
   CPen      WhitePen(PS_DOT,1,RGB(255,255,255));
	CPen     *OldPen;

   CRect     Rect; 

   if(bVisible) OldPen = DC.SelectObject(&BlackPen);
   else         OldPen = DC.SelectObject(&WhitePen);

   GetClientRect(&Rect);

   // Draw 5 vertical lines (-1 is only there to clear circles)
   DC.MoveTo(m_iWindowXCenter - m_iBiggestRadius - 1,      Rect.top);
   DC.LineTo(m_iWindowXCenter - m_iBiggestRadius - 1,      Rect.bottom);

   DC.MoveTo(m_iWindowXCenter - m_iBiggestRadius / 2 - 1,  Rect.top);
   DC.LineTo(m_iWindowXCenter - m_iBiggestRadius / 2 - 1,  Rect.bottom);

   DC.MoveTo(m_iWindowXCenter - 1 ,                        Rect.top);
   DC.LineTo(m_iWindowXCenter - 1,                         Rect.bottom);

   DC.MoveTo(m_iWindowXCenter + m_iBiggestRadius / 2,      Rect.top);
   DC.LineTo(m_iWindowXCenter + m_iBiggestRadius / 2,      Rect.bottom);

   DC.MoveTo(m_iWindowXCenter + m_iBiggestRadius,          Rect.top);
   DC.LineTo(m_iWindowXCenter + m_iBiggestRadius,          Rect.bottom);

   // Draw 5 horizontal lines (-1 is only there to clear circles) 
   DC.MoveTo(Rect.left,  m_iWindowYCenter - m_iBiggestRadius - 1);
   DC.LineTo(Rect.right, m_iWindowYCenter - m_iBiggestRadius - 1);

   DC.MoveTo(Rect.left,  m_iWindowYCenter - m_iBiggestRadius / 2 - 1);
   DC.LineTo(Rect.right, m_iWindowYCenter - m_iBiggestRadius / 2 - 1);

   DC.MoveTo(Rect.left,  m_iWindowYCenter - 1);
   DC.LineTo(Rect.right, m_iWindowYCenter - 1);

   DC.MoveTo(Rect.left,  m_iWindowYCenter + m_iBiggestRadius / 2);
   DC.LineTo(Rect.right, m_iWindowYCenter + m_iBiggestRadius / 2);

   DC.MoveTo(Rect.left,  m_iWindowYCenter + m_iBiggestRadius);
   DC.LineTo(Rect.right, m_iWindowYCenter + m_iBiggestRadius);

	DC.SelectObject(OldPen);
}

/********************************************************************************
 *
 * NAME:            DrawDot
 *
 * DESCRIPTION:     Draw a dot or a plus sign at the position received in 
 *                  parameters.  The color of the dot or the plus sign is chosen
 *                  by the navigation mode.
 *
 *                  Note: Coordinates are in pixel value and they will be drawing
 *                        with a center window offset.
 *
 * ATTRIBUTES USED:
 *    inputs:       iXCoor,
 *                  iYCoor,
 *                  m_iWindowXCenter, 
 *                  m_iWindowYCenter,
 *                  m_iDotSize
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::DrawDot(int                       iXCoor, 
                          int                       iYCoor, 
                          DEFMSG_ENUM_NAV_MODE_TYPE eNavMode)
{
   CClientDC DC(this);
   CRect     Rect; 

   // Red         255, 0,   0
   // Grey        255, 128, 128
   // Purple      200, 0,   128
   // Blue        64,  64,  255
   // Turquoise   0,   255, 255
   // Black       0,   0,   0
   // Green       0,   255, 0
   // Dark Blue   0,   0,   255

   RgB NavModeColor[] =
   {{255,0,   0},    // INIT_REQUIRED  = 0   
   {255, 128, 128},  // INITIALIZED    = 1   
   {64,  64,  255},  // NAV_3D         = 2   
   {200, 0,   128},  // ALT_HOLD_2D    = 3   
   {0,   255, 255},  // DIFF_3D        = 4   
   {0,   0,   255},  // DIFF_2D        = 5   
   {200, 0,   128},  // DED_RECKONING  = 6   
   {0,   0,   0  },  // INVALID_MODE   = 7   
   {0,   255, 0  },  // BASESTATION    = 8   
   {0,   0,   255},  // CODE_NAV       = 9   
   {128, 128, 255},  // RTK            = 10  
   {0,   0,   0  },  // INVALID_MODE11 = 11  
   {0,   0,   0  },  // INVALID_MODE12 = 12  
   {0,   0,   0  },  // INVALID_MODE13 = 13  
   {0,   0,   0  },  // INVALID_MODE14 = 14  
   {0,   0,   0  },  // INVALID_MODE15 = 15  
   {0,   0,   0  },  // INVALID_MODE16 = 16  
   {0,   0,   0  },  // INVALID_MODE17 = 17  
   {0,   0,   0  },  // INVALID_MODE18 = 18  
   {0,   0,   0  },  // INVALID_MODE19 = 19  
   {0,   0,   0  },  // INVALID_MODE20 = 20  
   {0,   0,   0  },  // INVALID_MODE21 = 21  
   {0,   0,   0  },  // INVALID_MODE22 = 22  
   {0,   0,   0  },  // INVALID_MODE23 = 23  
   {0,   0,   0  },  // INVALID_MODE24 = 24  
   {0,   0,   0  },  // INVALID_MODE25 = 25  
   {0,   0,   0  },  // INVALID_MODE26 = 26  
   {0,   0,   0  },  // INVALID_MODE27 = 27  
   {0,   0,   0  },  // INVALID_MODE28 = 28  
   {0,   0,   0  },  // INVALID_MODE29 = 29  
   {0,   0,   0  },  // INVALID_MODE30 = 30  
   {0,   0,   0  }}; // INVALID_MODE31 = 31  
   CPen      Pen(PS_SOLID,1,RGB(NavModeColor[eNavMode].r, NavModeColor[eNavMode].g, NavModeColor[eNavMode].b));
   CBrush    Brush(RGB(NavModeColor[eNavMode].r, NavModeColor[eNavMode].g, NavModeColor[eNavMode].b));    
	CPen     *OldPen =   DC.SelectObject(&Pen);
	CBrush   *OldBrush = DC.SelectObject(&Brush);
   
   GetClientRect(&Rect);

   if(m_bDotStyle){ // Draw a dot
      DC.Ellipse(m_iWindowXCenter + iXCoor - (2 + (m_iDotSize * 2)),
                 m_iWindowYCenter - iYCoor - (2 + (m_iDotSize * 2)),
                 m_iWindowXCenter + iXCoor + (2 + (m_iDotSize * 2)),
                 m_iWindowYCenter - iYCoor + (2 + (m_iDotSize * 2)));
   }
   else{ // Draw a plus sign
      DC.MoveTo(m_iWindowXCenter + iXCoor - (2 + (m_iDotSize * 2)), m_iWindowYCenter - iYCoor);
      DC.LineTo(m_iWindowXCenter + iXCoor + (2 + (m_iDotSize * 2)), m_iWindowYCenter - iYCoor);

      DC.MoveTo(m_iWindowXCenter + iXCoor, m_iWindowYCenter - iYCoor - (2 + (m_iDotSize * 2)));
      DC.LineTo(m_iWindowXCenter + iXCoor, m_iWindowYCenter - iYCoor + (2 + (m_iDotSize * 2))); 
   }
	DC.SelectObject(OldPen);
	DC.SelectObject(OldBrush);
}


/********************************************************************************
 *
 * NAME:            RadianToDegree
 *
 * DESCRIPTION:     Converts a radian angle into degree.  The result is returned
 *                  to the caller by the memory location pointed by the pointer
 *                  pdDegree.
 *
 *                  Note: the angle retruns will always be positive.
 *
 * ATTRIBUTES USED:
 *    inputs:       dRadian,
 *    outputs:      *pdDegree
 *
 ********************************************************************************/
void CNavPlotWnd::RadianToDegree(const double  dRadian, 
                                       double *pdDegree)
{ 
   int      Deg,Min;
   double   Angle,Angle1,Sec;

   Angle     = dRadian * 180.0 / PI;
   Angle1    = fabs(Angle);
   Deg       = (int)Angle1;
   Min       = (int)((Angle1 - (double)Deg) * 60.0);
   Sec       = (Angle1 - (double)(Deg) - (double)(Min / 60.0)) * 3600.0;

   *pdDegree = Deg + (double)Min / 100 + Sec / 10000;

   if(Angle < 0) 
      *pdDegree *= -1;
   
}

/********************************************************************************
 *
 * NAME:            DegreeToRadian
 *
 * DESCRIPTION:     Converts a degree angle into radian.  The result is returned
 *                  to the caller by the memory location pointed by the pointer
 *                  pdRadian.
 *
 * ATTRIBUTES USED:
 *    inputs:       dDegree,
 *    outputs:      *pdRadian
 *
 ********************************************************************************/
void CNavPlotWnd::DegreeToRadian(const double  dDegree, 
                                       double *pdRadian)
{ 
   int      Deg,  Min;
   double   Sec;

   Deg       = (int)dDegree;
   Min       = (int)((dDegree - (double)Deg) * 100.0);
   Sec       = ((dDegree - (double)Deg) * 100.0 - (double)Min) * 100.0;

   *pdRadian = ((double)Deg + (double)(Min / 60.0) + (double)(Sec / 3600.0)) * PI / 180;
}


/********************************************************************************
 *
 * NAME:            ComputeStepValue
 *
 * DESCRIPTION:     Compute the step value in radian for 1 meter for a given position.
 *
 * ATTRIBUTES USED:
 *    inputs:       m_dCenterPointLat
 *    outputs:      m_dStepValueLat, m_dStepValueLong
 *
 ********************************************************************************/
void CNavPlotWnd::ComputeStepValue(void)
{
//   m_dStepValueLat  = 111132.92 - 559.82 * cos(2 * m_dCenterPointLat);
//   m_dStepValueLong = 111412.84          * cos(    m_dCenterPointLong);
   m_dStepValueLat  = 1.0 / EARTH_RADIUS;
   m_dStepValueLong = 1.0 / (EARTH_RADIUS * cos(m_dCenterPointLat));
}


/********************************************************************************
 *
 * NAME:            DrawCoordinates
 *
 * DESCRIPTION:     Write the latitude and the longitude of the center window
 *                  position and some poistions around. (radius and radius / 2)
 *
 *                  Note: if bVisible is FALSE the function is not execute.
 *
 * ATTRIBUTES USED:
 *    inputs:       bVisible,
 *                  m_dCenterPointLat,
 *                  m_dCenterPointLong,
 *                  m_iWindowXCenter,
 *                  m_iWindowYCenter,
 *                  m_iZoomValue,
 *                  m_dStepValueLat,
 *                  m_dStepValueLong,
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::WriteCoordinates(BOOLEAN bVisible)
{
   double dTemp;
   double dCoordinate;
   char   Hemisphere;
   CRect  Rect; 

   GetClientRect(&Rect);

   if(bVisible){
      // Write Latitude coordinates
      // Determine in witch hemesphere we are
      if(m_dCenterPointLat < 0.0 ) 
         Hemisphere = 'S';
      else                        
         Hemisphere = 'N';

      // Center point
      WriteCoorDeg(Rect.left,            
                   m_iWindowYCenter,
                   m_dCenterPointLat,   
                   Hemisphere);

      // Write coordinates for some points
      dTemp       = m_iZoomValue * m_dStepValueLat; // transformation of the zoom in radian
      dCoordinate = m_dCenterPointLat - dTemp;
      WriteCoorDeg(Rect.left,            
                   m_iWindowYCenter + m_iBiggestRadius, 
                   dCoordinate,   
                   'Z'); // Dummy parameter (Hemisphere is only write for the center point)

      dCoordinate = m_dCenterPointLat + dTemp;
      WriteCoorDeg(Rect.left,            
                   m_iWindowYCenter - m_iBiggestRadius,
                   dCoordinate,   
                   'Z'); // Dummy parameter (Hemisphere is only write for the center point)

      dTemp       = ( m_iZoomValue / 2) * m_dStepValueLat; // transformation of the zoom in radian
      dCoordinate = m_dCenterPointLat - dTemp;
      WriteCoorDeg(Rect.left,            
                   m_iWindowYCenter + m_iBiggestRadius / 2,
                   dCoordinate,   
                   'Z'); // Dummy parameter (Hemisphere is only write for the center point)

      dCoordinate = m_dCenterPointLat + dTemp;
      WriteCoorDeg(Rect.left,            
                   m_iWindowYCenter - m_iBiggestRadius / 2,
                   dCoordinate,   
                   'Z'); // Dummy parameter (Hemisphere is only write for the center point)
   
      // Write Longitude coordinates
      // Determine in witch hemesphere we are
      if(m_dCenterPointLong < 0.0 ) 
         Hemisphere = 'W';
      else                        
         Hemisphere = 'E';

      // Center point
      WriteCoorDeg(m_iWindowXCenter - 40, // 40 is to center text around long. line
                   Rect.top,
                   m_dCenterPointLong,           
                   Hemisphere);

      // Write coordinates for some points
      dTemp       = m_iZoomValue * m_dStepValueLong; // transformation of the zoom in radian
      dCoordinate = m_dCenterPointLong - dTemp;
      WriteCoorDeg(m_iWindowXCenter - m_iBiggestRadius - 40, // 40 is to center text around long. line
                   Rect.top,
                   dCoordinate,   
                   'Z'); // Dummy parameter (Hemisphere is only write for the center point)

      
      dCoordinate = m_dCenterPointLong + dTemp;
      WriteCoorDeg(m_iWindowXCenter + m_iBiggestRadius - 40, // 40 is to center text around long. line           
                   Rect.top,
                   dCoordinate,   
                   'Z'); // Dummy parameter (Hemisphere is only write for the center point)

      dTemp       = ( m_iZoomValue / 2) * m_dStepValueLong; // transformation of the zoom in radian
      dCoordinate = m_dCenterPointLong - dTemp;
      WriteCoorDeg(m_iWindowXCenter - m_iBiggestRadius / 2 - 40, // 40 is to center text around long. line           
                   Rect.top,
                   dCoordinate,   
                   'Z'); // Dummy parameter (Hemisphere is only write for the center point)

      
      dCoordinate = m_dCenterPointLong + dTemp;
      WriteCoorDeg(m_iWindowXCenter + m_iBiggestRadius / 2 - 40, // 40 is to center text around long. line           
                   Rect.top,
                   dCoordinate,   
                   'Z'); // Dummy parameter (Hemisphere is only write for the center point)
   }
}

/********************************************************************************
 *
 * NAME:            WriteCoorDeg
 *
 * DESCRIPTION:     Write text coordinates in degree.  Coordinates received should
 *                  be in radian.
 *
 *                  Note: if Hemisphere parameter is 'Z' then only the last part
 *                        of the coordinates is writen. (minute(s) and secons(s))
 *
 * ATTRIBUTES USED:
 *    inputs:       iStartx,
 *                  iStarty,
 *                  AngleRad,
 *                  Hemisphere
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::WriteCoorDeg(int    iStartx, 
                               int    iStarty, 
                               double AngleRad, 
                               char   Hemisphere)
{
   char      string[80];
   int       Deg,Min;
   double    Angle,Sec;
   CClientDC DC(this);

 	DC.SelectObject(m_Font);

   Angle = AngleRad * 180.0 / PI;
   Angle = fabs(Angle);
   Deg   = (int)Angle;
   Min   = (int)((Angle - (double) Deg) * 60.0);
   Sec   = (      Angle - (double)(Deg) - (double)(Min / 60.0)) * 3600.0;

   DC.MoveTo(iStartx, iStarty);

   if(Hemisphere == 'Z' )
      sprintf(string,"%02d'%06.3lf\"",Min,Sec);
   else
      sprintf(string,"%c%02d %02d'%06.3lf\"",Hemisphere,Deg,Min,Sec);
      
   DC.TextOut(iStartx, iStarty + 2,string,strlen(string));
}

/********************************************************************************
 * PUBLIC
 ********************************************************************************/
BEGIN_MESSAGE_MAP(CNavPlotWnd, CFrameWnd)
	//{{AFX_MSG_MAP(CNavPlotWnd)
	ON_WM_PAINT()
	ON_WM_DESTROY()
	ON_WM_RBUTTONDOWN()
	ON_COMMAND(IDM_NAV_PLOT_ZOOM_IN, OnNavPlotZoomIn)
	ON_COMMAND(IDM_NAV_PLOT_ZOOM_OUT, OnNavPlotZoomOut)
	ON_COMMAND(IDM_NAV_PLOT_GRID, OnNavPlotGrid)
	ON_COMMAND(IDM_NAV_PLOT_CONFIG_NAV, OnNavPlotConfigNav)
	ON_COMMAND(IDM_NAV_PLOT_COORDINATES, OnNavPlotCoordinates)
	ON_COMMAND(IDM_NAV_PLOT_CURRENT_NAV, OnNavPlotCurrentNav)
	ON_COMMAND(IDM_NAV_PLOT_DOT_STYLE, OnNavPlotDotStyle)
	ON_COMMAND(IDM_NAV_PLOT_DOT_SIZE_LARGE, OnNavPlotDotSizeLarge)
	ON_COMMAND(IDM_NAV_PLOT_DOT_SIZE_MEDIUM, OnNavPlotDotSizeMedium)
	ON_COMMAND(IDM_NAV_PLOT_DOT_SIZE_SMALL, OnNavPlotDotSizeSmall)
	ON_COMMAND(IDM_NAV_PLOT_PLUS_STYLE, OnNavPlotPlusStyle)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/********************************************************************************
 *
 * NAME:            CNavPlotWnd
 *
 * DESCRIPTION:     Constructor of Nav Plot object.
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
CNavPlotWnd::CNavPlotWnd()
{
   m_Font.CreateFont(10,0,0,0,FW_NORMAL,0,0,0,0,OUT_TT_PRECIS,0,
                    PROOF_QUALITY,FIXED_PITCH |FF_SWISS| 4,
                    "MS Sans Serif");

   m_bmMouse.LoadBitmap(IDB_RIGHT_BUTTON_MOUSE); 

   m_bDotStyle           = Config.Data.NavigationPlotInformation.bDotStyle;
   m_iDotSize            = Config.Data.NavigationPlotInformation.iDotSize;
   m_iZoomValue          = Config.Data.NavigationPlotInformation.iZoomValue;
   m_bGridVisible        = Config.Data.NavigationPlotInformation.bGridVisible;
   m_bCoordinatesVisible = Config.Data.NavigationPlotInformation.bCoordinatesVisible;
   m_dCenterPointLat     = Config.Data.NavigationPlotInformation.dConfigPositionLatitude;
   m_dCenterPointLong    = Config.Data.NavigationPlotInformation.dConfigPositionLongitude;

   
   DegreeToRadian(m_dCenterPointLat,  &m_dCenterPointLat); // position saved in radian
   DegreeToRadian(m_dCenterPointLong, &m_dCenterPointLong);

   // Initialize the current navigation position with the center point position in radian
   m_dCurrentPointLat   = m_dCenterPointLat;
   m_dCurrentPointLong  = m_dCenterPointLong;
   m_bLastPositionValid = FALSE;    
}


/********************************************************************************
 *
 * NAME:            ~CNavPlotWnd
 *
 * DESCRIPTION:     Destructor of Nav Plot object
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
CNavPlotWnd::~CNavPlotWnd()
{
   m_Font.DeleteObject();
   m_bmMouse.DeleteObject();
}

/********************************************************************************
 *
 * NAME:            OnPaint
 *
 * DESCRIPTION:     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::OnPaint() 
{
   CPaintDC  pdc(this);
   CBitmap  *pbmMouse;
   CRect     Rect;

   // Determine window center point
   GetClientRect(&Rect);
   m_iWindowXCenter = (Rect.right  - Rect.left) / 2;                     
   m_iWindowYCenter = (Rect.bottom - Rect.top)  / 2;

   // Mouse Bitmap
   pbmMouse = &m_bmMouse;
   if(pbmMouse->m_hObject != NULL){ // Bitmap found
      CRect rcClient;
	   GetClientRect(rcClient);

	   CClientDC cdc(this);
	   CBitmap* pbmOld = NULL;

	   CDC dcMem;
	   dcMem.CreateCompatibleDC(&cdc);
	   pbmOld = dcMem.SelectObject(pbmMouse);

      cdc.BitBlt(MOUSELEFT, MOUSETOP, 12, 16, &dcMem, 0, 0, SRCCOPY);

      dcMem.SelectObject(pbmOld);
	   dcMem.DeleteDC();
   }

   // Font setup
	pdc.SelectObject(m_Font);
	
   pdc.SetTextAlign(TA_TOP | TA_LEFT);
   pdc.SetTextColor(::GetSysColor(COLOR_WINDOWTEXT));
   pdc.SetBkMode(TRANSPARENT);

   ComputeStepValue();
   DrawCircles();
   DrawGrid(m_bGridVisible);
   WriteCoordinates(m_bCoordinatesVisible);
}

/********************************************************************************
 *
 * NAME:            OnCreateClient
 *
 * DESCRIPTION:     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
BOOL CNavPlotWnd::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
   m_RightButtonMenu.LoadMenu(IDR_NAV_PLOT);
   SetMenu(&m_RightButtonMenu);
   ShowWindow(SW_SHOW);

   return CFrameWnd::OnCreateClient(lpcs, pContext);
}

/********************************************************************************
 *
 * NAME:            PreCreateWindow
 *
 * DESCRIPTION:     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
BOOL CNavPlotWnd::PreCreateWindow(CREATESTRUCT& cs) 
{
	return CFrameWnd::PreCreateWindow(cs);
}

/********************************************************************************
 *
 * NAME:            OnDestroy
 *
 * DESCRIPTION:     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::OnDestroy() 
{
   CMainFrame *pOwner;
   pOwner=(CMainFrame *)GetOwner();

     if(Config.Data.bNavPlotWndActive == TRUE){
      Config.Data.bNavPlotWndActive = FALSE;
      pOwner->PostMessage(WM_COMMAND,IDM_NAV_PLOT , (LPARAM)0 );
   }
}

/********************************************************************************
 *
 * NAME:            GetGetNavPlotInfo
 *
 * DESCRIPTION:     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::GetNavPlotInfo(NAVIGATION_PLOT_INFO_TYPE  *pNavPlotInfo)
{
   double dLatDegree;
   double dLongDegree;

   RadianToDegree(m_dCenterPointLat,  &dLatDegree);
   RadianToDegree(m_dCenterPointLong, &dLongDegree);

   pNavPlotInfo->bGridVisible             = m_bGridVisible;
   pNavPlotInfo->bCoordinatesVisible      = m_bCoordinatesVisible;
   pNavPlotInfo->dConfigPositionLatitude  = dLatDegree;
   pNavPlotInfo->dConfigPositionLongitude = dLongDegree;
   pNavPlotInfo->bDotStyle                = m_bDotStyle;
   pNavPlotInfo->iDotSize                 = m_iDotSize;
   pNavPlotInfo->iZoomValue               = m_iZoomValue;
}

/********************************************************************************
 *
 * NAME:            UpdateNavPlotData
 *
 * DESCRIPTION:     Compute the location, in the window, of the coordinates received
 *                  and draw the result in the window.  The color of the point is
 *                  determined with the navigation mode received in parameter.
 *
 *                  Note: coordinates are received in radian
 *
 * ATTRIBUTES USED:
 *    inputs:       dLatRad,
 *                  dLongRad,
 *                  eNavMode,
 *                  m_dCenterPointLat,
 *                  m_dCenterPointLong,
 *                  m_dStepValueLat,
 *                  m_dStepValueLong
 *                  m_iBiggestRadius
 *
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::UpdateNavPlotData(double                    dLatRad, 
                                    double                    dLongRad, 
                                    DEFMSG_ENUM_NAV_MODE_TYPE eNavMode)
{
   int       iXCoor;
   int       iYCoor;
   CClientDC dc(this);

static int test = 0;

 	dc.SelectObject(m_Font);

   // Write the last position with the rigth nav mode color
   if(m_bLastPositionValid){
      double dLastLat  = m_dCurrentPointLat;
      double dLastLong = m_dCurrentPointLong;

      // Convert position in window coordinates
      dLastLat -= m_dCenterPointLat;   // Keep the distance between the center and the current position
      dLastLat /= m_dStepValueLat;     // result in meter

      dLastLong -= m_dCenterPointLong; // Keep the distance between the center and the current position
      dLastLong /= m_dStepValueLong;   // result in meter

      // Transformation in window units (pixel)
      iYCoor = (int)(dLastLat  * m_iBiggestRadius / m_iZoomValue); // radius is represented in pixel
      iXCoor = (int)(dLastLong * m_iBiggestRadius / m_iZoomValue);

      DrawDot(iXCoor, iYCoor, m_eCurrentNavMode);
   }
   // Save the current navigation position and mode
   m_dCurrentPointLat   = dLatRad;
   m_dCurrentPointLong  = dLongRad;
   m_eCurrentNavMode    = eNavMode;
   m_bLastPositionValid = TRUE;

   // Convert position in window coordinates
   dLatRad -= m_dCenterPointLat;   // Keep the distance between the center and the current position
   dLatRad /= m_dStepValueLat;     // result in meter

   dLongRad -= m_dCenterPointLong; // Keep the distance between the center and the current position
   dLongRad /= m_dStepValueLong;   // result in meter

   // Transformation in window units (pixel)
   iYCoor = (int)(dLatRad  * m_iBiggestRadius / m_iZoomValue); // radius is represented in pixel
   iXCoor = (int)(dLongRad * m_iBiggestRadius / m_iZoomValue);

   // Witre the current point in black
   DrawDot(iXCoor, iYCoor, NAV_MODE_INVALID_MODE);
}


/********************************************************************************
 *
 * NAME:            OnRButtonDown
 *
 * DESCRIPTION:     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::OnRButtonDown(UINT nFlags, CPoint point) 
{
   if(m_pCMCMsgBuilder != NULL){
      m_pCMCMsgBuilder->SendDataRequest(USER_NAV,CONTINUOUS);
	   CFrameWnd::OnRButtonDown(nFlags, point);
   }
}


/********************************************************************************
 *
 * NAME:            OnNavPlotZoomIn
 *
 * DESCRIPTION:     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::OnNavPlotZoomIn() 
{
   m_iZoomValue /= 10;
   if(m_iZoomValue < 1){    // Smallest value
      m_iZoomValue = 1;
   }

   // Invalidate window, so the window will be redraw.
   Invalidate(TRUE);
}


/********************************************************************************
 *
 * NAME:            OnNavPlotZoomOut
 *
 * DESCRIPTION:     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::OnNavPlotZoomOut() 
{
   m_iZoomValue *= 10;
   if(m_iZoomValue > 1000){ // Biggest value
      m_iZoomValue = 1000;
   }

   // Invalidate window, so the window will be redraw.
   Invalidate(TRUE);
}



/********************************************************************************
 *
 * NAME:            OnNavPlotGrid
 *
 * DESCRIPTION:     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::OnNavPlotGrid() 
{
	m_bGridVisible = (BOOLEAN)!m_bGridVisible;

   // Invalidate window, so the window will be redraw.
   Invalidate(TRUE);
}



/********************************************************************************
 *
 * NAME:            OnNavPlotConfigNav
 *
 * DESCRIPTION:     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::OnNavPlotConfigNav() 
{
   m_dCenterPointLat  = Config.Data.NavigationPlotInformation.dConfigPositionLatitude;
   m_dCenterPointLong = Config.Data.NavigationPlotInformation.dConfigPositionLongitude;
   
   DegreeToRadian(m_dCenterPointLat,  &m_dCenterPointLat); // position saved in radian
   DegreeToRadian(m_dCenterPointLong, &m_dCenterPointLong);

   // Invalidate window, so the window will be redraw.
   Invalidate(TRUE);
}



/********************************************************************************
 *
 * NAME:            OnNavPlotCoordinates
 *
 * DESCRIPTION:     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::OnNavPlotCoordinates() 
{
	m_bCoordinatesVisible = (BOOLEAN)!m_bCoordinatesVisible;
   // Invalidate window, so the window will be redraw.
   Invalidate(TRUE);
}


/********************************************************************************
 *
 * NAME:            OnNavPlotCurrentNav
 *
 * DESCRIPTION:     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::OnNavPlotCurrentNav() 
{
   m_dCenterPointLat  = m_dCurrentPointLat;
   m_dCenterPointLong = m_dCurrentPointLong;
   
   // Invalidate window, so the window will be redraw.
   Invalidate(TRUE);
}

/********************************************************************************
 *
 * NAME:            OnNavPlotDotStyle
 *
 * DESCRIPTION:     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::OnNavPlotDotStyle() 
{
   m_bDotStyle = TRUE;

   // Invalidate window, so the window will be redraw.
   Invalidate(TRUE);
}

/********************************************************************************
 *
 * NAME:            OnNavPlotDotSizeLarge
 *
 * DESCRIPTION:     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::OnNavPlotDotSizeLarge() 
{
   m_iDotSize = 3; // Large size

   // Invalidate window, so the window will be redraw.
   Invalidate(TRUE);
}

/********************************************************************************
 *
 * NAME:            OnNavPlotDotSizeMedium
 *
 * DESCRIPTION:     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::OnNavPlotDotSizeMedium() 
{
   m_iDotSize = 2; // Medium size

   // Invalidate window, so the window will be redraw.
   Invalidate(TRUE);
}

/********************************************************************************
 *
 * NAME:            OnNavPlotDotSizeSmall
 *
 * DESCRIPTION:     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::OnNavPlotDotSizeSmall() 
{
   m_iDotSize = 1; // small size

   // Invalidate window, so the window will be redraw.
   Invalidate(TRUE);
}

/********************************************************************************
 *
 * NAME:            OnNavPlotPlusStyle
 *
 * DESCRIPTION:     
 *
 * ATTRIBUTES USED:
 *    inputs:       
 *    outputs:
 *
 ********************************************************************************/
void CNavPlotWnd::OnNavPlotPlusStyle() 
{
   m_bDotStyle = FALSE;

   // Invalidate window, so the window will be redraw.
   Invalidate(TRUE);
}
