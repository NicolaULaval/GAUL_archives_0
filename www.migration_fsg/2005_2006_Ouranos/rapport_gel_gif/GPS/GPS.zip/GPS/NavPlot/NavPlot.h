/***********************************************************************
 *
 *  CANADIAN MARCONI COMPANY
 *
 *  Copyright (c) 1997 Canadian Marconi Company.  All rights reserved.
 *  May be used only in accordance with a valid Source Code License
 *  Agreement with CMC.
 *
 *  COMPONENT: NavPlotWnd
 *
 *  Purpose:   Header file for the navigation plot Window (NavPlot.cpp)
 *                                                                            
 * $Workfile: NavPlot.h $, $ $
 *
 * $Author: Coopoem $, $ $
 *
 * $Modtime: 6/22/99 10:35a $             
 *
 * $Log: /GPS/Allstar/Code/Utilities/ProjetASV/NavPlot.h $                 
 * 
 * 1     8/06/99 12:49p Coopoem
 * Projet ASV, premiere version archive dans Source Safe. Les classes
 * ASVWnd, OperatingUnit et ScriptParser sont assez avancees. Script
 * Parser operationnel pour un premier set de commande (test�).
 * 
 * 5     2/23/99 9:41a Stlevesq
 * Show current position point in black (INVALID_NAV_MODE)
 * 
 * 4     12/22/98 3:22p Stlevesq
 * Implementation of navigation plot window.
 * 
 * 3     2/26/98 2:23p Stlevesq
 * Change comment : {{AFX_MSG(CMsgWnd) to {{AFX_MSG(CNavPlotWnd)
 * 
 * 2     9/08/97 5:31p Sdortun
 * Input serial port Bugged fixed in mainfrm.cpp
 * In Timer function , comment RTS/CTS flow control
 * 
 * 1     9/03/97 4:03p Sdortun
 * Nav plot window frame added to toolbar and config
 * 
 * 
 ***********************************************************************/
#ifndef _NAVPLOTWND_H
#define _NAVPLOTWND_H
 
/*-----------------------------------------------------------------------
 *                    * * * * *  INCLUDES  * * * * *                     
 *----------------------------------------------------------------------*/
#include <wingdi.h>
#include "CMCMsgBuilder.h"
#include "CMCType.h"

extern "C" {
   #include "oper/defmsg.h"
}

/*------------------------------------------------------------------------
 *                    * * * * *  DEFINITIONS  * * * * *                  
 *----------------------------------------------------------------------*/

/*------------------------------------------------------------------------  
 *                 * * * * *  STRUCTURES & CLASSES  * * * * *             
 *----------------------------------------------------------------------*/

typedef struct{
   BOOLEAN bGridVisible;
   BOOLEAN bCoordinatesVisible;
   double  dConfigPositionLatitude;
   double  dConfigPositionLongitude;
   BOOLEAN bDotStyle; // TRUE: dot, FALSE: plus sign
   int     iDotSize; // 0 to 5
   int     iZoomValue;
} NAVIGATION_PLOT_INFO_TYPE;

class CNavPlotWnd : public CFrameWnd
{
	DECLARE_DYNCREATE(CNavPlotWnd)
public:
	CNavPlotWnd();           
	
// Attributes
public:
   TCMCMsgBuilder            *m_pCMCMsgBuilder;

private:
   CFont                      m_Font;
   CBitmap                    m_bmMouse;
   CMenu                      m_RightButtonMenu;

   int                        m_iZoomValue;
   BOOLEAN                    m_bDotStyle; // TRUE: Dot (default) and FALSE: plus sign
   int                        m_iDotSize;
   int                        m_iBiggestRadius;
   int                        m_iWindowXCenter;
   int                        m_iWindowYCenter;
   double                     m_dCenterPointLat;
   double                     m_dCenterPointLong;
   double                     m_dStepValueLat;
   double                     m_dStepValueLong;
   double                     m_dCurrentPointLat;
   DEFMSG_ENUM_NAV_MODE_TYPE  m_eCurrentNavMode;
   double                     m_dCurrentPointLong;
   BOOLEAN                    m_bLastPositionValid;
   BOOLEAN                    m_bCoordinatesVisible;
   BOOLEAN                    m_bGridVisible;

   void DrawCircles      (void);

   void DrawDot          (int                         iXCoor,       
                          int                         iYCoor,      
                          DEFMSG_ENUM_NAV_MODE_TYPE   eNavMode);
   
   void WriteCoordinates (BOOLEAN                     bVisible);    
   
   void ChangeCenterPoint(double                      dCenterCoorLat, 
                          double                      dCenterCoorLong); // values in radians
   
   void DrawGrid         (BOOLEAN                     bVisible);
   
   void RadianToDegree   (const double                dRadian, 
                                double               *pdDegree);
   
   void DegreeToRadian   (const double                dDegree, 
                                double               *pdRadian);
   
   void ComputeStepValue (void);
   
   void WriteCoorDeg     (int                         iStartx, 
                          int                         iStarty, 
                          double                      AngleRad, 
                          char                        Hemisphere);
   
// Operations
public:

   // Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRadioWin)
	protected:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CNavPlotWnd();

   void UpdateNavPlotData(double dLatRad, double dLongRad, DEFMSG_ENUM_NAV_MODE_TYPE eNavMode);

   void GetNavPlotInfo(NAVIGATION_PLOT_INFO_TYPE  *pNavPlotInfo);

   // Generated message map functions
	//{{AFX_MSG(CNavPlotWnd)
	afx_msg void OnPaint();
	afx_msg void OnDestroy();
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnNavPlotZoomIn();
	afx_msg void OnNavPlotZoomOut();
	afx_msg void OnNavPlotGrid();
	afx_msg void OnNavPlotConfigNav();
	afx_msg void OnNavPlotCoordinates();
	afx_msg void OnNavPlotCurrentNav();
	afx_msg void OnNavPlotDotStyle();
	afx_msg void OnNavPlotDotSizeLarge();
	afx_msg void OnNavPlotDotSizeMedium();
	afx_msg void OnNavPlotDotSizeSmall();
	afx_msg void OnNavPlotPlusStyle();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


#endif
/////////////////////////////////////////////////////////////////////////////
