import java.util.*;
import java.awt.*;
import java.io.*;
import java.lang.*;
import java.awt.event.*;
import javax.comm.*;

public class Terminal extends      Frame
                      implements   Runnable,
                                   java.awt.event.ActionListener,
                                   SerialPortEventListener{

   // Objets de la classe Terminal
	//{{DECLARE_CONTROLS
   Thread TThisWindows;

   CommPortIdentifier portId;
   boolean bPortOpen = false;
   Enumeration portList;
   SerialPort serialPort;
   InputStream inputStream;
   OutputStream outputStream;
   RandomAccessFile rafLogFile;

   // Objet specifique pour l'application
   NMEA m_NMEA = new NMEA();
   String sLineMessage;

   // Options
   private String ExtentionOption           = new String("*.log;*.txt");
   private String DirectoryOption           = new String("C:\\");
   private String NomFichier                = new String();
   private byte    iNumberLinesBuffered      = 10;
   private byte    iNumberLine               = 1;
   private short    W = 650, H = 250;
   private short    TimeOut = 2000;

   // �tat du d�roulement du programme
   private final byte SAVE_LOG_INCOMMING_DATA_STATE     = 1;
   private final byte READ_LOG_DATA_FILE_STATE          = 2;
   private final byte READ_LOG_DATA_COM_STATE           = 3;
   private final byte IDLE                              = 4;
   private byte       STATUS                            = IDLE;
   private boolean   bRUN                              = false;

   // Etat de la communication
   private final byte COM_PORT_OPEN_IDLE                = 1;
   private final byte COM_PORT_OPEN_RUNNING             = 2;
   private final byte COM_PORT_NONE                     = 3;
   private final byte COM_PORT_CLOSE                    = 4;
   private final byte NO_PORT_DETECTED                  = 5;
   private final byte INVALID_STATE                     = 6;
   private byte       STATUS_COMM                       = COM_PORT_OPEN_IDLE;

   Panel pOptions;
   Button SELECT_BAUD_RATE;
   short iBAUD = 4800;
   //Button SELECT_COM;
   private Choice pv_portChoice;


   TextField tfEtatCommunication;
   Label lEtatCommunication;
   Button STOP;
   Button EFFACER;

   TextArea taMessage;
   Panel pCommandLine;
   Label lCommandLine;
   TextField tfCommandLine;
   Button SEND;
   //private final byte
   //}}

	//{{DECLARE_MENUS
   // Menu relatif aux programme
   MenuBar Menub;
   Menu mMenuFichier;
   CheckboxMenuItem iOptionOuvrir;
   CheckboxMenuItem iOptionEnregistrer;
   CheckboxMenuItem iOptionImprimer;
   MenuItem iOptionQuitter;
	//}}

   public Terminal(){


      //{{INIT_CONTROLS
      setTitle("Terminal -Otis Software Solutions-");
      setSize(W, H);
      setLayout(new BorderLayout());
      taMessage = new TextArea(new String(""),50, 50, TextArea.SCROLLBARS_NONE);
      add("Center", taMessage);
      pCommandLine = new Panel();
      lCommandLine = new Label("Ligne de Commande");
      tfCommandLine = new TextField(50);
      SEND = new Button("Envoyez");

      pOptions = new Panel();
      SELECT_BAUD_RATE = new Button(Integer.toString(iBAUD));
      STOP = new Button("D�marrer");
      EFFACER = new Button("Effacer");
      lEtatCommunication = new Label("�tat ");
      tfEtatCommunication = new TextField("NONE " + Integer.toString(iBAUD) + " Idle", 25);
      //SELECT_COM = new Button("NONE");

      pv_portChoice = new Choice();

      TThisWindows            = null;
      portId                  = null;
      portList                = null;
      serialPort              = null;

      pv_listPortChoices();



      pOptions.add(SELECT_BAUD_RATE);
      //pOptions.add(SELECT_COM);
      pOptions.add(pv_portChoice);
      pOptions.add(STOP);
      pOptions.add(EFFACER);
      pOptions.add(lEtatCommunication);
      pOptions.add(tfEtatCommunication);
      add("North", pOptions);

      pCommandLine.add(lCommandLine);
      pCommandLine.add(tfCommandLine);
      pCommandLine.add(SEND);
      pCommandLine.setBackground(Color.cyan);
      add("South", pCommandLine);
      //}}

      // Menu relatif aux programme
      //{{INIT_MENUS
      Menub                 = new MenuBar();
      mMenuFichier          = new Menu("Fichier");
      iOptionOuvrir         = new CheckboxMenuItem("Ouvrir un log ...");
      iOptionEnregistrer    = new CheckboxMenuItem("Enregistrer ...");
      iOptionImprimer       = new CheckboxMenuItem("Imprimer en echo");
      iOptionQuitter        = new MenuItem("Quitter");

      Menub.add(mMenuFichier);
      mMenuFichier.add(iOptionOuvrir);
      mMenuFichier.add(iOptionEnregistrer);
      mMenuFichier.addSeparator();
      mMenuFichier.add(iOptionImprimer);
      mMenuFichier.addSeparator();
      mMenuFichier.add(iOptionQuitter);
      setMenuBar(Menub);

		iOptionOuvrir.addActionListener(this);
      iOptionEnregistrer.addActionListener(this);
      iOptionImprimer.addActionListener(this);
      iOptionQuitter.addActionListener(this);
      SEND.addActionListener(this);
      STOP.addActionListener(this);
      EFFACER.addActionListener(this);
      SELECT_BAUD_RATE.addActionListener(this);
      //addWindowListener(this);

      //}}

}

   /************************************************************************************************
   * Mise en place des Threads
   * Fonctions:
   *          start()
   *          stop()
   *          run()
   ************************************************************************************************/

    public void startSerialCom(){

        if( bPortOpen == false){
          // Obtain a CommPortIdentifier object for the port you want to open.
          try {
            portId = CommPortIdentifier.getPortIdentifier(pv_portChoice.getSelectedItem());
          } catch (NoSuchPortException e) {
             STATUS_COMM = NO_PORT_DETECTED;
          }

          // Open the port represented by the CommPortIdentifier object. Give
          // the open call a relatively long timeout of 30 seconds to allow
          // a different application to reliquish the port if the user
          // wants to.
          try {
            serialPort = (SerialPort) portId.open("OtisTerminal", TimeOut);
            STATUS_COMM = COM_PORT_OPEN_IDLE;
            SimpleRead();
          } catch (PortInUseException e) {
             STATUS_COMM = NO_PORT_DETECTED;
          }

        }
    }

   public void stopSerialCom(){

            //inputStream = serialPort.getInputStream();
            //outputStream = serialPort.getOutputStream();

      if(bPortOpen == true){
         STATUS = IDLE;
         STATUS_COMM = COM_PORT_CLOSE;
         bRUN = false;
         if(serialPort != null){
            serialPort.notifyOnDataAvailable(false);
            serialPort.removeEventListener();
            try {
               // close the i/o streams.
               inputStream.close();
               outputStream.close();
            } catch (IOException e) {
               System.err.println(e);
            }

            // Close the port.
            serialPort.close();
            bPortOpen = false;

            // Remove the ownership listener.
            //portId.removePortOwnershipListener(this);
         }

      }

   }


   /************************************************************************************************
   * Ex�cution du Thread principal de la fen�tre
   ************************************************************************************************/
   public void run(){

        while(true){

            try{
                Thread.sleep(100);
            }catch(InterruptedException ie){}

            if( (STATUS != READ_LOG_DATA_COM_STATE) &&
                 (STATUS != IDLE) &&
                 (bRUN == true) ){

                // Si fin de fichier... on lit le port serie
                if( pv_AfficherMessage() == true ){
                   startSerialCom();
                }
                /*else{
                   pv_UpdateFieldWnd();
                }*/
            }

        }

   }

   public boolean m_isRunning(){ return bRUN; }

   private void pv_UpdateFieldWnd(){

      if(bRUN == true){
         STOP.setLabel("-Arr�ter-");
      }
      else{
         STOP.setLabel("D�marrer");
      }
      SELECT_BAUD_RATE.setLabel(Integer.toString(iBAUD));

      if(portId != null){
         //SELECT_COM.setLabel(portId.getName());

          // Etat de la communication
          switch( STATUS_COMM ){
             case COM_PORT_OPEN_IDLE:{

                tfEtatCommunication.setText(portId.getName() + " " + Integer.toString(iBAUD) + " Idle");
                //SELECT_COM.setLabel(portId.getName());

                } break;

             case COM_PORT_OPEN_RUNNING:{

                tfEtatCommunication.setText(portId.getName() + " " + Integer.toString(iBAUD));
                //SELECT_COM.setLabel(portId.getName());

                } break;

             case COM_PORT_NONE:{

                //SELECT_COM.setLabel("NONE");
                tfEtatCommunication.setText("NONE " + Integer.toString(iBAUD) + " Idle");

                } break;

             case COM_PORT_CLOSE:{

                tfEtatCommunication.setText(portId.getName() + " " + Integer.toString(iBAUD) + " closed.");
                //SELECT_COM.setLabel(portId.getName());

                } break;

             case NO_PORT_DETECTED:{

                tfEtatCommunication.setText("Aucun port detecte.");

             } break;

             case INVALID_STATE:{
                tfEtatCommunication.setText("�tat invalid.");
             }break;


             default :{

                tfEtatCommunication.setText("Invalide... ");
                //SELECT_COM.setLabel("Inv.");

                } break;
          }// switch
      }// si portId =! null
   }

 /***************************************************************
  * Function Name : pv_AfficherMessage
  * Author        : Martin Otis
  * Purpose       : Cette fonction affiche les messages recu par
  *                 un medium de communication.
  * Output        : boolean (vrai == EOF).
  *
  ****************************************************************/

   private boolean pv_AfficherMessage(){

      // variables de control
      boolean           bEOF            = false;
      boolean           Error1          = false;
      boolean           Error2          = false;
      boolean           Error3          = false;

      if(iNumberLine > iNumberLinesBuffered){
         EffaceText();
         iNumberLine = 1;
      }

      switch ( STATUS ) {
         case SAVE_LOG_INCOMMING_DATA_STATE :{

            if( (rafLogFile != null) &&
                (sLineMessage != null) ){

               taMessage.append(sLineMessage);
               iNumberLine++;
               try{
                  rafLogFile.writeChars(sLineMessage);
               }
               catch(IOException e){
                  STATUS = READ_LOG_DATA_COM_STATE;
                  System.out.println("Unable to write in log file.");
                  rafLogFile = null;
                  TThisWindows = null;
               }
            }

         } break;


         case READ_LOG_DATA_COM_STATE :{
            if( sLineMessage != null ){  // insert-> il faudrait trouver le /n et * iNumberLine par le nb de char avant le /n
               taMessage.append(sLineMessage/*, iNumberLine*/);
               ++iNumberLine;
            }

            } break;

         case READ_LOG_DATA_FILE_STATE :{

            if(bEOF == false){

               try{
                  sLineMessage = rafLogFile.readLine();
                  taMessage.append(sLineMessage+"\n"/*, iNumberLine*/);
                  iNumberLine++;
               }

               // Si fin du fichier, sortir de la boucle et �tat par d�faut
               catch(EOFException e){
                  bEOF = true;
                  tfEtatCommunication.setText("Fin du fichier.");
                  Error1 = true;
               }

               catch(IOException e){
                  tfEtatCommunication.setText("Erreur I/O");
                  bEOF = true;
                  Error2 = true;
               }

               finally{
                  // Traitement des informations sur les messages NMEA
                  if(sLineMessage == null){
                     bEOF = true;
                     tfEtatCommunication.setText("Fin du fichier.");
                  }
                  else{
                    if(!Error1 && !Error2){
                        byte readBuffer[] = new byte[sLineMessage.length()];
                        readBuffer = sLineMessage.getBytes();
                        m_NMEA.OnNewData(readBuffer, (short)sLineMessage.length());
                    }
                    else{
                      // si une erreur, un detruit le thread
                      if(TThisWindows != null){
                          TThisWindows = null;
                      }
                    }
                  }
               }                        // finally


            }                           // fin du if bEOF==false
         }break;

         case IDLE : {} break;
         default:{
            STATUS_COMM = INVALID_STATE;
            STATUS = IDLE;
            // si une erreur, un detruit le thread
            if(TThisWindows != null) TThisWindows = null;

         } break;

      }                                 // fin du switch
      return bEOF;
   }



    public void SimpleRead() {

      if(portId.getPortType() == CommPortIdentifier.PORT_SERIAL){

         try {
            inputStream = serialPort.getInputStream();
            outputStream = serialPort.getOutputStream();
         }
         catch (IOException e) {}

         try {
            serialPort.addEventListener(this);
         }
         catch (TooManyListenersException e) {}
         catch( NullPointerException e ) {}

         try{
            serialPort.notifyOnDataAvailable(true);
         }
         catch( NullPointerException e ) {}

         try {
            serialPort.setSerialPortParams(iBAUD,
                                           SerialPort.DATABITS_8,
                                           SerialPort.STOPBITS_1,
                                           SerialPort.PARITY_NONE);
         }
         catch (UnsupportedCommOperationException e) {}
         catch( NullPointerException e ) {}

         // Add ownership listener to allow ownership event handling.
         // portId.addPortOwnershipListener(this);
         STATUS = READ_LOG_DATA_COM_STATE;
         STATUS_COMM = COM_PORT_OPEN_IDLE;
         bRUN = true;
         bPortOpen = true;

      }                                 // end if


      if(portId.getPortType() == CommPortIdentifier.PORT_PARALLEL){}

    }
 //-------------------------------------------------------------
 // This file has been migrated from the 1.0 to 1.1 event model.
 // This method is not used with the new 1.1 event model. You can
 // move any code you need to keep, then remove this method.
 //-------------------------------------------------------------
 //
 // /*******************************************************************
 //  * Gestionnaire des �venements
 //  * ****************************************************************/
 //actionPerformed(ActionEvent evenement)
     public void actionPerformed(ActionEvent evenement)//action(Event evenement, Object argument)
     {

        String Code = (String)evenement.getActionCommand();
        System.out.println("<"+Code+">");
        //String Code = (String)evenement;
        boolean bError = false;

        /*********************************
         * Commande d'imprimante
         * *******************************/
        if(Code.equals(iOptionImprimer.getActionCommand())){ //"Imprimer en echo"
           System.out.println("Commande imprimer non definie.");
        }

        /*********************************
         * Commande Fichier Ouvrir
         * *******************************/

        if(Code.equals(iOptionOuvrir.getActionCommand())){ //"Ouvrir un log ..."

            if(STATUS != READ_LOG_DATA_FILE_STATE){// on arrete le com port

               //iOptionOuvrir.setState(true);
               stopSerialCom();
               TThisWindows = null;
               NomFichier = null;
               rafLogFile = null;

               FileDialog OuvrirFichier = new FileDialog(this, iOptionOuvrir.getActionCommand(), FileDialog.LOAD);
               OuvrirFichier.setFile(ExtentionOption);
               OuvrirFichier.setDirectory(DirectoryOption);
               OuvrirFichier.show();

               try{

                  //OuvrirFichier.setFilenameFilter(ExtentionOption);
                  NomFichier = OuvrirFichier.getDirectory();
                  String temp = new String(OuvrirFichier.getFile());

                  NomFichier = NomFichier + temp;
                  System.out.println("Log: " + NomFichier + ".\n");

                  try{
                     rafLogFile = new RandomAccessFile(NomFichier, "r");
                     STATUS = READ_LOG_DATA_FILE_STATE;
                     bRUN = true;
                     tfEtatCommunication.setText("Lecture :" + temp);
                     TThisWindows = new Thread(this, "ReadFile");
                     if(TThisWindows != null) TThisWindows.start();
                     else tfEtatCommunication.setText("Fail to start Thread");
                  }

                  catch(IOException e){
                     tfEtatCommunication.setText("Erreur I/O");
                     bRUN = false;
                  }

               }                               // fin du premier try

               catch(NullPointerException  e) {
                  tfEtatCommunication.setText("Fichier invalide.");
                  bRUN = false;
               }

               EffaceText();
            }
            else{
                  STATUS = READ_LOG_DATA_COM_STATE;
                  //iOptionOuvrir.setState(false);
                  System.out.println("Fin de la lecture.");
                  //startSerialCom();
                  rafLogFile = null;
                  TThisWindows = null;
            }

        }// fin de l'�venement d'ouverture

        /*********************************
         * Commande Fichier Enregistrer
         * *******************************/
        if(Code.equals(iOptionEnregistrer.getActionCommand())){ //"Enregistrer ..."

            if(STATUS != SAVE_LOG_INCOMMING_DATA_STATE){
               STATUS = SAVE_LOG_INCOMMING_DATA_STATE;
               NomFichier = null;
               rafLogFile = null;
               TThisWindows = null;

               FileDialog OuvrirFichier = new FileDialog(this, iOptionEnregistrer.getActionCommand(), FileDialog.SAVE);
               OuvrirFichier.setFile(ExtentionOption);
               OuvrirFichier.setDirectory(DirectoryOption);
               OuvrirFichier.show();

               try{

                  //OuvrirFichier.setFilenameFilter(ExtentionOption);
                  NomFichier = OuvrirFichier.getDirectory();
                  String temp = new String(OuvrirFichier.getFile());

                  NomFichier = NomFichier + temp;
                  System.out.println("Log: " + NomFichier + ".\n");

                  try{
                     rafLogFile = new RandomAccessFile(NomFichier, "w");
                     STATUS = SAVE_LOG_INCOMMING_DATA_STATE;
                     bRUN = true;
                     tfEtatCommunication.setText("Ecriture :" + temp);
                     TThisWindows = new Thread(this, "WriteFile");
                     if(TThisWindows != null) TThisWindows.start();
                     else tfEtatCommunication.setText("Fail to start Thread");
                  }

                  catch(IOException e){
                     tfEtatCommunication.setText("Erreur I/O");
                     bRUN = false;
                  }

               }                               // fin du premier try

               catch(NullPointerException  e) {
                  tfEtatCommunication.setText("Fichier invalide.");
                  bRUN = false;
               }

               EffaceText();
            }

            else{
                  STATUS = READ_LOG_DATA_COM_STATE;
                  System.out.println("Fin de l'enregistrement.");
                  rafLogFile = null;
                  TThisWindows = null;
            }
        }


        /*********************************
         * Commande Changement du baud rate
         * *******************************/
        if( (Code.equals(SELECT_BAUD_RATE.getActionCommand())) &&
            (STATUS == READ_LOG_DATA_COM_STATE) ){

           if(iBAUD < 19200){
              iBAUD = (short)(iBAUD*2);
           }
           else{
              iBAUD = 4800;
           }

           // on prend la nouvelle configuration
           SimpleRead();

        }                                // fin SELECT_BAUD_RATE

        if( (Code.equals("-Arr�ter-")) ){ //"-Arr�ter-"

            TThisWindows = null;
            if( (bRUN == true) &&
                ((STATUS_COMM == COM_PORT_OPEN_RUNNING)||(STATUS_COMM == COM_PORT_OPEN_IDLE)) ){
                try{
                    stopSerialCom();
                } catch(NullPointerException e){}
            }
            bRUN = false;
        }
        else{
            if( (Code.equals("D�marrer")) ){ //"D�marrer"

                  if( (bRUN == false) || (STATUS == READ_LOG_DATA_FILE_STATE) ){
                     try{
                        startSerialCom();
                     } catch (NullPointerException e){}
                  }
                  bRUN = true;
            }                                 // fin STOP
        }


        /*********************************
         * Commande Envoie d'un string
         * *******************************/
        if( (Code.equals(SEND.getActionCommand())) && (serialPort != null) ){
           String temp = new String(tfCommandLine.getText() + "\r\n");
           if(temp != null){
              taMessage.append("SEND> " + temp);
              // envoie du string dans le port serie
              try {
                 if(outputStream != null){
                    System.out.println("SEND> " + temp);
                    outputStream.write(temp.getBytes());
                 }
                 else{
                  System.out.println("outputStream NULL. Can't send any bytes");
                 }
              } catch (IOException e) {}

           }
        }

        if( Code.equals(EFFACER.getActionCommand()) ){
           EffaceText();
        }


        if(Code.equals(iOptionQuitter.getActionCommand())){ //"Quitter"
           // il ne faut pas detruire la fenetre
           this.hide();
        }

      //on update les nouvelles valeurs
      pv_UpdateFieldWnd();

      //return true;
    }                                     // fin fonction action



    public void serialEvent(SerialPortEvent event) {

        if(STATUS == READ_LOG_DATA_COM_STATE){

            switch(event.getEventType()) {
            case SerialPortEvent.BI:{
               taMessage.append("\n--- BREAK RECEIVED ---\n");
            } break;

            case SerialPortEvent.DATA_AVAILABLE:
                  STATUS_COMM = COM_PORT_OPEN_RUNNING;

                  sLineMessage = null;
                  try {
                      short numBytes = (short)inputStream.available();
                      byte readBuffer[] = new byte[numBytes];

                      if(inputStream.read(readBuffer) == numBytes){
                         sLineMessage = new String(readBuffer);

                         pv_AfficherMessage();
                         if(m_NMEA.OnNewData(readBuffer, numBytes)){
                          //sLineMessage = null;
                         }
                      }
                      else{
                         System.out.println("Invalid number of bytes received.");
                      }

                  } catch (IOException e) {
                     //System.err.println(ex);
                  }

                  break;

            default:
            break;
            }                               //  end switch
        }                               // end if   READ_LOG_DATA_COM_STATE
    }

 // /*******************************************************************
 //  * �v�nement : Capture des �v�nements
 //  *******************************************************************/
    /*public boolean handleEvent(Event evenement)
    {
       // cas du X
        if(evenement.id == Event.WINDOW_DESTROY){
           this.hide();
        }                                 // fin if

      return super.handleEvent(evenement);
    }                                     // fin fonction handleEvent
    //-------------------------------------------------------------
   */
/*******************************************************************
* Proc�dures priv�es
******************************************************************/

   private void EffaceText(){
      taMessage.setText("");
      tfCommandLine.setText("");
   }


   private void pv_listPortChoices(){

      boolean bNoPortDetec = false;
      portList = CommPortIdentifier.getPortIdentifiers();

      if( portList != null && portList.hasMoreElements() ){

         do{
            try{
               portId = (CommPortIdentifier) portList.nextElement();
            }
            catch(NoSuchElementException e){
                bNoPortDetec = true;
                STATUS_COMM = NO_PORT_DETECTED;
            }
            catch (NullPointerException e){
                bNoPortDetec = true;
                STATUS_COMM = NO_PORT_DETECTED;
            }

            if( (bPortOpen == false) && (bNoPortDetec == false) &&
                (portId.isCurrentlyOwned() == false) &&
                (portId.getPortType() == CommPortIdentifier.PORT_SERIAL) ){

                pv_portChoice.addItem(portId.getName());
                bNoPortDetec = false;
            }

         }while( portList.hasMoreElements() );
      }

      else{
         STATUS_COMM = NO_PORT_DETECTED;
         System.out.println("No port detected");
         System.out.println("Variable portList: " + portList.toString());
         if(portList == null){
            System.out.println("portList NULL");
         }
         else{
            if(portList.hasMoreElements() == false){
               System.out.println("No element in portList");
            }
         }
      }
   }

/*******************************************************************
 * Proc�dure principale
 * ****************************************************************/

   /*public static void main(String args[]){

      Terminal term = new Terminal();
      TThisWindows = new Thread(term);
      TThisWindows.start();
      term.show();
   }*/
}
