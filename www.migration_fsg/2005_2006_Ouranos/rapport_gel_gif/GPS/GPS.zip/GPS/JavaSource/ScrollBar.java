import java.awt.Scrollbar;

public class ScrollBarPage extends Scrollbar
{
  public ScrollBarPage()
  {
    super(Scrollbar.HORIZONTAL);
    setPageIncrement(2);

  }


}
