import java.awt.*;
import java.lang.*;
import java.awt.event.*;


//import symantec.itools.multimedia.ImageViewer;
//import geo.emblaze.Emblaze20;
//import symantec.itools.multimedia.ScrollingText;

public final class CAproposDlg extends java.awt.Dialog implements java.awt.event.MouseListener
{

	public CAproposDlg(Frame parent, boolean modal)
	{
		super(parent, modal);
		//{{INIT_CONTROLS
		setLayout(null);
		setVisible(false);
		setSize(375,408);
		setForeground(new Color(0));
		setBackground(new Color(0));
		setCursor(new Cursor(Cursor.HAND_CURSOR));
      /*symantec.itools.multimedia.*/
      BGImage = new ImageViewer();
		try {
			BGImage.setImageURL(symantec.itools.net.RelativeURL.getURL("Images/Rose.JPG"));
		}
		catch (java.net.MalformedURLException error) { }
		catch(java.beans.PropertyVetoException e) { }
		try {
         /*symantec.itools.multimedia.*/
         BGImage.setStyle(ImageViewer.IMAGE_NORMAL);
		}
		catch(java.beans.PropertyVetoException e) { }
		BGImage.setBounds(0,0,375,400);
		add(BGImage);
		BGImage.setCursor(new Cursor(Cursor.HAND_CURSOR));
      /*symantec.itools.multimedia.*/
      scrollingText1 = new ScrollingText();
		try {
			scrollingText1.setHiliteColor(new java.awt.Color(16777215));
		}
		catch(java.beans.PropertyVetoException e) { }
		try {
			java.lang.String[] tempString = new java.lang.String[4];
			tempString[0] = new java.lang.String("Martin Otis software designer");
			tempString[1] = new java.lang.String("GeoState beta version v.1.00b");
			tempString[2] = new java.lang.String("ICQ nick Name: HOT-ICE");
			tempString[3] = new java.lang.String("Web: http://www-edu.gel.usherb.ca/otim01/");
			scrollingText1.setMessageList(tempString);
		}
		catch(java.beans.PropertyVetoException e) { }
		scrollingText1.setBounds(0,372,375,30);
		scrollingText1.setFont(new Font("Dialog", Font.ITALIC, 14));
		scrollingText1.setForeground(new Color(16777215));
		add(scrollingText1);
		setTitle("A Propos ...");
		//}}

		//{{REGISTER_LISTENERS
		SymWindow aSymWindow = new SymWindow();
		this.addWindowListener(aSymWindow);
		addMouseListener(this);
		//}}
	}

	public void addNotify()
	{
		// Record the size of the window prior to calling parents addNotify.
		Dimension d = getSize();

		super.addNotify();

		if (fComponentsAdjusted)
			return;

		// Adjust components according to the insets
		setSize(insets().left + insets().right + d.width, insets().top + insets().bottom + d.height);
		Component components[] = getComponents();
		for (int i = 0; i < components.length; i++)
		{
			Point p = components[i].getLocation();
			p.translate(insets().left, insets().top);
			components[i].setLocation(p);
		}
		fComponentsAdjusted = true;
	}

	// Used for addNotify check.
	boolean fComponentsAdjusted = false;

	public CAproposDlg(Frame parent, String title, boolean modal)
	{
		this(parent, modal);
		setTitle(title);
	}

	public synchronized void show()
	{
		Rectangle bounds = getParent().bounds();
		Rectangle abounds = bounds();

		move(bounds.x + (bounds.width - abounds.width)/ 2,
			bounds.y + (bounds.height - abounds.height)/2);
		super.show();
	}

	public void setVisible(boolean b)
	{
		if(b)
		{
			Rectangle bounds = getParent().getBounds();
			Rectangle abounds = getBounds();
			setLocation(bounds.x + (bounds.width - abounds.width) /2 ,
				bounds.y + (bounds.height - abounds.height) / 2);
		}
	super.setVisible(b);
	}

	class SymWindow extends java.awt.event.WindowAdapter
	{
		public void windowClosing(java.awt.event.WindowEvent event)
		{
			Object object = event.getSource();
			if (object == CAproposDlg.this)
				CAproposDlg_WindowClosing(event);
		}
	}

	void CAproposDlg_WindowClosing(java.awt.event.WindowEvent event)
	{
		dispose();
	}
	//{{DECLARE_CONTROLS
   /*symantec.itools.multimedia.*/
   ImageViewer BGImage;
   /*symantec.itools.multimedia.*/
   ScrollingText scrollingText1;
	//}}

    public void mouseReleased(MouseEvent e)
    {
    }
    public void mousePressed(MouseEvent e)
    {
        dispose();
    }
    public void mouseExited(MouseEvent e)
    {
    }
    public void mouseEntered(MouseEvent e)
    {
    }
    public void mouseClicked(MouseEvent e)
    {
        dispose();
    }
}
