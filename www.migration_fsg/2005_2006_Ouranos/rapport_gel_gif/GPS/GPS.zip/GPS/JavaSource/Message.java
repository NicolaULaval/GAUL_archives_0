
public abstract class Message
{
    protected static final byte GPGGA_LEN = 14;
    protected static final byte GPGSV_LEN = 19;
    protected static final byte GPGSA_LEN = 17;
    protected static final byte GPZDA_LEN = 6;
    protected static final byte GPRMC_LEN = 11;
    protected static final byte GPGLL_LEN = 6;
    protected static final byte GPVTG_LEN = 8;
    protected static final byte GP908_LEN = 17;

    protected static final byte NULL_FIELD  =  3;
    protected static final byte MAXARG_LEN  = 30;
    protected static final byte MAXARG_NBR  = 30;
    protected static final byte MAX_NMEA_LENTH = 100;

    protected byte MsgData[][];
    protected byte Quality;


    public Message(){
        MsgData = new byte[MAXARG_NBR][MAXARG_LEN];
    }

    public Message(byte tempMsgData[][]){
        MsgData = tempMsgData;
    }

    public void m_ClearMsgData(){

        for( byte i = 0; i < MAXARG_NBR; i++){
            for( byte j = 0; j < MAXARG_LEN; j++){
                MsgData[i][j] = 0;
            }
        }
    }

    public float atof(byte pMsgData[]){
        float floatValue = 0;
        byte index = 0;
        while( (index < MAXARG_LEN) &&
               (pMsgData[index] <= 57 && pMsgData[index] >= 48) || (pMsgData[index] == 46) ){
                ++index;
        }
        if(index > 0){
            floatValue = Float.valueOf( new String(pMsgData, 0, index) ).floatValue();
        }
        else{
            floatValue = 0.0f;
        }

        return floatValue;
    }

}
