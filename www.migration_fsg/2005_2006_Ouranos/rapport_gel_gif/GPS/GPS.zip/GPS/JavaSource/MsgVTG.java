public class MsgVTG extends Message{


   float    fHeading;
   float    fSpeed;

   public MsgVTG(byte tempMsgData[][]){
      super(tempMsgData);
   }


   public void m_ProcessVTG(WayPoint ThisWpt){

      fHeading       = atof(Data[1]);
      fSpeed         = atof(Data[5]);

      ThisWpt.SetMsgVTG( new String(MsgData[0]), fSpeed, fHeading );
   }

}  // fin de la classe
