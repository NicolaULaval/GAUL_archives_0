import java.awt.*;
import java.lang.*;

public final class NMEA extends Parser{


   WayPoint NMEA_Wpt;

   MsgGLL m_MsgGLL;
   MsgVTG m_MsgVTG;
   //MsgRMC m_MsgRMC;
   //MsgZDA m_MsgZDA;
   //String sMsgData[];

   private short pv_uchRawMsgPtr;
   private short pv_uchMsgPtr;
   private short pv_uchArraySize;
   private byte  pv_uchMessage[];



   public NMEA(){
      super();
      m_MsgGLL = new MsgGLL(MsgData);
      m_MsgVTG = new MsgVTG(MsgData);
      pv_uchArraySize = MAX_NMEA_LENTH;
      pv_uchMessage = new byte[pv_uchArraySize];
      //m_MsgRMC = new MsgRMC();
      //m_MsgZDA = new MsgZDA();
      //NMEA_Wpt = new WayPoint();
      pv_uchRawMsgPtr = 0;
      pv_uchMsgPtr = 0;
      m_ClearMsgData();
   }


   public void SetActualWayPoint(WayPoint p_Wpt){
      NMEA_Wpt = p_Wpt;
   }

   //public boolean ComputeCheckSum(){ return true; }

   public boolean OnNewData(byte sMessage[], short sSizeRead){

      boolean bSuccesOperation = false;
      byte uchRawByte = 0;
      pv_uchRawMsgPtr = 0;
      //System.out.println("New Data: " + sMessage);

      if( (sSizeRead > pv_uchArraySize) ){
         ProtocolState = GETSOH;
         pv_uchArraySize = sSizeRead;
         pv_uchMessage = null;
         pv_uchMessage = new byte[pv_uchArraySize];
         System.out.println("Update size of message: " + pv_uchArraySize + "length.");
      }

      while( (pv_uchRawMsgPtr < sSizeRead) && (pv_uchRawMsgPtr < 32766) && (pv_uchMsgPtr < pv_uchArraySize) ){


         uchRawByte = sMessage[pv_uchRawMsgPtr];
         if(uchRawByte == (byte)'$'){
            ProtocolState = GETSOH;
         }

         switch(ProtocolState){
            case GETSOH:
               pv_uchMsgPtr = 0;
               if(uchRawByte == (byte)'$'){
                  //System.out.println("Header found.");
                  pv_uchMessage[pv_uchMsgPtr] = uchRawByte;
                  ProtocolState = GETDATA;
               }
               else{
                  ProtocolState = GETSOH;
               }
            break;

            case GETDATA:
               pv_uchMessage[pv_uchMsgPtr] = uchRawByte;
               //System.out.println("GetData...");
               if(uchRawByte == (byte)'\r'){
                  pv_uchMessage[++pv_uchMsgPtr] = (byte)'\n';
                  pv_uchMessage[++pv_uchMsgPtr] = 0;
                  bSuccesOperation = Dispatch(pv_uchMessage);
                  ProtocolState = GETSOH;
               }
               else{
                  if(uchRawByte == (byte)'\n'){
                     pv_uchMessage[++pv_uchMsgPtr] = 0;
                     bSuccesOperation = Dispatch(pv_uchMessage);
                     ProtocolState = GETSOH;
                  }
               }
            break;

            default:
               System.out.println("------ Error in dispatching ------");
               ProtocolState = GETSOH;
            break;
         }                              // switch case
         ++pv_uchRawMsgPtr;
         ++pv_uchMsgPtr;
      }                                 // while

      return bSuccesOperation;
   }

   private boolean Dispatch(byte sMessage[]){

      boolean bSuccesOperation = false;
      byte     iNumberOfFields  = pv_ExtractNMEAData(sMessage);

      //System.out.println("Rx :" + sMessage);
      if( pv_CompareHeader(sMessage, "GPGLL") == true ){
         //System.out.println("received GPGLL :" + sMessage);
         if( iNumberOfFields == GPGLL_LEN ){
            //System.out.println("Length " + GPGLL_LEN + " :" + sMessage);
            m_MsgGLL.m_ProcessGLL(NMEA_Wpt);
            bSuccesOperation = true;
         }
      }
      else{
        if( pv_CompareHeader(sMessage, "GPVTG") == true ){
          if( iNumberOfFields == GPVTG_LEN ){
              m_MsgVTG.m_ProcessVTG(NMEA_Wpt);
              bSuccesOperation = true;
          }
        }
         // autres messages...
      }

      return bSuccesOperation;


   }

   private boolean pv_CompareHeader(byte sMessage[], String sHeader){

      boolean bSucess = false;

      if( (sMessage[0] == '$') ){
         if(pv_uchMsgPtr >= 5){
            if( (sHeader.charAt(0) == sMessage[1]) &&
                (sHeader.charAt(1) == sMessage[2]) &&
                (sHeader.charAt(2) == sMessage[3]) &&
                (sHeader.charAt(3) == sMessage[4]) &&
                (sHeader.charAt(4) == sMessage[5])
             ){
               bSucess = true;
            }
         }
      }

      //System.out.println("Header :" + new String(tempHeader) + "End");
      return bSucess;

   }

   private byte pv_ExtractNMEAData(byte MsgBuffer[]){

      byte  iNumberFields     = 0;
      byte  StrCnt            = 0;
      byte  CntPerStr         = 0;
      short LenOfMsg          = 0;

      LenOfMsg = (short)pv_uchMsgPtr;

      for(short i = 0; (i < LenOfMsg) && (LenOfMsg < Short.MAX_VALUE) ; i++ ){
         MsgData[StrCnt][CntPerStr++] = (byte)MsgBuffer[i];

         // Error, Clear the data array if an argument is longer then MAXARG_LEN
         // or if there is mode then MAXARG_LEN arguments in the message.
         if((StrCnt > MAXARG_NBR-1) || (CntPerStr > MAXARG_LEN)) {
            m_ClearMsgData();
            iNumberFields = 0;
            i = (short)(LenOfMsg + 1);
         }

         else{
            if(MsgBuffer[i] == ','){
               MsgData[StrCnt][CntPerStr-1] = 0;
               StrCnt++;
               iNumberFields = StrCnt;
               CntPerStr = 0;
            }

            // 0x0d = 13 CR
            if(MsgBuffer[i] == 0x0d){
               MsgData[StrCnt][CntPerStr-1] = 0;
               i = LenOfMsg;
            }

         }                              // fin else
      }                                 // fin du for


      return iNumberFields;
   }                                    // fin pv_ExtractNMEAData
}  // fin classe
