public class MsgGLL extends Message{


   float    fLatitude;
   float    fLongitude;
   float    fUTCTime;

   public MsgGLL(byte tempMsgData[][]){
      super(tempMsgData);
   }


   public void m_ProcessGLL(WayPoint ThisWpt){

      fLatitude = atof(MsgData[1]);
      fLatitude      = (byte)(fLatitude/100)+ (fLatitude/100 - (byte)(fLatitude/100))*100/60;


      if( (MsgData[2][0] == (byte)'S') || (MsgData[2][0] == (byte)'s') ){
         fLatitude = -fLatitude;
      }

      fLongitude = atof(MsgData[3]);
      fLongitude     = (byte)(fLongitude/100)+ (fLongitude/100 - (byte)(fLongitude/100))*100/60;

      if( (MsgData[4][0] == (byte)'O') || (MsgData[4][0] == (byte)'o')){
         fLongitude = -fLongitude;
      }

      ThisWpt.SetPositionLLA( new String(MsgData[0]), fLatitude, fLongitude, 0.0f );
   }                                    // fin m_ProcessGLL

}  // fin de la classe
