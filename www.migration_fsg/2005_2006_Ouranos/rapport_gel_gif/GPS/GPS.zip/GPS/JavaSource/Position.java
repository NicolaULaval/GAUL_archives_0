
public abstract class Position
{
    protected float      fLatitude;
    protected float      fLongitude;
    protected float      fAltitude;
    protected short      sRefPositionX;
    protected short      sRefPositionY;
    protected short      sRefPositionZ;

    public Position(){
        fLatitude       = 0.0f;
        fLongitude      = 0.0f;
        fAltitude       = 0.0f;
        sRefPositionX   = 0;
        sRefPositionY   = 0;
        sRefPositionZ   = 0;
    }

    public Position(float fLat, float fLong, float fAlt){
        fLatitude       = fLat;
        fLongitude      = fLong;
        fAltitude       = fAlt;
    }

    public Position(short X, short Y, short Z){
        sRefPositionX   = X;
        sRefPositionY   = Y;
        sRefPositionZ   = Z;
    }

    public float CalculDistanceXYZ(PositionXYZ RefXYZ) {

        int DiffX = (RefXYZ.sRefPositionX - sRefPositionX);
        int DiffY = (RefXYZ.sRefPositionY - sRefPositionY);
        int DiffZ = (RefXYZ.sRefPositionZ - sRefPositionZ);
        int Diff3D =  (DiffX*DiffX + DiffY*DiffY + DiffZ*DiffZ);
        float DistanceXYZ = (float)Math.sqrt(Diff3D);

        return DistanceXYZ;
    }

    public float CalculDistanceLLA(PositionLLA RefLLA) {

        float ErrLat      = (float)(( RefLLA.getLat() - fLatitude )*1852*60);
        float ErrLong     = (float)( ( RefLLA.getLong() - fLongitude )*1852*60*Math.cos(fLatitude*Math.PI)/180 );
        float ErrAlt      = RefLLA.getAlt() - fAltitude;
        float Diff3D      = (float)(ErrLat*ErrLat + ErrLong*ErrLong + ErrAlt*ErrAlt);
        float DistanceLLA = (float)Math.sqrt(Diff3D);

        return DistanceLLA;
    }

}
