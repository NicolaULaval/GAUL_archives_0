import java.awt.*;
import java.lang.*;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.awt.Component;
import java.awt.event.*;
import java.io.*;


public final class GeoState extends Frame
                            implements Runnable,
                                       java.awt.event.MouseListener,
                                       java.awt.event.MouseMotionListener,
                                       java.awt.event.KeyListener,
                                       java.awt.event.ActionListener,
                                       java.awt.event.WindowListener
{
    //{{DECLARE_CONTROLS
    Thread TThisWindows;

    boolean bShowMap;
    boolean bRUN;


    Image                 imaWindows;
    //MediaTracker          tracker;
    Graphics              graphWindows;
    WayPoint              ActualPositionWpt;
    CoordonnesReference   CoordRef;
    PositionLLA           ActCurPosLLA;
    RandomAccessFile      rafLogFile;

    // Variables pour les Options
    Point                 PointOrigineGraph;
    private static short  sfrequency;  // 2 secondes
    private static short  sValueTranslation;
    String                ExtentionOption;
    String                DirectoryOption;
    private static float  fZoomFacteurValue;
    final static byte     IMAGE_BACKGROUND_ID = 0;

    // Boite de dialogue relatif au programme
    CAproposDlg           APropos;
    CUserPositionWnd      SaveActualLLA;
    boolean               bSaveActualPositionWndActive;
    Terminal              Term;
    boolean               bTerminalWndActive;

    TextField   tfZoomValue;
    Button      STOP;

	//}}
	//{{DECLARE_MENUS
	MenuBar Menub;
    Menu mMenuFichier;  // 1
    //Menu mMenuMenu;
    Menu mMenuWindows;
    //Menu mMenuSet;
    Menu mMenuAide;  // 5
    MenuItem    iOptionOuvrir;
    //MenuItem    iOptionDemarrer;
    //MenuItem    iOptionEnregistrer;
    MenuItem    iOptionQuitter;
    //MenuItem    iOption21;
    //MenuItem    iOption22;
    MenuItem    iOptionPositionActWnd;
    MenuItem    iOptionTerminal;
    //MenuItem    iOption41;
    //MenuItem    iOption42;
    MenuItem    iOptionAPropos;
	//}}

   // Constructeur de la classe
   public GeoState()
   {
        //{{INIT_CONTROLS
        setTitle("GeoState, Otis SoftWare 1999 v1.00b");
        setCursor(Frame.CROSSHAIR_CURSOR);
        setLayout(new BorderLayout());
        resize(500, 500);

        // Variables pour les Options
        PointOrigineGraph      = new Point(0,10);
        sfrequency             = 1500;  // 1 secondes
        sValueTranslation      = 30;
        ExtentionOption        = new String("*.gif;*.jpg;*.jpeg");
        DirectoryOption        = new String("C:\\GeoState\\Lac-St-Jean.jpg");
        fZoomFacteurValue      = (float)1/5;

        // Barre d'etat de la fenetre
        tfZoomValue            = new TextField("100%", 5);
        STOP                   = new Button("D�marrer");
        Panel pSud             = new Panel();

        Term                    = new Terminal();
        ActualPositionWpt       = new WayPoint();

        Term.m_NMEA.SetActualWayPoint(ActualPositionWpt);

        CoordRef                = new CoordonnesReference();
        ActCurPosLLA            = new PositionLLA();

        //tracker                 = new MediaTracker(this);
        TThisWindows            = null;

        // control du programme
        SaveActualLLA           = null;
        // fenetre active
        bSaveActualPositionWndActive   = false;
        bTerminalWndActive             = false;
        // Arr�t de toutes les taches
        // bShowMap                       = false;
        // bRUN                           = true;

        // Ouverture de l'image principale
        /*try{
            Dimension dWindowsDim = new Dimension(size());
            imaWindows = Toolkit.getDefaultToolkit().getImage(DirectoryOption);
            fZoomFacteurValue = dWindowsDim.height/((float)imaWindows.getHeight(this));
            imageUpdate(imaWindows,0,0,0,(int)(imaWindows.getWidth(this)*fZoomFacteurValue), (int)(imaWindows.getHeight(this)*fZoomFacteurValue));
            CheckCalibration(DirectoryOption);
        } catch(NullPointerException  e) {}*/

        //}}

        //{{INIT_MENUS
        // Menu principal de GEOSTATE
        Menub              = new MenuBar();

        // Les commandes principales du Menu
        mMenuFichier       = new Menu("Fichier");  // 1
        //mMenuMenu        = new Menu("Menu");
        mMenuWindows       = new Menu("Windows");
        //mMenuSet         = new Menu("Set");
        mMenuAide          = new Menu("Aide");  // 5

        // Les commandes secondaires du menub
        MenuItem    iOptionOuvrir                 = new MenuItem("Ouvrir une carte");
        //MenuItem    iOptionDemarrer               = new MenuItem("Demarrer le GPS");
        //MenuItem    iOptionEnregistrer            = new MenuItem("Enregistrer");
        MenuItem    iOptionQuitter                = new MenuItem("Quitter");
        //MenuItem    iOption21                     = new MenuItem("�diter les points de route");
        //MenuItem    iOption22                     = new MenuItem("Sauvegarder la position actuel");
        MenuItem    iOptionPositionActWnd         = new MenuItem("Position actuel");
        MenuItem    iOptionTerminal               = new MenuItem("Terminal");
        //MenuItem    iOption41                     = new MenuItem("Points de r�f�rences");
        //MenuItem    iOption42                     = new MenuItem("Options...");
        MenuItem    iOptionAPropos                = new MenuItem("� Propos...");
        //}}

		//{{REGISTER_LISTENERS
        pSud.add(STOP, 0);
        pSud.add(tfZoomValue, 1);
        //pSud.setBackground(Color.gray);
        add("South", pSud);
        // Ajout du menu
        Menub.add(mMenuFichier);
        //Menub.add(mMenuMenu);
        Menub.add(mMenuWindows);
        //Menub.add(mMenuSet);
        Menub.add(mMenuAide);
        // Ajout au menu
        mMenuFichier.add(iOptionOuvrir);
        //mMenuFichier.add(iOptionDemarrer);
        //mMenuFichier.add(iOptionEnregistrer);
        mMenuFichier.addSeparator();
        mMenuFichier.add(iOptionQuitter);
        //mMenu2.add(iOption21);
        //mMenu2.add(iOption22);
        mMenuWindows.add(iOptionPositionActWnd);
        mMenuWindows.add(iOptionTerminal);
        //mMenu4.add(iOption41);
        //mMenu4.addSeparator();
        //mMenu4.add(iOption42);
        mMenuAide.add(iOptionAPropos);
        // Affichage du Menu
        setMenuBar(Menub);
        //setMenuBar(MenuPosition);
		addMouseListener(this);
		addMouseMotionListener(this);
		addKeyListener(this);
		STOP.addActionListener(this);
		iOptionOuvrir.addActionListener(this);
		iOptionQuitter.addActionListener(this);
		iOptionTerminal.addActionListener(this);
		iOptionAPropos.addActionListener(this);
		iOptionPositionActWnd.addActionListener(this);
		addWindowListener(this);
		//}}


   }

   /************************************************************************************************
   * Ex�cution du Thread principal de la fen�tre
   ************************************************************************************************/
   public void run(){
        /*try {
            tracker.waitForID(IMAGE_BACKGROUND_ID);
	    } catch (InterruptedException e) {
	        return;
	    }*/

        while(true){
            try{
                Thread.sleep(sfrequency);
            }catch(InterruptedException ie){}

            if(bRUN == true){
                //Term.m_NMEA.SetActualWayPoint(ActualPositionWpt);
                if( (bSaveActualPositionWndActive == true) && (ActualPositionWpt != null) ){
                    SaveActualLLA.Update();
                }

                if(bShowMap == true){
                    try{
                        DrawPositionWpt();
                    }catch(NullPointerException e){}
                }
            }
        }
   }

   /************************************************************************************************
   * DrawPositionWpt
   *     Proc�dure permettant de visualiser la position en temps r�el.
   ************************************************************************************************/

  public void DrawPositionWpt() throws java.lang.NullPointerException{
      float  DeltaActualLat  = (float)0;
      float  DeltaActualLong = (float)0;
      short x = 0;
      short y = 0;


      //Trouver le point le plus pr�s pour �valuer la position actuel sur la carte
      float min = Float.MIN_VALUE;
      float max = Float.MAX_VALUE;
      byte i = 0;
      byte index = 0;

      while(i < CoordRef.SIZE){
         min = CoordRef.ActualPosition[i].CalculDistanceLLA(ActualPositionWpt.GetPositionLLA());
         if(min < max){
            max = min;
            index = i;               // point de calibration le plus proche
         }
         i++;
      }

      DeltaActualLat = (float)(CoordRef.ActualPosition[index].getLat() - ActualPositionWpt.GetLatitude());
      DeltaActualLong = (float)(CoordRef.ActualPosition[index].getLong() - ActualPositionWpt.GetLongitude());

      //Calcul de la position sur le graphique (r�gle de trois)
      y = (short)(DeltaActualLat/CoordRef.VariationLat +
                  (float)(CoordRef.PXY[index].y)*fZoomFacteurValue);

      x = (short)(DeltaActualLong/CoordRef.VariationLat +
                  (float)(CoordRef.PXY[index].x)*fZoomFacteurValue);

      ActualPositionWpt.XYActual.x = x;
      ActualPositionWpt.XYActual.y = y;

      //x = (int)((imaWindows.getWidth(this)*fZoomFacteurValue*(Math.abs(DeltaLongRef - DeltaActualLong)) -
      //    (float)PointOrigineGraph.x)/DeltaLongRef);

      // Dessine la position actuel sur le graphique si les coordonn�es sont �
      // l'int�rieur de la carte.
      if((x <= imaWindows.getWidth(this)*fZoomFacteurValue) &&
         (y <= imaWindows.getHeight(this)*fZoomFacteurValue)){
         graphWindows = getGraphics();
         graphWindows.setColor(Color.red);
         graphWindows.drawOval(x-7,y-7,14,14);
         graphWindows.fillOval(x-2,y-2,4,4);
      }

      else{
         System.out.println("Coordonn�es � l'ext�rieur de la carte.");
         // on laisse un chance au coureur...
         //bShowMap = false;
      }

  }

/*******************************************************************
 * Gestionnaire Graphique
 * ****************************************************************/

  public void update(Graphics graph)
  {
    paint(graph);
  }

  public void paint(Graphics graph)
  {
      //graph = getGraphics();
      if( (graph != null) &&
          (imaWindows != null) &&
          (bShowMap == true)){
          //try{
             //if (tracker.statusID(IMAGE_BACKGROUND_ID, false) == MediaTracker.COMPLETE) {
                /*imaWindows = imaWindows.getScaledInstance((int)(imaWindows.getWidth(this)*fZoomFacteurValue),
                                                          (int)(imaWindows.getHeight(this)*fZoomFacteurValue),
                                                          Image.SCALE_FAST);*/

                graph.drawImage(imaWindows, (int)(PointOrigineGraph.x*fZoomFacteurValue),
                                            (int)(PointOrigineGraph.y*fZoomFacteurValue),
                                            (int)(imaWindows.getWidth(this)*fZoomFacteurValue),
                                            (int)(imaWindows.getHeight(this)*fZoomFacteurValue), this);
             //}
          //}

          //catch(NullPointerException  e) {
          //   System.out.println("Pointeur nul pour dessiner le graphique.");
          //}
      }

      else{
        // presentation
        bShowMap = false;
        graph.setColor(Color.blue);
        graph.fill3DRect(0,0,20,getSize().height, false);
        graph.drawLine(25,0,25,getSize().height);
        graph.drawLine(25,100,getSize().width,100);
        //graph.fillOval(304,98,4,4);
        //graph.drawOval(300,94,12,12);
        //graph.drawLine(306,88,306,112);
        graph.setFont(new Font("Arial", Font.ITALIC, 30));
        graph.setColor(Color.cyan);
        graph.drawString("GeoState Soft", 80, 125);
        graph.setFont(new Font("Arial", Font.ITALIC, 30));
        graph.setColor(Color.blue);
        graph.drawString("GeoState Soft", 75, 120);

      }
  }

    public void actionPerformed(ActionEvent evenement){

        String Code = (String)evenement.getActionCommand();
      /*********************************
       * Commande Fichier Ouvrir
       * *******************************/

        if(Code.equals("Ouvrir une carte")){

            String Dir;
            String NomFichier;

            FileDialog OuvrirFichier = new FileDialog(this, "Ouvrir une carte...", FileDialog.LOAD);
            OuvrirFichier.setFile(ExtentionOption);
            OuvrirFichier.setDirectory(DirectoryOption);
            OuvrirFichier.show();

            Dir = new String(OuvrirFichier.getDirectory());
            NomFichier = new String(OuvrirFichier.getFile());
            setTitle("GeoState, Otis SoftWare " + NomFichier.substring(0,(NomFichier.length()-4)));

            if(NomFichier != null && Dir != null){

                if(bShowMap == true){
                    //tracker.removeImage(imaWindows, IMAGE_BACKGROUND_ID);
                    imaWindows.flush();
                    bShowMap = false;
                }
                System.out.println("Carte: " + NomFichier);
                PointOrigineGraph.x = 0;
                PointOrigineGraph.y = 15;
                fZoomFacteurValue = 1f;

                imaWindows = Toolkit.getDefaultToolkit().getImage(Dir+NomFichier);
                //tracker.addImage(imaWindows, IMAGE_BACKGROUND_ID);
                //graphWindows = imaWindows.getGraphics(); // uniquement avec createImage(w,h)
                // pour rendre l'image � la grandeur de la fenetre setScaled
                // Dimension dWindowsDim = new Dimension(size());  // la fen�tre peut �tre redimensionn�e en tout temps
                /*try {
                    tracker.waitForID(IMAGE_BACKGROUND_ID);
        	    } catch (InterruptedException e) {
	                System.out.println("Error in waiting image for loading.");
	            }*/

                //if(prepareImage(imaWindows, this) == false){
                //    System.out.println("Error in prepare image to be load.");
                //}
                //repaint();
                //Ajuste le facteur de zoom pour voir l'image au complet
                //fZoomFacteurValue = dWindowsDim.height/((float)imaWindows.getHeight(this));

                //imageUpdate(imaWindows, 0, 0, 0,
                //            (int)(imaWindows.getWidth(this)*fZoomFacteurValue), (int)(imaWindows.getHeight(this)*fZoomFacteurValue));

                bShowMap = CheckCalibration(Dir+NomFichier);
                if(bShowMap == true){
                    repaint();
                }

            }
        }                                 // end open file


        if(Code.equals("Position actuel")) {

            if(!bSaveActualPositionWndActive){
                SaveActualLLA = new CUserPositionWnd(ActualPositionWpt);
                //SaveActualLLA.SetInformationWpt();
                SaveActualLLA.setTitle("Position Actuel");
                SaveActualLLA.show();
                bSaveActualPositionWndActive = true;
            }

            else{
                bSaveActualPositionWndActive = false;
                SaveActualLLA = null;
            }
        }// end if position actuel LLA

        if(Code.equals("Terminal")){
            if(!bTerminalWndActive){
                Term.show();
                bTerminalWndActive = true;
            }

            else{
                bTerminalWndActive = false;
            }
        }  //fin terminal

        if(Code.equals("� Propos...")){
            APropos = new CAproposDlg(this, true);
            APropos.show();
        }

        if( Code.equals("Quitter") ) {
            System.exit(0);  // Fin du Programme
        }

        if( Code.equals("- Arr�ter -") || Code.equals("D�marrer") ){

            if(bRUN == true){
                STOP.setLabel("D�marrer");
                //Term.stopSerialCom();
                TThisWindows = null;
                System.out.println("Arr�t du processus en cours.");
                bRUN = false;
            }

            else{
                if(bRUN == false){
                    STOP.setLabel("- Arr�ter -");

                    try{
                        //Term.startSerialCom();
                        TThisWindows = new Thread(this, "ExecCommand");
                        if(TThisWindows != null) TThisWindows.start();
                        else System.out.println("Fail to start Thread in GeoState");
                    } catch(NullPointerException e){}
                    bRUN = true;
                }

                else{
                    System.out.println("Aucun Thread...");
                    bRUN = false;
                    bShowMap = false;
                }
            }
        }                                 //  fin STOP

    } // fin de la fonction action performed


    public void mousePressed(MouseEvent evenement){
        graphWindows = getGraphics();
        graphWindows.setColor(Color.black);
        graphWindows.fillOval(evenement.getX()-2, evenement.getY()-2, 4,4);
        graphWindows.drawOval(evenement.getX()-6, evenement.getY()-6, 12,12);
    }

    public void mouseDragged(MouseEvent evenement){
    }

    public void mouseMoved(MouseEvent evenement){

        if(bShowMap == false){
            //tfValuePositionX.setText(Float.toString((evenement.getX() - PointOrigineGraph.x)*fZoomFacteurValue));
            //tfValuePositionY.setText(Float.toString((evenement.getY() - PointOrigineGraph.y)*fZoomFacteurValue));
        }

        else{
            //PositionActuelLat = (LatRef + (Yref-Yactuel)*VariationLat)*zoom
            //variationLat = degree/pixels
            ActCurPosLLA.SetPositionLLA( ((CoordRef.ActualPosition[1].getLat() + (CoordRef.PXY[1].y-evenement.getY())*CoordRef.VariationLat*fZoomFacteurValue)),
                                         ((CoordRef.ActualPosition[1].getLong() + (CoordRef.PXY[1].x-evenement.getX())*CoordRef.VariationLong*fZoomFacteurValue)),
                                         (float)0);

            ActualPositionWpt.SetActualCursorPosition(ActCurPosLLA);
        }
    } // fin mouseMouve

    public void mouseReleased(MouseEvent evenement){

        /*CursorPositionUp.SetPosition((float)((evenement.getX - PointOrigineGraph.x)*fZoomFacteurValue),
                                     (float)((evenement.getY - PointOrigineGraph.y)*fZoomFacteurValue), 0d);

        tfValueDistance.setText(Float.toString(distance.CalculDistanceXYZ(CursorPositionUp,
                               CursorPositionDown))+
                               distance.Unites);*/
    }

    public void mouseEntered(MouseEvent evenement){
    }

    public void mouseExited(MouseEvent evenement){
    }

    public void mouseClicked(MouseEvent evenement){
    }

    public void keyPressed(KeyEvent evenement){

        Dimension dWindowsDim = new Dimension(size());
        int iKeyPressed = evenement.getKeyCode();

        if(bShowMap == false){
            tfZoomValue.setText("Carte ?");
            PointOrigineGraph.x = 0;
            PointOrigineGraph.y = 0;
        }

        else {                            // bShowMap == true

            switch(iKeyPressed){
                case KeyEvent.VK_R:{
                    FindActualWPT();
                } break;

                case KeyEvent.VK_ADD:{
                    if (fZoomFacteurValue < 5){
                       fZoomFacteurValue = fZoomFacteurValue*(10/7);
                       tfZoomValue.setText(Integer.toString((int)(100*fZoomFacteurValue)) + "%");
                       repaint();
                    }
                } break;

                case KeyEvent.VK_SUBTRACT:{
                    if(fZoomFacteurValue > 4/10){
                       fZoomFacteurValue = fZoomFacteurValue*7/10;

                       if ( (imaWindows.getWidth(this)*fZoomFacteurValue < dWindowsDim.width) ||
                             (imaWindows.getHeight(this)*fZoomFacteurValue < dWindowsDim.height)){

                          PointOrigineGraph.x = 0;
                          PointOrigineGraph.y = 0;
                       }

                       tfZoomValue.setText(Integer.toString((int)(100*fZoomFacteurValue)) + "%");
                       repaint();
                    }
                } break;

                case KeyEvent.VK_HOME:{
                    fZoomFacteurValue = 1f;
                    PointOrigineGraph.x = 0;
                    PointOrigineGraph.y = 15;
                    tfZoomValue.setText(Integer.toString((int)(100*fZoomFacteurValue)) + "%");
                    repaint();
                } break;

                case KeyEvent.VK_DOWN:{ //VK_KP_DOWN
                    if ( (imaWindows.getHeight(this)*fZoomFacteurValue > dWindowsDim.height) &&
                         (0 > PointOrigineGraph.y) ) {

                        graphWindows = getGraphics();
                        PointOrigineGraph.y += sValueTranslation;
                        paint(graphWindows);
                        //repaint();
                    }
                } break;

                case KeyEvent.VK_LEFT:{
                    if ( (imaWindows.getWidth(this)*fZoomFacteurValue > dWindowsDim.width) &&
                         (Math.abs(imaWindows.getWidth(this)*fZoomFacteurValue - dWindowsDim.width)
                         > Math.abs(PointOrigineGraph.x)) ) {

                        graphWindows = getGraphics();
                        PointOrigineGraph.x += -sValueTranslation;
                        paint(graphWindows);
                        //repaint();
                    }
                } break;

                case KeyEvent.VK_RIGHT:{
                    if ( (imaWindows.getWidth(this)*fZoomFacteurValue > dWindowsDim.width) &&
                         (0 > PointOrigineGraph.x) ) {

                        graphWindows = getGraphics();
                        PointOrigineGraph.x += sValueTranslation;
                        paint(graphWindows);
                        //repaint();
                    }
                } break;

                case KeyEvent.VK_UP:{
                    if ( (imaWindows.getHeight(this)*fZoomFacteurValue > dWindowsDim.height) &&
                         (Math.abs(imaWindows.getHeight(this)*fZoomFacteurValue - dWindowsDim.height)
                          > Math.abs(PointOrigineGraph.y)) ) {

                        graphWindows = getGraphics();
                        PointOrigineGraph.y += -sValueTranslation;
                        paint(graphWindows);
                        //repaint();
                    }
                } break;

                default:{}break;
            }
        }// ELSE BSHOWMAP
    }

    public void keyTyped(KeyEvent evenement){
    }
    public void keyReleased(KeyEvent evenement){
    }
	public void windowClosing(java.awt.event.WindowEvent event)
	{
		System.exit(0);
	}
    public void windowOpened(java.awt.event.WindowEvent event){}
    public void windowClosed(java.awt.event.WindowEvent event){}
    public void windowIconified(java.awt.event.WindowEvent event){}
    public void windowDeiconified(java.awt.event.WindowEvent event){}
    public void windowActivated(java.awt.event.WindowEvent event){
        repaint();
    }
    public void windowDeactivated(java.awt.event.WindowEvent event){}

 /**************************************************************************************************
 * Lecture d'une valeur entr�e au clavier
 **************************************************************************************************/

   public String ReadValue() throws java.io.IOException{

      String S = new String();
      char C;

      while ( (C = (char)System.in.read()) != '\n' ) {
         S=S+C;
      }

      return S;
   }

 /**************************************************************************************************
 * Lecture de la calibration de la carte
 **************************************************************************************************/
   public boolean CheckCalibration(String File){

         String NomFichierData;

         NomFichierData = new String(File.substring(0,(File.length()-4))+".eta");
         System.out.println("Calibration: " + File.substring(0,(File.length()-4))+ ".eta");


         try{
            String Line;
            boolean bEOF = false;
            boolean bDMS = false;
            boolean bGoodLine = false;
            float dDegrees = (float)0;
            rafLogFile = new RandomAccessFile(NomFichierData, "r");

            System.out.println("Informations: " + rafLogFile);

            // Lecture du fichier de calibration
            while(!bEOF){
               Line = rafLogFile.readLine();
               if(Line == null){
                  bEOF = true;
               }

               else{
                  if(Line.startsWith("LAT/LON")){
                     bGoodLine = true;

                     if(Line.substring(23,26).equals("DMS")){
                        bDMS = true;
                        System.out.println("Format standard Degrees, minutes, secondes");
                     }
                     else{
                        if(Line.substring(23,25).equals("DM")){
                           System.out.println("Format Degrees, minutes");
                        }
                        else{
                           bGoodLine = false;
                           bEOF = true;
                           System.out.println("Format de coordonnees invalide");
                        }               // fin format invalide
                     }                  // fin DM ou DMS
                  }                     // fin LAT/LON

                  if(Line.startsWith("GRILLE UTM")) bGoodLine = false;
               }

               if(bGoodLine){
                  //Lecture de chaque point de calibration
                  System.out.println(Line);

                  for(byte i = 0; i < CoordRef.SIZE; i++){
                     //Signe positif sur l'altitude et la longitude
                     //Extraction de la longitude
                     Line = rafLogFile.readLine();
                     System.out.println(Line);

                     dDegrees = m_ExtractNumber(Line, 0);
                     if(bDMS){
                              dDegrees = (float)(dDegrees + m_ExtractNumber(Line, 8)/60.0f);
                              dDegrees = (float)(dDegrees + m_ExtractNumber(Line, 13)/3600.0f);
                     }
                     else     dDegrees = (float)(dDegrees + m_ExtractNumber(Line, 7)/60.0f);
                     if ( Line.charAt(0) == 'W' )  dDegrees = -dDegrees;

                     CoordRef.SetLongReference(dDegrees, i);
                     System.out.println(Float.toString(dDegrees) + " Deg.");

                     //Extraction de la latitude
                     Line = rafLogFile.readLine();
                     System.out.println(Line);

                     dDegrees = m_ExtractNumber(Line, 2);
                     if(bDMS){
                              dDegrees = (float)(dDegrees + m_ExtractNumber(Line, 7)/60.0f);
                              dDegrees = (float)(dDegrees + m_ExtractNumber(Line, 12)/3600.0f);
                     }
                     else     dDegrees = (float)(dDegrees + m_ExtractNumber(Line, 6)/60.0f);
                     if ( Line.charAt(0) == 'S' )  dDegrees = -dDegrees;

                     CoordRef.SetLatReference(dDegrees, i);
                     System.out.println(Float.toString(dDegrees) + " Deg.");

                     //Extraction de X
                     Line = rafLogFile.readLine();
                     System.out.println(Line);
                     CoordRef.PXY[i].x = (int)m_ExtractNumber(Line, 0);

                     //Extraction de Y
                     Line = rafLogFile.readLine();
                     System.out.println(Line);
                     CoordRef.PXY[i].y = (int)m_ExtractNumber(Line, 0);

                  }
               }
            }


            bShowMap = true;
            CoordRef.CalculVariationReference();
            System.out.println("Variation lat.  : " + Float.toString(CoordRef.VariationLat));
            System.out.println("Variation long. : " + Float.toString(CoordRef.VariationLong));
            bRUN = true;                // Pas bon, seulement qu'avec le boutton demarrer
            System.out.println("Carte active");
            tfZoomValue.setText(Integer.toString((int)(100*fZoomFacteurValue)) + "%");


         }

         catch(IOException e){
            bShowMap = false;
            bRUN = false;
            System.out.println("Exception at reading file GeoState: Ouvrir une carte.");
         }

         return bShowMap;
   }                                    // Fin calibration

   public float m_ExtractNumber(String sLine, int iPos){

        byte           iLength            = (byte)(sLine.length() - iPos);
        boolean        bFindNumber        = false;
        float          dNumberFind        = 0.0f;
        final byte     fiSize             = 10;
        char[]         chNumber           = new char[fiSize];
        byte           iIndexNumber       = 0;
        byte           iCompare           = 0;
        String         sNumber;

        // on enleve les char inutiles au debut
        iCompare = (byte)sLine.charAt(iPos);
        while( ( iCompare <= 48 || iCompare > 57 ) &&
               (iPos <= iLength) ){

            ++iPos;
            iCompare = (byte)sLine.charAt(iPos);
        }

        // on extrait le nombre
        while( (iPos <= iLength) &&
             (bFindNumber == false) &&
             (fiSize > iIndexNumber)){

            iCompare = (byte)sLine.charAt(iPos++);

            if( ( iCompare >= 48 && iCompare <= 57 )||(iCompare == 46) ){
                chNumber[iIndexNumber++] = (char)iCompare;
            }
            else{
                sNumber = new String(chNumber, 0, iIndexNumber);
                if(m_FindChar(sNumber, '.') == true){
                    dNumberFind = Float.valueOf(sNumber).floatValue();
                }
                else{
                    dNumberFind = (float)Integer.valueOf(sNumber).intValue();
                }
                bFindNumber = true;
            }
        }

        return dNumberFind;

   } // fin extract number

 /**************************************************************************************************
 * Trouve une suite de caract�res
 **************************************************************************************************/

   public boolean FindChars(char Reference[], int lenRef, char Compare[], int lenComp){
      boolean Sucess = false;
      boolean first = false;
      int i = 0;
      int j = 0;

      if(lenRef <= lenComp) Sucess = false;
      else{

         while ( (i < lenRef) && (j < lenComp) ) {

            //Trouve le premier caract�re
            while ( (i < lenRef) && (first == false)) {
               if(Reference[i] == Compare[j]) first = true;
               i++;
            }

            //compare la suite
            while ( (j < lenComp) && (Sucess == true) && (i < lenRef)) {
               j++;
               if(Reference[i] == Compare[j]) Sucess = true;
               else Sucess = false;
               i++;
            }

            i++;
         }                              // fin de la comparaison
      }                                 // fin else

      return Sucess;
   }

    public boolean m_FindChar(String sLine, char chComp){

        int iLength = sLine.length();
        boolean bFindChar = false;

        for(int i = 0; i < iLength && bFindChar == false; i++){
            if( sLine.charAt(i) == chComp ) bFindChar = true;
        }

        return bFindChar;

    }
/*******************************************************************
 * Fonction recherche du Waypoint
 *    But: trouver le point d'origine de la carte qui
 *         correspond le mieux et redessiner la carte pour
 *         voir le WPT
 *
 *          On suppose � 0,0 l'image dans la fen�tre
 *          Activ� par la cl� r (recherche)
 ******************************************************************/
   public void FindActualWPT(){

      graphWindows = getGraphics();
      fZoomFacteurValue = (float)1;
      Dimension dWindowsDim = new Dimension(getSize());  // la fen�tre peut �tre redimensionn�e en tout temps
      int imaX = imaWindows.getWidth(this);
      int imaY = imaWindows.getHeight(this);
      float step = 2/10;
      float diviseurX = 2.0f;
      float diviseurY = 2.0f;

      int maxTransX = (int)(Math.abs((float)(imaX)*fZoomFacteurValue  - (float)dWindowsDim.width)); //- PointOrigineGraph.x;
      int maxTransY = (int)(Math.abs((float)(imaY)*fZoomFacteurValue -  (float)dWindowsDim.height)); //- PointOrigineGraph.y;
      int b = (ActualPositionWpt.XYActual.x-dWindowsDim.width);
      int a = (ActualPositionWpt.XYActual.y-dWindowsDim.height);

      //V�rifier si le WPT est visible, dans la fen�tre
      if(a > 0 && b > 0){
         //Pas visible, calcul de la meilleur translation

         while(((float)dWindowsDim.width/diviseurX + (float)b) > maxTransX){
            diviseurX = diviseurX-step;
         }
         while(((float)dWindowsDim.height/diviseurY + (float)a) > maxTransY){
            diviseurY = diviseurY-step;
         }

         //Nouvelle Position d'origine
         PointOrigineGraph.x = (int)((float)(dWindowsDim.width)/diviseurX  + (float)b);
         PointOrigineGraph.y = (int)((float)(dWindowsDim.height)/diviseurY + (float)a);
         //Redessiner la carte
         paint(graphWindows);
         System.out.println("Recherche termin�e avec succ�s");

      }

      else{
         System.out.println("Le point est visible");
         paint(graphWindows);
      }
      //Si visible, fin de la fonction

   }


/*******************************************************************
 * Procedure principale
 ******************************************************************/
 //, java.awt.event.MouseListener, java.awt.event.MouseMotionListener, KeyListener

    //class CMouseListener extends java.awt.event.MouseListener{}
    //class CMouseMotionListener extends java.awt.event.MouseMotionListener{}
    //class CKeyListener extends java.awt.event.KeyListener{}
    //class CGeoStateWindow extends java.awt.event.WindowAdapter{}

    public static void main(String args[])
    {

        GeoState GState = new GeoState();
        GState.show();
    }
}  // fin goestate
