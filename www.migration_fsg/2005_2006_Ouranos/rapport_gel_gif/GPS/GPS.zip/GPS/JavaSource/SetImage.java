import java.awt.*;

public class SetImage extends
{
  Image iImageBack;

  // Acquiaition de l'image
  public SetImage(Frame mainFrame)
  {
    super(mainFrame);
    iImageBack = getImage("C:\\prog\\java\\", "brune.jpeg");
  }

  // Affichage de l'image
  public void paint(Graphics PlotThis)
  {
    // Lecture des dimensions de l'image
    int iLargeur = iImageBack.getWidth(this);
    int iHauteur = iImageBack.getHeight(this);

    // Affichage de l'image
    PlotThis.drawImage(iImageBack, 10, 10, this);

  }
}


