import java.awt.*;
import java.lang.*;

public class HourSystem {

  int iHour;
  int iDegrees;
  int iMinutes;
  double dSeconds;

  double dValueInSeconds;

  public HourSystem(double dValue){
    dValueInSeconds = dValue;
    SetDegrees();
  }

  public void SetHourSystem(){
     iHour = (int)(dValueInSeconds/3600);
     iDegrees = (int)dValueInSeconds;
     iMinutes = (int)(dValueInSeconds/60 - iHour*60);
     dSeconds = (dValueInSeconds - iHour*3600 - iMinutes*60);
  }

  public void SetDegrees(){
     iDegrees = (int)dValueInSeconds;
     iMinutes = (int)((dValueInSeconds - iDegrees)*60);
     dSeconds = 3600*(dValueInSeconds - (double)iDegrees - (double)iMinutes/60);
  }

  public double SetALLinSeconds(){
     dValueInSeconds = (iHour*3600 + iMinutes*60 + dSeconds);
     return dValueInSeconds;
  }


}
