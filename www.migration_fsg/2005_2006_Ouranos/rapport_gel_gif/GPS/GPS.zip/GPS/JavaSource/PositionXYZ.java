import java.awt.*;
import java.lang.*;

public class PositionXYZ extends Position {

  public PositionXYZ(short X, short Y, short Z){
     super(X, Y, Z);
  }

  public PositionXYZ(){
     super(0, 0, 0);
  }

  public void SetPosition(short X, short Y, short Z){
     sRefPositionX = X;
     sRefPositionY = Y;
     sRefPositionZ = Z;
  }

  public float GetPositionX(){ return sRefPositionX; }
  public float GetPositionY(){ return sRefPositionY; }
  public float GetPositionZ(){ return sRefPositionZ; }
  public PositionXYZ GetPosition(){ return this; }

}
