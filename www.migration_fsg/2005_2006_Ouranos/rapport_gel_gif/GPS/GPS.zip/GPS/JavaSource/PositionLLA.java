import java.awt.*;
import java.io.*;
import java.lang.*;

public class PositionLLA extends Position {

   boolean     bSuccesOperation = false;

   public PositionLLA(float fLat, float fLong, float fAlt){
      super(fLat, fLong, fAlt);
   }

   public PositionLLA(){
      super(0.0f,0.0f,0.0f);
   }

   public PositionLLA(PositionLLA Pos){
      fLatitude   = Pos.fLatitude;
      fLongitude  = Pos.fLongitude;
      fAltitude   = Pos.fAltitude;
   }


   public float getLat()    { return fLatitude;    }
   public float getLong()   { return fLongitude;   }
   public float getAlt()    { return fAltitude;    }
   public PositionLLA getPosition() { return this; }

   public void SetPositionLLA(float Lat, float fLong, float Alt){
      fLatitude    = Lat;
      fLongitude   = fLong;
      fAltitude    = Alt;
   }

   public void SetPositionLat(float Lat){
      fLatitude = Lat;
   }

   public void SetPositionLong(float fLong){
      fLongitude = fLong;
   }

   public void SetAltiutde(float Altitude){
      fAltitude = Altitude;
   }


   /*public boolean SetLatitude(int iDegrees, int iMinutes, float dSeconds, char chSystem){
      bSuccesOperation = true;

      dLatitude = ((float)(iDegrees) + ((float)iMinutes/60) + ((float)dSeconds/3600));
      if(chSystem == 'S'){
         dLatitude = dLatitude*(-1);
      }

      return bSuccesOperation;
   }

   public boolean SetLongitude(int iDegrees, int iMinutes, float dSeconds, char chSystem){
      bSuccesOperation = false;

      dLongitude = ((float)(iDegrees) + ((float)iMinutes/60) + ((float)dSeconds/3600));
      if(chSystem == 'O'){
         dLongitude = dLongitude*(-1);
      }

      return bSuccesOperation;
   }*/

}
