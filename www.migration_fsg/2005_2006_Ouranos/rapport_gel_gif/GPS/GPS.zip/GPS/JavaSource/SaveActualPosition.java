import java.awt.*;
import java.awt.GridBagLayout;
import java.lang.*;


public class SaveActualPosition extends Frame {


  Button Enregistrer;
  Button Annuler;

  WayPoint Position;

  // Affiche la latitude
  Label Latitude;
  TextField LatDegrees;
  TextField LatMinutes;
  TextField LatSeconds;

  // Affiche la longitude
  Label Longitude;
  TextField LongDegrees;
  TextField LongMinutes;
  TextField LongSeconds;

  // Affiche l'altitude
  Label lAltitude;
  TextField tfAltitude;

  Label lName;
  TextField tfName;

  GridBagLayout gbFrame; // = new GridBagLayout();
  GridBagConstraints gbC; // = new GridBagConstraints();

  public SaveActualPosition(){

         //super(frame, "Sauvegarde de la position actuel...", true);
       setTitle("Sauvegarde de la position actuel...");
       resize(350,250);
        //pack();
        //setResizable(true);

       gbFrame = new GridBagLayout();
       gbC = new GridBagConstraints();

       // Pannel de la fen�tre
       Panel pBoutton = new Panel();
       Enregistrer = new Button("Enregistrer");
       Annuler = new Button("Annuler");

       //Panel pLatitude = new Panel();
       //pLatitude.setBackground(Color.white);
       //Panel pLongitude = new Panel();
       //pLongitude.setBackground(Color.white);
       //Panel pAltitude = new Panel();
       //pAltitude.setBackground(Color.white);

       Panel pName = new Panel();
       GridBagLayout gbLayout = new GridBagLayout();
       GridBagConstraints gcLayout = new GridBagConstraints();
       //setLayout(gbFrame);
       gcLayout.anchor = GridBagConstraints.NORTHWEST;
       gcLayout.insets = new Insets(8,8,8,8);
       gcLayout.fill = GridBagConstraints.BOTH;
       gcLayout.gridwidth = GridBagConstraints.REMAINDER;
       gcLayout.weightx = 1.0;
       gcLayout.weighty = 0.2;

       pName.setLayout(gbLayout);
       pName.setBackground(Color.white);

       Panel pValue = new Panel();
       pValue.setLayout(gbLayout);
       pValue.setBackground(Color.white);

       Label UnitDegLat = new Label("\u00b0");
       Label UnitMinLat = new Label("\u0060");
       Label UnitSecLat = new Label("\"");
       Label UnitDegLong = new Label("\u00b0");
       Label UnitMinLong = new Label("\u0060");
       Label UnitSecLong = new Label("\"");
       Label UnitMetric = new Label("m\u00e8tres");

       //TextField.setEditable(true);
       setLayout(gbFrame);
       gbC.anchor = GridBagConstraints.NORTHWEST;
       gbC.insets = new Insets(4,4,4,4);
       gbC.fill = GridBagConstraints.BOTH;
       gbC.weightx = 1.0;
       gbC.weighty = 0.2;
       //setLayout(new FlowLayout());
       setBackground(Color.blue);
       setFont(new Font("Helvetica", Font.BOLD, 16));


       // Affiche la latitude
       Latitude = new Label("Latitude", Label.LEFT);
       gbLayout.setConstraints(Latitude ,gbC);
       LatDegrees = new TextField(2);
       LatMinutes = new TextField(2);
       LatSeconds = new TextField(4);
       //gbFrame.setConstraints(pBoutton ,gbC);


       // Affiche la longitude
       Longitude = new Label("Longitude", Label.LEFT);
       gbLayout.setConstraints(Longitude ,gbC);
       LongDegrees = new TextField(2);
       LongMinutes = new TextField(2);
       LongSeconds = new TextField(4);


       // Affiche l'altitude
       lAltitude = new Label("Altitude", Label.LEFT);
       gbLayout.setConstraints(lAltitude ,gbC);
       tfAltitude = new TextField(5);

       // Affiche le nom du waypoint
       lName = new Label("Nom", Label.LEFT);
       gbLayout.setConstraints(lName ,gbC);
       tfName = new TextField(10);
       tfName.setEditable(true);
       tfName.selectAll();
       tfName.requestFocus();

       // Disposition des informations
        // premiere ligne
       // gbFrame.setConstraints(Latitude, gbC);

        pName.add(Latitude);
        gbLayout.setConstraints(Latitude, gcLayout);
        pName.add(Longitude);
        gbLayout.setConstraints(Longitude, gcLayout);
        pName.add(lAltitude);
        gbLayout.setConstraints(lAltitude, gcLayout);
        pName.add(lName);
        gbLayout.setConstraints(lName, gcLayout);

        pValue.add(LatDegrees);
        pValue.add(UnitDegLat);
        pValue.add(LatMinutes);
        pValue.add(UnitMinLat);
        pValue.add(LatSeconds);
        pValue.add(UnitSecLat);
        gbLayout.setConstraints(UnitSecLat, gcLayout);
        //add(pLatitude);

        // 2 ligne
        //pLongitude.add(Longitude);
        pValue.add(LongDegrees);
        pValue.add(UnitDegLong); //add(new Label("\u00b0"));
        pValue.add(LongMinutes);
        pValue.add(UnitMinLong); //add(new Label("\u0060"));
        pValue.add(LongSeconds);
        pValue.add(UnitSecLong); //add(new Label("\""));
        gbLayout.setConstraints(UnitSecLong, gcLayout);

        //gbC.gridwidth = GridBagConstraints.REMAINDER;
        //gbFrame.setConstraints(pLongitude, gbC);
        //add(pLongitude);

        // 3 ligne
        //pAltitude.add(lAltitude);
        pValue.add(tfAltitude);
        pValue.add(UnitMetric);
        gbLayout.setConstraints(UnitMetric, gcLayout);

        //gbC.gridwidth = GridBagConstraints.REMAINDER;
        //gbFrame.setConstraints(pAltitude, gbC);
        //add(pAltitude);

        // 4 ligne
        //pName.add(lName);
        pValue.add(tfName);
        gbLayout.setConstraints(tfName, gcLayout);

        gbC.gridwidth = GridBagConstraints.REMAINDER;
        gbFrame.setConstraints(pValue, gbC);
        add(pName);
        add(pValue);

        pBoutton.add(Enregistrer);
        pBoutton.add(Annuler);

        gbC.gridwidth = GridBagConstraints.CENTER;
        gbFrame.setConstraints(pBoutton, gbC);
        add(pBoutton);

  }

  public void SetInformation(double Lat, double Long, float Alt){
    Position = new WayPoint("Entrer un nom", Lat, Long, Alt);
    tfName.setText("");
    tfName.setEditable(true);

    tfAltitude.setText(Float.toString(Position.WayPtPositionLLA.fAltitude));

    LatDegrees.setText(Integer.toString(Position.WayPtPositionLLA.Latitude.iDegrees));
    LatMinutes.setText(Integer.toString(Position.WayPtPositionLLA.Latitude.iMinutes));
    LatSeconds.setText(Double.toString(Position.WayPtPositionLLA.Latitude.dSeconds));
    LongDegrees.setText(Integer.toString(Position.WayPtPositionLLA.Longitude.iDegrees));
    LongMinutes.setText(Integer.toString(Position.WayPtPositionLLA.Longitude.iMinutes));
    LongSeconds.setText(Double.toString(Position.WayPtPositionLLA.Longitude.dSeconds));

  }

/*******************************************************************
 * Gestionnaire d'�venement de la classe Dialogue
 * ****************************************************************/

  public boolean action(Event evenement, Object argument, Frame frame)
  {

    //String Code = (String)argument;

    return true;
  }                                     // fin fonction action

/*******************************************************************
 * �v�nement : Capture des �v�nements
 *******************************************************************/

/*******************************************************************
 * �v�nement : Capture des �v�nements
 *******************************************************************/

  public boolean handleEvent(Event evenement)
  {
     // cas du X
    if(evenement.id == Event.WINDOW_DESTROY){
      dispose();

    }                                   // fin if

    // Cas de la boite de dialogue � Propos
    if(evenement.target == Annuler){
      dispose();
    }

    if(evenement.target == Enregistrer){

    }

      return(true);
  }                                     // fin fonction handleEvent
}
