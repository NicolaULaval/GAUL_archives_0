import java.awt.*;
import java.io.*;

public class EdText3 extends Frame
{
  // La zone de texte de l'�diteur de texte
  TextArea texte = new TextArea();  // La zone de texte de l'�diteur de texte
  String Nom;                       // Le nom s�lectionn� dans la bo�te de dialogue
  String Dir;                       // Le dossier s�lectionn� dans la bo�te de dialogue
  File fichier;                     // Le nom complet du fichier

  EdText3()
  // ---------------------------------------------------------------
  // Constructeur de la classe EdText.
  // D�finition et affichage de la bo�te de dialogue
  // ---------------------------------------------------------------
  {
    // Titre de la fen�tre et zone de texte
    super("Editeur de texte");
    add("Center", texte);

    // D�finition et affichage du syst�me de menus
    MenuBar mb = new MenuBar();
    Menu m1 = new Menu("&Fichier");
    mb.add(m1);
    MenuItem i11 = new MenuItem("&Ouvrir");
    MenuItem i12 = new MenuItem("&Enregistrer");
    MenuItem i13 = new MenuItem("&Quitter");
    m1.add(i11);
    m1.add(i12);
    m1.add(i13);
    setMenuBar(mb);

    // Taille par d�faut de la frame
    resize(250,300);

    pack();
  }

  public boolean action(Event evt, Object arg)
  // -------------------------------------------------
  // Capture des �v�nements li�s au syste�me de menus
  // -------------------------------------------------
  {
    if (evt.target instanceof MenuItem)
    {
      String Cde = (String)arg;

      // - - - - - - - - - - - - -
      // Commande Fichier/Ouvrir
      // - - - - - - - - - - - - -
      if (Cde.equals("&Ouvrir"))
      {
        FileDialog f = new FileDialog(this, "Ouvrir", FileDialog.LOAD);
        f.show();
        String Nom = f.getFile();
        String Dir = f.getDirectory();
        fichier = new File(Dir, Nom);
        try
        {
          FileInputStream fis = new FileInputStream(Dir+Nom);
          byte b[] = new byte[fis.available()];
          fis.read(b);
          texte.setText(new String(b,0));
          fis.close();
        }
        catch (IOException e)
        {
        }
      }

      // - - - - - - - - - - - - - - - -
      // Commande Fichier/Enregistrer
      // - - - - - - - - - - - - - - - -
      if (Cde.equals("&Enregistrer"))
      {

        try
        {
          fichier.delete();
          FileOutputStream fos = new FileOutputStream(fichier);
          String s = texte.getText();
          int l = s.length();
          byte bw[] = new byte[l];
          for (int i=0; i<l; i++)
            bw[i] = (byte) s.charAt(i);
          fos.write(bw);
          fos.close();
        }
        catch (IOException e)
        {
        }
      }

      // - - - - - - - - - - - - -
      // Commande Fichier/Quitter
      // - - - - - - - - - - - - -
      if (Cde.equals("&Quitter"))
      {
        System.exit(0);
      }
     }
    return(true);
  }


  public boolean handleEvent(Event evt)
  // --------------------------------------------------------
  // Capture de l'�v�nement "Appui sur la case de fermeture"
  // --------------------------------------------------------
  {
    if (evt.id == Event.WINDOW_DESTROY)
    {
      System.exit(0);
      return(true);
    }
    return super.handleEvent(evt);
  }


  public static void main(String args[]) 
  // ------------------------------------------------
  // D�finition d'une frame pour l'application et
  // affichage de la bo�te de dialogue
  // ------------------------------------------------
  {
    EdText3 e = new EdText3();
    e.show();
  }
}
