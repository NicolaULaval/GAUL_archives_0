
public abstract class Parser extends Message
{
    protected static final byte GETSOH = 0;
    protected static final byte GETDATA = 1;
    protected static byte ProtocolState = GETSOH;

    public Parser(){
        super();
    }

    public abstract boolean OnNewData(String sMessage, short sSizeRead);
}
