import java.awt.*;
import java.awt.GridBagLayout;
import java.lang.*;


public class CUserPositionWnd extends Frame implements java.awt.event.WindowListener{

    final short  TOPBORDER_ROW             = 50;
    final short  TOBBORDER_INCREMENT       = 20;
    final short  TOPBORDER_COLON           = 20;
    final short  TOPBORDER_COLON_FIELDS    = 200;

    final short STATIC_LATITUDE           = TOPBORDER_ROW;
    final short STATIC_LONGITUDE          = 1*TOBBORDER_INCREMENT +TOPBORDER_ROW;
    final short STATIC_DIRECTION          = 2*TOBBORDER_INCREMENT +TOPBORDER_ROW;
    final short STATIC_VITESSE            = 3*TOBBORDER_INCREMENT +TOPBORDER_ROW;
    final short STATIC_CURSOR             = 5*TOBBORDER_INCREMENT +TOPBORDER_ROW;
    final short STATIC_LAT_CURSOR         = 6*TOBBORDER_INCREMENT +TOPBORDER_ROW;
    final short STATIC_LONG_CURSOR        = 7*TOBBORDER_INCREMENT +TOPBORDER_ROW;
    final short STATIC_DISTANCE           = 8*TOBBORDER_INCREMENT +TOPBORDER_ROW;

    private byte       pv_iDegrees      = 0;
    private byte       pv_iMinutes      = 0;
    private float      pv_fSeconds      = 0.0f;

    private short SizeWndX = 0;
    private short SizeWndY = 0;
    private char  chCardinalPoint;

    private WayPoint pv_PositionWpt;

    public CUserPositionWnd(WayPoint ptr_Wpt){
        setFont(new Font("Helvetica", Font.BOLD, 16));
        setBackground(new Color(50,50,100));
        setSize(350, 280);
        pv_PositionWpt = ptr_Wpt;
        addWindowListener(this);
    }

    public void paint(Graphics graph)
    {
        graph.setColor(Color.white);
        graph.fill3DRect(0,0,15, (short)SizeWndY, false);
        graph.drawLine(17,0,17, (short)SizeWndY);
        graph.drawLine(17,STATIC_CURSOR+2,(short)SizeWndX,STATIC_CURSOR+2);
        UpdateStaticFiledsWnd(graph);
        UpdateFieldsWnd(graph);
    }

    private void UpdateStaticFiledsWnd(Graphics graph){

        graph.setColor(Color.white);
        graph.setFont(new Font("Arial", Font.ITALIC, 16));
        graph.drawString("Latitude",            TOPBORDER_COLON, STATIC_LATITUDE);
        graph.drawString("Longitude",           TOPBORDER_COLON, STATIC_LONGITUDE);
        graph.drawString("Direction",           TOPBORDER_COLON, STATIC_DIRECTION);
        graph.drawString("Vitesse",             TOPBORDER_COLON, STATIC_VITESSE);

        graph.setFont(new Font("Arial", Font.BOLD, 16));
        graph.drawString("Position du curseur", TOPBORDER_COLON, STATIC_CURSOR);

        graph.setFont(new Font("Arial", Font.ITALIC, 16));
        graph.drawString("Latitude",            TOPBORDER_COLON, STATIC_LAT_CURSOR);
        graph.drawString("Longitude",           TOPBORDER_COLON, STATIC_LONG_CURSOR);
        graph.drawString("Distance",            TOPBORDER_COLON, STATIC_DISTANCE);

    }

    private void UpdateFieldsWnd(Graphics graph){

      graph.setColor(Color.white);
      graph.setFont(new Font("Helvetica", Font.BOLD, 17));

      pv_fSeconds = pv_PositionWpt.GetLatitude();
      if(pv_fSeconds >= 0){
         chCardinalPoint = 'N';
      } else {
         chCardinalPoint = 'S';
         pv_fSeconds = -pv_fSeconds;
      }
      CalculLLADMS(pv_fSeconds);

      graph.drawString(chCardinalPoint + " " + pv_iDegrees + "\u00b0" + pv_iMinutes + "\u0060" + pv_fSeconds + "\"",
                       TOPBORDER_COLON_FIELDS, STATIC_LATITUDE);

      pv_fSeconds = pv_PositionWpt.GetLongitude();
      if(pv_fSeconds >= 0){
         chCardinalPoint = 'E';
      } else {
         chCardinalPoint = 'O';
         pv_fSeconds = -pv_fSeconds;
      }
      CalculLLADMS(pv_fSeconds);
      graph.drawString(chCardinalPoint + " " + pv_iDegrees + "\u00b0" + pv_iMinutes + "\u0060" + pv_fSeconds + "\"",
                       TOPBORDER_COLON_FIELDS, STATIC_LONGITUDE);

      graph.drawString(pv_PositionWpt.m_fDirection + "\u00b0",   TOPBORDER_COLON_FIELDS,STATIC_DIRECTION);
      graph.drawString(pv_PositionWpt.m_fVitesse + " Noeuds",     TOPBORDER_COLON_FIELDS,STATIC_VITESSE);


      pv_fSeconds = pv_PositionWpt.GetCursorLat();
      if(pv_fSeconds >= 0){
         chCardinalPoint = 'N';
      } else {
         chCardinalPoint = 'S';
         pv_fSeconds = pv_fSeconds*(-1.0f);
      }
      CalculLLADMS(pv_fSeconds);
      graph.drawString(chCardinalPoint + " " + pv_iDegrees + "\u00b0" + pv_iMinutes + "\u0060" + pv_fSeconds + "\"",
                       TOPBORDER_COLON_FIELDS, STATIC_LAT_CURSOR);

      pv_fSeconds = pv_PositionWpt.GetCursorLong();
      if(pv_fSeconds >= 0){
         chCardinalPoint = 'E';
      } else {
         chCardinalPoint = 'O';
         pv_fSeconds = pv_fSeconds*(-1.0f);
      }
      CalculLLADMS(pv_fSeconds);
      graph.drawString(chCardinalPoint + " " + pv_iDegrees + "\u00b0" + pv_iMinutes + "\u0060" + pv_fSeconds + "\"",
                       TOPBORDER_COLON_FIELDS, STATIC_LONG_CURSOR);

      graph.drawString(pv_PositionWpt.m_fDistance + " M�tres",    TOPBORDER_COLON_FIELDS,STATIC_DISTANCE);

    }

    /*public void SetInformationLLA(double Lat, double dLong, float Alt){
        repaint(TOPBORDER_COLON_FIELDS,
                STATIC_LATITUDE - 30,
                SizeWndX - TOPBORDER_COLON_FIELDS,
                SizeWndY - STATIC_LATITUDE);
        pv_PositionWpt.SetPositionLLA("Aucun", Lat, dLong, Alt);
    }*/

    public void Update(){

        repaint(TOPBORDER_COLON_FIELDS,
                STATIC_LATITUDE - 30,
                SizeWndX - TOPBORDER_COLON_FIELDS,
                SizeWndY - STATIC_LATITUDE);

    }

   /*private void CalculLatitudeDMS(boolean bActualPosition){
      double dLat = 0;
      if(bActualPosition == true) {dLat = pv_PositionWpt.GetLatitude();}
      else {dLat = pv_PositionWpt.GetCursorLat();}

      pv_iDegrees = (int)dLat;
      pv_iMinutes = (int)((dLat - pv_iDegrees)*60);
      pv_fSeconds = (float)(3600*(dLat - (double)pv_iDegrees - (double)pv_iMinutes/60));
   }*/

   private void CalculLLADMS(float dDegrees){
      //double dLong = 0;
      //if(bActualPosition == true) {dLong = pv_PositionWpt.GetLongitude();}
      //else {dLong = pv_PositionWpt.GetCursorLong();}

      pv_iDegrees = (byte)dDegrees;
      pv_iMinutes = (byte)((dDegrees - (float)pv_iDegrees)*60);
      pv_fSeconds = (float)(( dDegrees - (float)pv_iDegrees - (float)pv_iMinutes/60 )*3600);
   }

/*******************************************************************
 * �v�nement : Capture des �v�nements
 *******************************************************************/
	public void windowClosing(java.awt.event.WindowEvent event)
	{
      dispose();
	}
    public void windowOpened(java.awt.event.WindowEvent event){
        SizeWndY = (short)getSize().height;
        SizeWndX = (short)getSize().width;
        repaint();//UpdateStaticFiledsWnd(getGraphics());
    }

    public void windowClosed(java.awt.event.WindowEvent event){}
    public void windowIconified(java.awt.event.WindowEvent event){}
    public void windowDeiconified(java.awt.event.WindowEvent event){
        SizeWndY = (short)getSize().height;
        SizeWndX = (short)getSize().width;
        repaint();
        //UpdateStaticFiledsWnd(getGraphics());
    }

    public void windowActivated(java.awt.event.WindowEvent event){
        SizeWndY = (short)getSize().height;
        SizeWndX = (short)getSize().width;
        repaint();//UpdateStaticFiledsWnd(getGraphics());
    }

    public void windowDeactivated(java.awt.event.WindowEvent event){}
                                // fin fonction handleEvent

/*******************************************************************
 * Procedure principale
 ******************************************************************/

  /*public static void main(String args[])
  {

    SaveActualPosition Test = new SaveActualPosition();
    Test.setTitle("Position Actuel");
    Test.show();
  } */

}

