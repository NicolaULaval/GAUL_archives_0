import java.awt.*;
import java.lang.*;

public class Distance {

    //public PositionXYZ RefPosXYZ;
    //public PositionXYZ SavePosXYZ;
    public String Unites = "m.";
    //public Double dDistance;

    public Distance(){

      //RefPosXYZ = new PositionXYZ(RefXYZ.dRefPositionX.doubleValue(), RefXYZ.dRefPositionY.doubleValue(), RefXYZ.dRefPositionZ.doubleValue());

      //SavePosXYZ = new PositionXYZ(SaveXYZ.dRefPositionX.doubleValue(),SaveXYZ.dRefPositionY.doubleValue(),SaveXYZ.dRefPositionZ.doubleValue());

      //dDistance = new Double(CalculDistanceXYZ());
    }

  public double CalculDistanceXYZ(PositionXYZ RefXYZ, PositionXYZ SaveXYZ) {
    double DiffX = (RefXYZ.dRefPositionX - SaveXYZ.dRefPositionX);
    double DiffY = (RefXYZ.dRefPositionY - SaveXYZ.dRefPositionY);
    double DiffZ = (RefXYZ.dRefPositionZ - SaveXYZ.dRefPositionZ);
    double Diff3D =  (DiffX*DiffX + DiffY*DiffY + DiffZ*DiffZ);
    double DistanceXYZ = Math.sqrt(Diff3D);

    if ( DistanceXYZ < 1000 ) {
      Unites = " m.";
    }

    else{
      Unites = " Km.";
      DistanceXYZ /= 1000;
    }

     // = sqrt();
    return DistanceXYZ;
  }

   public double CalculDistanceLLA(PositionLLA RefLLA, PositionLLA SaveLLA) {

     double ErrLat = (RefLLA.Latitude.dValueInSeconds*Math.PI/180
                      -SaveLLA.Latitude.dValueInSeconds*Math.PI/180)*1852*60*180/Math.PI;


     double ErrLong =(RefLLA.Longitude.dValueInSeconds*Math.PI/180
                      -RefLLA.Longitude.dValueInSeconds*Math.PI/180)
                      *1852*60*Math.cos(SaveLLA.Latitude.dValueInSeconds*Math.PI/180)*180/Math.PI;


     double ErrAlt = RefLLA.fAltitude - SaveLLA.fAltitude;
     double Diff3D = ErrLat*ErrLat + ErrLong*ErrLong + ErrAlt*ErrAlt;

     double DistanceLLA = Math.sqrt(Diff3D);

     if ( DistanceLLA < 1000 ) {
       Unites = " m.";
     }

     else{
       Unites = " Km.";
       DistanceLLA /= 1000;
     }

     return DistanceLLA;
   }

}

