import java.awt.*;

public class Dialogue extends Dialog
{

  // Bouttons
  Button OK = new Button("OK");

  // Constructeur
  Dialogue(Frame frame)
  {

        // Boite de dialogue � Propos...
        super(frame, "� Propos...", false);
        setBackground(Color.yellow);
        setLayout(new FlowLayout());
        add(new Label("Martin Otis SoftWare", Label.CENTER));
        add(new Label("Tous droits r�serv�s.", Label.CENTER));
        add(new Label("1999", Label.CENTER));
        add(new Label("otim01@gel.usherb.ca", Label.CENTER));
        add(new Label("http://www-edu.gel.usherb.ca/otim01", Label.CENTER));
        //add("Center", new TextField(5));
        Panel pBoutton = new Panel();
        pBoutton.add(OK);
        add(pBoutton);
        resize(240,170);
        //pack();
        setResizable(false);

  }                                     // Fin du constructeur

/*******************************************************************
 * Gestionnaire d'�venement de la classe Dialogue
 * ****************************************************************/
 /*
  public boolean action(Event evenement, Object argument, Frame frame)
  {

    String Code = (String)argument;

    return true;
  }                                     // fin fonction action
  */
/*******************************************************************
 * �v�nement : Capture des �v�nements
 *******************************************************************/

  public boolean handleEvent(Event evenement)
  {
     // cas du X
    if(evenement.id == Event.WINDOW_DESTROY){
      dispose();

    }                                   // fin if

    // Cas de la boite de dialogue � Propos
    if(evenement.target == OK){
      dispose();
    }

      return(true);
  }                                     // fin fonction handleEvent


}  // Fin de la classe Dialogue
