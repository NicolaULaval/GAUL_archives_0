import java.awt.*;
import java.lang.*;


public class WayPoint {

   private  PositionLLA       ActualPositionLLA;
   public   Point             XYActual;
   private  PositionLLA       ActCurPosLLA;

   public  String             nameWpt;
   public  float              m_fDistance;
   public  float              m_fDirection;
   public  float              m_fVitesse;

   public WayPoint(){
      ActualPositionLLA  = new PositionLLA();
      ActCurPosLLA       = new PositionLLA();
      XYActual           = new Point(0,0);
      nameWpt            = new String("Null");
      m_fDirection       = 0.0f;
      m_fVitesse         = 0.0f;
      m_fDistance        = 0.0f;
   }

   public WayPoint(String name, float Lat, float dLong, float Alt){
      ActualPositionLLA  = new PositionLLA(Lat, dLong, Alt);
      ActCurPosLLA       = new PositionLLA();
      XYActual           = new Point(0,0);
      nameWpt            = new String(name);
      m_fDirection       = 0.0f;
      m_fVitesse         = 0.0f;
      m_fDistance        = 0.0f;
   }

   public float  GetLatitude()  {   return ActualPositionLLA.getLat();    }
   public float  GetLongitude() {   return ActualPositionLLA.getLong();   }
   public float  GetAltitude()  {   return ActualPositionLLA.getAlt();    }
   public float  GetCursorLat() {   return ActCurPosLLA.getLat();        }
   public float  GetCursorLong(){   return ActCurPosLLA.getLong();       }

   public PositionLLA GetPositionLLA(){ return ActualPositionLLA; }

   public void SetPositionLLA(String name, float Lat, float dLong, float Alt){
      ActualPositionLLA.SetPositionLLA(Lat, dLong, Alt);
      nameWpt = name;
   }

   public void SetWayPointFromPosition(String name, PositionLLA ThisPosition){
      ActualPositionLLA = ThisPosition;
      nameWpt = name;
   }

   public void SetActualCursorPosition(PositionLLA ThisPosition){
       ActCurPosLLA = ThisPosition;
       m_fDistance = ActCurPosLLA.CalculDistanceLLA(ActualPositionLLA);
   }

}
