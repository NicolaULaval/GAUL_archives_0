// Deux ou trois Premier WayPoint du fichier allant avec la carte
// Ces deux coordonnes de reference ont une distance,
// une position LLA et une correspondance aux coordonnes de la
// fen�tre d'application.

import java.awt.*;
import java.lang.*;
import java.io.*;

public class CoordonnesReference {

   static final byte   SIZE = 3;
   float               VariationLat;
   float               VariationLong;
   PositionLLA[]       ActualPosition               = {new PositionLLA(0.0f,0.0f,0.0f),
                                                       new PositionLLA(0.0f,0.0f,0.0f),
                                                       new PositionLLA(0.0f,0.0f,0.0f)};
   Point[]             PXY                          = {new Point(0,0),
                                                       new Point(0,0),
                                                       new Point(0,0)};

   public CoordonnesReference(){
      VariationLat = 0.0f;
      VariationLong = 0.0f;
   }

   public void SetReference(float fLat, float fLong, byte index){
      if(index < SIZE){
         ActualPosition[index].SetPositionLLA(fLat, fLong, 0.0f);
         //.SetPositionLLA(dLat, dLong, (float)0);
      }
   }

   public void SetLatReference(float fDeg, byte index){
      if(index < SIZE){
         //ActualPosition[index] = new PositionLLA();
         ActualPosition[index].SetPositionLat(fDeg);
      }

   }

   public void SetLongReference(float fDeg, byte index){
      if(index < SIZE){
         //ActualPosition[index] = new PositionLLA();
         ActualPosition[index].SetPositionLong(fDeg);
      }
   }

   public float CalculEchelle(){

      PositionXYZ[] positionXY  = {new PositionXYZ((short)PXY[0].x, (short)PXY[0].y, (short)0),
                                   new PositionXYZ((short)PXY[1].x, (short)PXY[1].y, (short)0),
                                   new PositionXYZ((short)PXY[2].x, (short)PXY[2].y, (short)0)};

      float dEchelle      = 0.0f;
      float dDistanceLLA  = 0.0f;
      float dDistanceXYZ  = 0.0f;
      float fInche2meter  = 39.37f;
      int   iMapDPI       = 150;

      byte i = 0;
      byte j = 0;
      byte n = 0;


      for(i=0; i<SIZE; i++){
         for(j=SIZE-1; j>i; j--){

            // on conserve les variations sup. a 5 pixels
            if (Math.abs(PXY[i].y-PXY[j].y) > 5){
               dDistanceLLA = ActualPosition[i].CalculDistanceLLA(ActualPosition[j]);
               dDistanceXYZ = positionXY[i].CalculDistanceXYZ(positionXY[j]);
               dEchelle = dDistanceLLA/dDistanceXYZ*iMapDPI*fInche2meter + dEchelle;
               ++n;
               System.out.println("Echelle : " + Double.toString(dEchelle/n));
            }
         }
      }

      if(n != 0){
         dEchelle = dEchelle/n;
      }

      System.out.println("Echelle moyenne: " + Float.toString(dEchelle));

      return dEchelle;
   }

   public void CalculVariationReference(){

      byte n = 0;
      byte i = 0;
      byte j = 0;
      float somme = (float)0;

      for(i=0; i<SIZE; i++){
         for(j=SIZE-1; j>i; j--){

            // on conserve les variations sup. a 5 pixels
            if (Math.abs(PXY[i].y-PXY[j].y) > 5){
               VariationLat = Math.abs((ActualPosition[i].getLat() -
                                        ActualPosition[j].getLat())/(PXY[i].y-PXY[j].y));

               //on conserve les valeurs superieurs a 0
               if(VariationLat > 1/250000){
                  n++;
                  System.out.println("Variation Lat: " + Float.toString(VariationLat));
                  somme = somme + VariationLat;
               }
            }

         }
      }

      if(n != 0){
         VariationLat = somme/n;
      }

      n = 0;
      somme = 0;

      for(i=0; i<SIZE; i++){
         for(j=SIZE-1; j>i; j--){

            if (Math.abs(PXY[i].x-PXY[j].x) > 5){
               VariationLong = Math.abs((ActualPosition[i].getLong() -
                                        ActualPosition[j].getLong())/(PXY[i].x-PXY[j].x));
               if(VariationLong  > 1/250000){
                  n++;
                  System.out.println("Variation Long.:" + Float.toString(VariationLong));
                  somme = somme + VariationLong;
               }
            }

         }
      }

      if( n != 0 ){
         VariationLong = somme/n;
      }

      CalculEchelle();
   }

 /**************************************************************************************************
 * Lecture de la calibration de la carte
 **************************************************************************************************/
   public boolean CheckCalibration(String File){

         boolean bShowMap = false;
         boolean bEOF = false;
         boolean bDMS = false;
         boolean bGoodLine = false;

         String NomFichierData;
         RandomAccessFile rafLogFile;
         String Line;
         float dDegrees = 0.0f;

         NomFichierData = new String(File.substring(0,(File.length()-4))+".eta");
         System.out.println("Calibration: " + File.substring(0,(File.length()-4))+ ".eta");


         try{
            rafLogFile = new RandomAccessFile(NomFichierData, "r");

            System.out.println("Informations: " + rafLogFile);

            // Lecture du fichier de calibration
            while(!bEOF){
               Line = rafLogFile.readLine();
               if(Line == null){
                  bEOF = true;
               }

               else{
                  if(Line.startsWith("LAT/LON")){
                     bGoodLine = true;

                     if(Line.substring(23,26).equals("DMS")){
                        bDMS = true;
                        System.out.println("Format standard Degrees, minutes, secondes");
                     }
                     else{
                        if(Line.substring(23,25).equals("DM")){
                           System.out.println("Format Degrees, minutes");
                        }
                        else{
                           bGoodLine = false;
                           bEOF = true;
                           System.out.println("Format de coordonnees invalide");
                        }               // fin format invalide
                     }                  // fin DM ou DMS
                  }                     // fin LAT/LON

                  if(Line.startsWith("GRILLE UTM")) bGoodLine = false;
               }

               if(bGoodLine){
                  //Lecture de chaque point de calibration
                  System.out.println(Line);

                  for(byte i = 0; i < SIZE; i++){
                     //Signe positif sur l'altitude et la longitude
                     //Extraction de la longitude
                     Line = rafLogFile.readLine();
                     System.out.println(Line);

                     dDegrees = m_ExtractNumber(Line, 0);
                     if(bDMS){
                              dDegrees = (float)(dDegrees + m_ExtractNumber(Line, 8)/60.0f);
                              dDegrees = (float)(dDegrees + m_ExtractNumber(Line, 13)/3600.0f);
                     }
                     else     dDegrees = (float)(dDegrees + m_ExtractNumber(Line, 7)/60.0f);
                     if ( Line.charAt(0) == 'W' )  dDegrees = -dDegrees;

                     SetLongReference(dDegrees, i);
                     System.out.println(Float.toString(dDegrees) + " Deg.");

                     //Extraction de la latitude
                     Line = rafLogFile.readLine();
                     System.out.println(Line);

                     dDegrees = m_ExtractNumber(Line, 2);
                     if(bDMS){
                              dDegrees = (float)(dDegrees + m_ExtractNumber(Line, 7)/60.0f);
                              dDegrees = (float)(dDegrees + m_ExtractNumber(Line, 12)/3600.0f);
                     }
                     else     dDegrees = (float)(dDegrees + m_ExtractNumber(Line, 6)/60.0f);
                     if ( Line.charAt(0) == 'S' )  dDegrees = -dDegrees;

                     SetLatReference(dDegrees, i);
                     System.out.println(Float.toString(dDegrees) + " Deg.");

                     //Extraction de X
                     Line = rafLogFile.readLine();
                     System.out.println(Line);
                     PXY[i].x = (int)m_ExtractNumber(Line, 0);

                     //Extraction de Y
                     Line = rafLogFile.readLine();
                     System.out.println(Line);
                     PXY[i].y = (int)m_ExtractNumber(Line, 0);

                  }
               }
            }


            bShowMap = true;
            CalculVariationReference();
            System.out.println("Variation lat.  : " + Float.toString(VariationLat));
            System.out.println("Variation long. : " + Float.toString(VariationLong));
            System.out.println("Carte active");


         }

         catch(IOException e){
            bShowMap = false;
            System.out.println("Exception at reading file GeoState: Ouvrir une carte.");
         }

         return bShowMap;
   }                                    // Fin calibration

   public float m_ExtractNumber(String sLine, int iPos){

        byte           iLength            = (byte)(sLine.length() - iPos);
        boolean        bFindNumber        = false;
        float          dNumberFind        = 0.0f;
        final byte     fiSize             = 10;
        char[]         chNumber           = new char[fiSize];
        byte           iIndexNumber       = 0;
        byte           iCompare           = 0;
        String         sNumber;

        // on enleve les char inutiles au debut
        iCompare = (byte)sLine.charAt(iPos);
        while( ( iCompare <= 48 || iCompare > 57 ) &&
               (iPos <= iLength) ){

            ++iPos;
            iCompare = (byte)sLine.charAt(iPos);
        }

        // on extrait le nombre
        while( (iPos <= iLength) &&
             (bFindNumber == false) &&
             (fiSize > iIndexNumber)){

            iCompare = (byte)sLine.charAt(iPos++);

            if( ( iCompare >= 48 && iCompare <= 57 )||(iCompare == 46) ){
                chNumber[iIndexNumber++] = (char)iCompare;
            }
            else{
                sNumber = new String(chNumber, 0, iIndexNumber);
                if(m_FindChar(sNumber, '.') == true){
                    dNumberFind = Float.valueOf(sNumber).floatValue();
                }
                else{
                    dNumberFind = (float)Integer.valueOf(sNumber).intValue();
                }
                bFindNumber = true;
            }
        }

        return dNumberFind;

   } // fin extract number

    public boolean m_FindChar(String sLine, char chComp){

        int iLength = sLine.length();
        boolean bFindChar = false;

        for(int i = 0; i < iLength && bFindChar == false; i++){
            if( sLine.charAt(i) == chComp ) bFindChar = true;
        }

        return bFindChar;

    }

}
