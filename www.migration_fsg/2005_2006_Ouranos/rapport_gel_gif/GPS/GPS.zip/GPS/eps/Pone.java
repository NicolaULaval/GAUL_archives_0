// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>

import java.awt.*;



class Pone {
  static int ffGPSTRANS=500;
  static int ffGARLINK=501;
  static int ffGRM=502;
  
  static int DDD=0;
  static int MDD=1;
  static int DMM=2;
  static int DM=3;
  static int MgDD=98;
  static int MD=99;
  static int GRM=100;
  static int pfGARLINK=ffGARLINK;
  static int pfGPSTRANS=ffGPSTRANS;
  static String nstr;
  static int MALL=2000;
  static String dgSign="\u00b0";
  //static String dgSign="�";

  static String mnSign="\u0027";
  double p;
  
  Pone (){
  }
    
  Pone (double ff) {
    p = ff;
  }
  
  double r(){
    return (((double) p)*Math.PI/180d);
  }
  
  static Pone str2Pone(String sp, int scol, int pf, int filf) {
    String colStr;
    
    colStr = CAux.getCol(sp,scol,(filf==Pone.ffGPSTRANS)?'\t':' '); 
    try {
      if (filf==Pone.ffGRM || (filf==Pone.ffGPSTRANS && pf == DDD)){
	double rv;
	int gpos,spi=0;
	double sign=1d;
	if (colStr.charAt(spi)=='N' || colStr.charAt(spi)=='E'){
	  spi=1;
	} else if (colStr.charAt(spi)=='W' || colStr.charAt(spi)=='S'){
	  spi=1;	
	  sign=-1d;
	}      
	nstr = colStr.substring(spi, colStr.length());
	//rv = sign*Double.valueOf(nstr).doubleValue();
	rv = (new Double(nstr)).doubleValue();
	if (filf==Pone.ffGRM){
	  rv = rv/100d;
	}	
	
	return (new Pone(rv));
      } else {
	int gpos=0,spi=0;
	double pg, pm;
	double pr;
	int sign=1;
	
	// System.out.println("s2Pone filf "+ filf +" " + colStr);
	// don't check for '�'. Strange things happen
	if (colStr.charAt(spi)=='N' || colStr.charAt(spi)=='E'){
	  gpos=1;
	} else if (colStr.charAt(spi)=='W' || colStr.charAt(spi)=='S'){
	  gpos=1;	
	  sign=-1;
	}      
	while (colStr.charAt(spi) >= '0' && colStr.charAt(spi)<='9') {
	  spi++;	
	};
	pg = Double.valueOf(colStr.substring(gpos,spi)).doubleValue();
	spi++;
	gpos = spi;
	// This was degrees
	while (colStr.charAt(spi) >= '0' && colStr.charAt(spi)<='9') {
	  spi++;	
	};
	pm = Double.valueOf(colStr.substring(gpos,spi)).doubleValue();
	spi++;
	gpos = spi;
	while (colStr.charAt(spi) < '0' || colStr.charAt(spi)>'9') {
	  // skip .,
	  spi++;
	};
	gpos = spi;
      // System.out.println("gpos=" + gpos);
	while (spi < colStr.length() && colStr.charAt(spi) != '\'') {
	  spi++;	
	};
	pm += Double.valueOf("0."+colStr.substring(gpos,spi)).doubleValue();

	if (pg<0d){
	  pm = -pm;	
	}
	pr = sign*(pg + pm/60d);
	
	if (colStr.length()>(spi+1) && (colStr.charAt(spi+1)=='S' 
				      ||colStr.charAt(spi+1)=='W')){
	  pr = -pr;
	}
	if (filf==Pone.ffGRM){
	  pr = pr/100d;
	}      
	return (new Pone(pr));
	
      }
    } catch (StringIndexOutOfBoundsException ioe) {
      System.out.println("Pone " + " \""+sp+"\" "+ "colstr= \""+colStr+"\" scol="+ scol+" "+ioe);
      ioe.printStackTrace();
      return(new Pone(0));
    }
  }

  static public String ffString(int ff) {
    if (ff==ffGPSTRANS) {
      return "gpstrans";
    }
    else if (ff==ffGARLINK) {
      return "garlink";
    }
    else if (ff==ffGRM) {
      return "grm";
    }
    else return "?ffString";
    
  }
    

  public String toStringMin() {
    double mn = CAux.frd(Math.abs((60d*p)),3);
    int dg = (int) (mn/60d);
    mn = mn - 60*(double)dg;
    return(CAux.frds0(mn,3));
  }
    
  
  public String toString(int pf) {
    int dg;
    int lpad =0;
    int ldpad =0;
    int dprc=3;
    String dgSign1=dgSign;
    double mn;  

  if (pf==DDD) {
    return(""+CAux.frds(p,3));
  } else if (pf==MALL) {
    return(""+p);
  } else if (pf==MDD) { /*dd.mm.mm */
    dprc=3;
  } else if (pf==DM) { /*dd.mm */
    dprc=0;
  } else if (pf==DMM) { /*dd.mm.mm */
    dprc=2;
  } else if (pf==Pone.pfGPSTRANS) { /*dd.mm.mm */
	return(""+p);
  } else if (pf==Pone.pfGARLINK) { /*dd.mm.mm */
    ldpad =3;
    lpad =6;
    dprc =3;
    
  } else if (pf==MD){
    dgSign1="g";
    mnSign="";
    dprc =0;
    lpad =2;
    ldpad =2;
    
  } else {
    return("Wrong Format");	
  }		            
  try {    
    mn = CAux.frd(Math.abs((60d*p)),dprc);
    dg = (int) (mn/60d);
    mn = mn - 60*(double)dg;
    return(CAux.spad(""+dg,-ldpad,'0') + dgSign1 + CAux.spad(CAux.frds(mn,dprc),-lpad,'0') + mnSign);
  } catch (IllegalArgumentException ex) {
    System.out.println("ill arg dprc="+ dprc+" p="+p+" "+ex);
    return("Pone error");
    
  }
  
  
}
}

