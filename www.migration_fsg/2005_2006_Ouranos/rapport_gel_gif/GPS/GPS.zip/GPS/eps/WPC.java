// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>

import java.awt.*;
import java.io.*;
import java.net.*;
import java.lang.Runtime;
import  java.util.Date;
import  java.text.*;
import netscape.security.PrivilegeManager;
import netscape.security.ForbiddenTargetException;


class WPC {
  int nWP=0, maxWP=500;
  WayPoint wayPoints[] = new WayPoint[maxWP];

  
  public void flushList(List wpl,boolean isRoute){
    int nw;
    double sumDist=0d;
    double dist=0d;
    if (wpl!=null){

      // netscape problem
      try {
	if (wpl.getItemCount() >0){
	  wpl.removeAll();
	}
      }  catch (NoSuchMethodError ex) {
	if (wpl.countItems() >0){
	  wpl.clear();
	}
      }
      

      
      for (nw=0 ; nw<nWP ; nw++){
	if (isRoute){
	  wpl.addItem("" + wayPoints[nw].name + " +" + CAux.frds(dist,2) + 
		      "Nm =" + CAux.frds(sumDist,2) + " Nm");
	  if (nw < nWP-1){
	    dist = wayPoints[nw].wpos.dist(wayPoints[nw+1].wpos);
	    sumDist += dist;
	  }	  
	} else {	
	  wpl.addItem("" + wayPoints[nw].name);
	  
	}	
      }
    }    
  }
  
  public void delete(int nd){
    int nw;
    nWP--;
    for (nw=nd; nw < nWP; nw++){
      wayPoints[nw] = wayPoints[nw+1];
    }     
    wayPoints[nWP]=null;    
  }
  
  public void deleteAll(){
    nWP = 0;
  }
  

  
  WayPoint readWP(TextArea err,List wl,String inputLine, int posFmt, int filf, boolean isRoute){    
   WayPoint nwp = new WayPoint();
   if (filf==Pone.ffGARLINK){
     int rOff = (isRoute)?1:0;
     nwp.name = CAux.getCol(inputLine,rOff,' ');
     if (nwp.name.length()>6){
       nwp.name = nwp.name.substring(0,6);
     }
     
     nwp.wpos.y =  Pone.str2Pone(inputLine,rOff+1,posFmt,filf);
     nwp.wpos.x =  Pone.str2Pone(inputLine,rOff+2,posFmt,filf);
   } else if (filf==Pone.ffGPSTRANS){
     int rOff = (isRoute)?0:1;
     nwp.name = CAux.getCol(inputLine,1,'\t');
     nwp.wpos.y =  Pone.str2Pone(inputLine,rOff+3,posFmt,filf);
     nwp.wpos.x =  Pone.str2Pone(inputLine,rOff+4,posFmt,filf);
     if (!isRoute) {
       nwp.comment = CAux.getCol(inputLine,2,'\t');
       if (nwp.comment != null) {
	 nwp.comment = nwp.comment.toUpperCase();
       }     
       nwp.timestamp = CAux.readDate(CAux.getCol(inputLine,3,'\t'));
     }     
   } else if (filf==Pone.ffGRM){
     if (inputLine==null || inputLine.length()==0 || inputLine.charAt(0)!='W'){
       return(null);
     }     
     nwp.name = inputLine.substring(3,9);
     nwp.wpos.y =  Pone.str2Pone(inputLine,2,posFmt,filf);
     nwp.wpos.x =  Pone.str2Pone(inputLine,3,posFmt,filf);
   }

    nwp.name = nwp.name.toUpperCase();
    //     System.out.println("new wp " + wayPoints[nWP].name + 
//			" "+wayPoints[nWP].toString(1));
    
   insertWP(err,null,nwp,false);
   //      ChartFrame.wlist.addItem("" + nWP + " "+ nwp.name);
   flushList(wl,false);
   return (nwp);
 }
  
 void readWayPoints (TextArea err, List wl,URL epsBase, String wpfile, int filf, GMenv menv) {
    int posFmt=Pone.DDD;
    URL tURL;
    Datum pDatum = Pos.WGS84;
    
     BufferedReader dis;
    String inputLine;
    menv.wpfile = wpfile;    
    try {            
      if (epsBase !=null){
	tURL =new URL(epsBase,wpfile);
	dis = new BufferedReader(new InputStreamReader(tURL.openStream()));
      } else {
	dis = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec(wpfile+ " -dw").getInputStream()));
      }      

      if (filf==Pone.ffGPSTRANS){
	if ((inputLine = dis.readLine())!=null) {
	  //	System.out.println("0--7 " + inputLine.substring(0,7));
	  
	  if (inputLine.substring(0,7).equals("Format:")){	
	    //	  System.out.println("found Format");
	    
	    if (inputLine.substring(8,11).equals("DDD")){
	      posFmt = Pone.DDD;
	  } else {
	    posFmt = Pone.MDD;
	  }
	  }
	}
	int datumNo;	
	datumNo = Integer.parseInt(inputLine.substring(43,46));
	pDatum = Pos.getGtDatum(datumNo);	
      } 

      while ((inputLine = dis.readLine()) != null) {
	WayPoint d;
	//System.out.println("now read " + inputLine + " ff="+filf+" pf="+posFmt);
	d = readWP(err,null,inputLine, posFmt, filf,false);
	d.wpos.theDatum = pDatum;	
      }
      flushList(wl,false);
    dis.close();
    }
    catch (MalformedURLException me) {
      err.setText("MalformedURLException: " + me);
    } catch (FileNotFoundException fe) {
      err.setText("waypoint file not found: " + fe);
    } catch (IOException ioe) {
      err.setText("Could not find wayPoints:" + ioe);
    } catch (StringIndexOutOfBoundsException ioe) {
      err.setText("Could not read Waypoint file " + ioe);
      ioe.printStackTrace();
    } catch (NumberFormatException ioe) {
      err.setText("Could not read Waypoint file " + ioe);
    } catch (SecurityException ioe) {
      err.setText("Could not read WP file " + ioe);
    }
    flushList(wl,false);
  }
  

  public void insertWP(TextArea err,List wl, WayPoint wp, boolean isRoute){
    int oldInx=0;
    int nw;
    WayPoint ewp;
    
    ewp = findWP(wp.name);
    if (!isRoute && ewp!=null && ewp.wpos.eq(wp.wpos)){
      if (err != null) {
	try {
	  err.append("WP already exist:"+wp.name+"\n");
	} catch (NoSuchMethodError ex) {
	  CAux.perr("WP already exist:"+wp.name,0);
	}
      }      
      return;
    }
  
    if (nWP >= maxWP) {
      int xi;
      WayPoint w0[] = wayPoints;
      wayPoints = new WayPoint[2*maxWP];      
      for (xi=0;xi<maxWP;xi++){
	wayPoints[xi] = w0[xi];    
	maxWP=2*maxWP;
      }            
    }
    
    if (wl==null){
      oldInx=nWP;
    } else {
      oldInx = wl.getSelectedIndex()+1;
      if (oldInx==0){
	oldInx = nWP;
      }      
    } 
    for (nw=nWP; nw>oldInx; nw--){
      wayPoints[nw] = wayPoints[nw-1];
    }    
    nWP++;

    wayPoints[oldInx] = wp;
    if (wl!=null){
      flushList(wl,isRoute);
    }    
  }    
  
  public WayPoint findWP(String wname){
    int nwp=0;
    
    while (nwp < nWP) {
      if (wayPoints[nwp].name.equals(wname)){
	return(wayPoints[nwp]);
      }
      nwp++;
    }
    return(null);
  }

  WayPoint findWP(WayPoint wp){
    int nwp=0;
    
    while (nwp < nWP) {
      if (wayPoints[nwp]==wp){
	return(wayPoints[nwp]);
      }
      nwp++;
    }
    return(null);
  }

   public void output(TextArea ta, int ff, int off,Datum datum,String fn, String gt){    
    String tmp_file = "/tmp/gpstrans_upl_WP";
    try {
      DataOutputStream dos;
      boolean ferr = false;

	String fn1 = fn;      
	try {
	  try {
	    PrivilegeManager.enablePrivilege("UniversalFileWrite" /*, fn1*/);
	  } catch (ForbiddenTargetException me) {
	  CAux.perr("No FTE PM",3);
	  } catch (NoClassDefFoundError me) {
	    CAux.perr("No PM",3);
	  }
	  if (gt!=null){
	    fn1 = tmp_file;
	  }
	  File oFile = new File(fn1);
	  dos = new DataOutputStream(new FileOutputStream(oFile));
	  output(null,dos,ff,off, datum);
	} catch (SecurityException me) {
	  System.out.println(" SecurityException: " + me);
	  ferr=true;
	}
	catch (IOException me) {
	  System.out.println(" File IOException: uWP" + me);
	  ferr=true;
	}    

	if (gt!=null){
	  Process prc;
	  prc=Runtime.getRuntime().exec(gt + " -uw " +tmp_file);
	} else if (ta!=null && ferr){
	  ta.setText("");
	  output(ta,null,ff,off, datum);
	}	
    }
    
    catch (IOException me) {
      System.out.println(" File IOException: uWP" + me);
    }    
  }
  
   public void output(TextArea ta, DataOutputStream dos, int ff,int off,Datum datum) 
     throws IOException{
       String dstr;
       int nw;
    if (ff==Pone.ffGPSTRANS){
      String Soff = ""+off;
      String Sdatum = ""+datum.gpstransNo;
      CAux.fo(
	     "Format: DDD  UTC Offset:" + "    ".substring(0,4-Soff.length()) + Soff +
	     ".00 hrs  Datum["+ "000".substring(0,3-Sdatum.length()) + Sdatum+
	     "]: "+datum.name+"\n",dos,ta);
      for (nw=0; nw < nWP; nw++){
	Pos outPos = wayPoints[nw].wpos.toDatum(datum);	
	dstr = CAux.localOutDefault.format(wayPoints[nw].timestamp);
	  CAux.fo("W" + "\t" + wayPoints[nw].name+"\t"+
		  wayPoints[nw].comment + "\t"+
		  dstr + "\t"+
		  outPos.toString(ff)+"\n", dos, ta);
      }    
    } else if (ff==Pone.ffGARLINK) {
      for (nw=0; nw < nWP; nw++){
	CAux.fo(
	       CAux.spad(wayPoints[nw].name,6,' ') +
	       " " + wayPoints[nw].wpos.toString(Pone.pfGARLINK) +
	       " ______________                      \n",dos,ta);
      }      
    }
    if (dos!=null){
      dos.close();   
    }     
  }
  
}

