// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>

import java.io.*;
import java.util.Date;
import java.util.Calendar;
import java.awt.*;
import java.text.*;
import netscape.security.PrivilegeManager;
import netscape.security.ForbiddenTargetException;

class NMEA implements Runnable {
  ImageGMap IGMCanvas;
  Label NMEALabel;
  Calendar tcal = Calendar.getInstance();

  NMEA (ImageGMap IGM,Label nl) {
    IGMCanvas = IGM;
    NMEALabel = nl;
  }

  public void run() {
    Pos NMEAPos;
    String inputLine;
    double lat,lng;
    String tm;
    double speed =0d;
    double course =0d;
    
    int year=97;
    int month=1;
    int date=1;
    int hrs=0;
    int min=0;
    int sec=0;
    int ssec=0;
    Calendar today = Calendar.getInstance();
    
    String lats,lngs;

    year = today.get(Calendar.YEAR);
    month = today.get(Calendar.MONTH);
    date = today.get(Calendar.DAY_OF_MONTH);
    
    System.out.println("  NMEAPos start: ");
    try {
      PrivilegeManager.enablePrivilege("UniversalFileRead");	
      PrivilegeManager.enablePrivilege("UniversalExecAccess");	
    } catch (ForbiddenTargetException me) {
      CAux.perr("No FTE PM",3);
    } catch (NoClassDefFoundError me) {
      CAux.perr("No NMEA PM",3);
    }
    Garmincomm.serialOpen(Garmincomm.NMEA_comm);
    TrackC.insertTrack(new TRPos(null,new Date()));
    while(true) {
      try {
	inputLine = (Garmincomm.epscommNMEA).readLine();
	if ((inputLine!=null) && inputLine.length()>3) {
	  CAux.perr("  il is "+ inputLine,7);
	  try {
	    if (inputLine.substring(3,6).equals("GLL")) {
	      lats = CAux.getCol(inputLine,1,',');
	      lngs = CAux.getCol(inputLine,3,',');
	      CAux.perr("  lats= "+ lats +"  lngs= "+ lngs ,6);
	      if (lats.length()>0 && lngs.length()>0) {
		lat = Double.valueOf(lats.substring(0,2)).doubleValue() +
		  (Double.valueOf(lats.substring(2)).doubleValue()/60d);
		lng = Double.valueOf(lngs.substring(0,3)).doubleValue()+
		  (Double.valueOf(lngs.substring(3)).doubleValue()/60d);
		if (CAux.getCol(inputLine,6,',').charAt(0)=='A'){		  
		  tm = CAux.getCol(inputLine,5,',');
		  hrs = Integer.parseInt(tm.substring(0,2));
		  min = Integer.parseInt(tm.substring(2,4));
		  sec = Integer.parseInt(tm.substring(4,6));		  
		}
		
		if (CAux.getCol(inputLine,2,',').equals("S")) {
		  lat = -lat;
		}
		if (CAux.getCol(inputLine,4,',').equals("W")) {
		  lng = -lng;
		}
		NMEAPos = new Pos(lng,lat,Pos.WGS84);
		CAux.perr("  NMEAPos is "+ NMEAPos, 5);
		tcal.set(year,month,date,hrs,min,sec);
		TrackC.insertTrack(new TRPos(NMEAPos,tcal.getTime()));
				   
		if (IGMCanvas.onScreen(NMEAPos)) {
		  IGMCanvas.NMEAPaint = true;
		  IGMCanvas.repaint(20);
		} else {
		  IGMCanvas.ggoto(NMEAPos);
		  IGMCanvas.FullPaint = true;
		  IGMCanvas.musync.upd(50);
		}
	      }
	    } else if (inputLine.substring(3,6).equals("RMC")) {
	      String dS;	      
	      dS = CAux.getCol(inputLine,9,',');
	      String sS, cS;
	      sS = CAux.getCol(inputLine,7,',');
	      cS = CAux.getCol(inputLine,8,',');
	      
	      if (sS != null && sS.length()>0 && cS != null && cS.length()>0) {		
		year = Integer.parseInt(dS.substring(4,6));
		month = Integer.parseInt(dS.substring(2,4))-1;
		date = Integer.parseInt(dS.substring(0,2));
		speed = Double.valueOf(sS).doubleValue();
		course = Double.valueOf(cS).doubleValue();
		NMEALabel.setText("NMEA: "+ speed + "Kn  "+course + Pone.dgSign);

		CAux.perr("dS="+dS+ " year="+year + " month="+month, 6);
	      }	      
	    }	    
	  } catch (StringIndexOutOfBoundsException ioe) {
	      System.out.println("SOOB NMEA: " + ioe);
	  }
	}
      } catch (IOException ioe) {
	System.out.println("IOException NMEA: " + ioe);
    }  
    }   
  }
}
