import java.awt.*;
import java.io.*;
import  java.text.*;
import netscape.security.*;
import com.ms.*;
class T {
  static public void main(String argv[]){
    DataOutputStream dos;
    try {
	  try {
	    PrivilegeManager.enablePrivilege("UniversalFileAccess");	
	  } catch (NoClassDefFoundError me) {
	    System.out.println("No PM");
	  }    

      File oFile = new File("foo");
      dos = new DataOutputStream(new FileOutputStream(oFile));
      dos.write(42);
    } catch (SecurityException me) {
      System.out.println(" SecurityException: " + me);
    }
    catch (IOException me) {
      System.out.println(" File IOException: uWP" + me);
    }    
  }
}

