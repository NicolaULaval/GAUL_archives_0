// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>


class GTime{
  long secs=0;
  String ss;

  GTime(){
  }

  GTime (int ts){
    secs = ts;
    ss = ""+ts;
  }
  
  GTime(String s){
    ss=s;
    int spi=0;
    while (s.charAt(spi)!=' '){
      spi++;
    }
//    System.out.println(" spi= "+ spi+ " s="+s.substring(spi+1,spi+3));
    secs = 3600*Integer.valueOf(s.substring(spi+1,spi+3)).intValue(); 

//    System.out.println(" secs now= "+ secs + " s="+s.substring(spi+4,spi+6));
    secs += 60*Integer.valueOf(s.substring(spi+4,spi+6)).intValue(); 

//    System.out.println(" secs now= "+ secs+s.substring(spi+7,spi+8));
    if (s.length()>spi+8) {
      secs += Integer.valueOf(s.substring(spi+7,spi+8)).intValue(); 
//    System.out.println(" secs now= "+ secs);
    }
    
    
  }
  public String toString(){
    return(ss);
  }
  

}
