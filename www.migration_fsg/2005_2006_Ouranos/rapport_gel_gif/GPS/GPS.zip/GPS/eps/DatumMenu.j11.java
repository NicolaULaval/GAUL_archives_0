// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>

import java.awt.*;
import java.awt.event.*;

class DatumMenuItem extends MenuItem implements ActionListener{
  public Datum theDatum = Pos.WGS84;
  DatumMenu myMenu;

  DatumMenuItem(DatumMenu mm, String lb,Datum d)  {      
    super(lb);
    myMenu = mm;
    theDatum =d;  
    addActionListener(this);
  }

  public void actionPerformed(ActionEvent event) {
    CAux.perr("DM PE: " + event, 6);
    CAux.perr("mm=: " + myMenu, 6);
    myMenu.setDatum(theDatum);
    myMenu.IGMCanvas.FullPaint=true;
    myMenu.IGMCanvas.repaint(50);
    CAux.perr("Map now: " + theDatum.name,4);
  }    
 }


class DatumMenu extends Menu {
  public Datum theDatum = Pos.WGS84;
  MenuItem now = new MenuItem("NOW: WGS84");
  public ImageGMap IGMCanvas;  
  
  DatumMenu(String name) {  
    super(name);
    int di=0;   
    add(now);  
    addSeparator();   
    while (Pos.datumList[di]!=null) {     
      add (new DatumMenuItem(this, Pos.datumList[di].name, Pos.datumList[di]));
      di++;     
    }
  }
  
  public void setDatum(Datum d) {
    theDatum =d;
    now.setLabel("now: "+theDatum.name);
    CAux.perr("new datum" + theDatum, 3);
    //Could be done more elegant in Java 1.1
  }
}



