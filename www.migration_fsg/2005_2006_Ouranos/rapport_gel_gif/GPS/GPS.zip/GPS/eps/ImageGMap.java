// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>
import java.awt.*;
import java.io.*;
import java.net.*;
import java.lang.Math;
import java.util.Date;

class ImageGMap extends EPSCanvas implements Runnable {
//class ImageGMap extends Canvas {
  Date simTime = new Date(0) ;
  ICF theCF;
  int ttx;
  int tx;
  int tty;  
  int ty=500;  
  boolean mouseUp = true;
  static boolean CursorPaint= false;

  boolean alive = true;
  boolean NMEA=false;
  

  int tx0=0,ty0=0;  
  int cx0=0, cy0=0;
  int cx1=0, cy1=0;
  Pos bottomLeftPos;
  int lastZoom;
  String oldpos = "";
  int XCharts;
  int YCharts;
  int ScreenWidth;
  int ScreenHeight;
  Font waypointFont = new Font("Helvetica", Font.PLAIN, 12);  
  Font routeFont = new Font("Helvetica", Font.PLAIN, 20);  
  int nLoadMaps = 25;   
  String imgNames="";
  
  double xres=0d, yres=0d;  // pixels per degree
  
  Dimension ChartDim;
  Dimension minDim;
  Dimension prefDim;
  
  int nLong, nLat;
  double fLong, fLat;
  
  ChartInfo loadedMaps[][];
  Pos cCursor=null;
  Pos oldcCursor=null;
  
  GMenv menv;
  Usync musync= new Usync(this);
  
  ImageGMap(GMenv e, ICF cf){
    menv =e;
    //System.out.println(" I UGM env= " +menv);
    //bottomLeftPos.x.p = menv.initLong;
    //bottomLeftPos.y.p = menv.initLat;
    loadedMaps = new ChartInfo[nLoadMaps*2+1][nLoadMaps*2+1];
    theCF = cf;
    bottomLeftPos = new Pos(0d,0d, theCF.mMapDatum.theDatum);

    nLong =  menv.cw;		//width of charts in minutes
    nLat =  menv.ch;		//width of charts in minutes
    
    fLong = ((double) nLong)/60d; //width of charts in degrees
    fLat = ((double) nLat)/60d;   //width of charts in degrees

    ChartDim = new Dimension(menv.naturalDim.width,menv.naturalDim.height);
    
    prefDim = new Dimension(600,700);
    minDim = new Dimension(400,300);
    System.out.println("starting at  " + menv.initLat +","+menv.initLong);
    ScreenWidth = prefDim.width;
    ScreenHeight = prefDim.height;

    yres = ChartDim.height / fLat;
    xres = ChartDim.width / fLong;  
    // FIXME ScreenWidth and ScreenHeight should be correct here.
    // But is be unknown at this time
    // System.out.println(" ssz= " +getSize());


    jumpTo(new Pos(menv.initLong,menv.initLat,theCF.mMapDatum.theDatum), true);

    setBackground(new Color(240,230,140));
    
    // Math.rint() dos not work on the HP's at least with Netscape 
    
    if (menv.wpfile != null){
      aWP.theWP.readWayPoints(theCF.outArea,theCF.waypointList,menv.epsBase, menv.wpfile,
			      theCF.fileFormat,menv);
    }
    if (menv.rtfile != null){
      RouteC.readRoutes(theCF.outArea,theCF.routeList,theCF.routeWPList, theCF.waypointList,
			menv.epsBase, menv.rtfile,theCF.fileFormat,menv);
    }
    if (menv.trfile != null){
      TrackC.readTracks(menv.epsBase,menv.trfile,theCF.fileFormat,menv);
    }    
    imgNames=CAux.readCharts( menv.epsBase, menv.chartdir);

  }
  
  public Dimension getMinimumSize(){  
    return (minDim);
  }
  
  public Dimension getPreferredSize(){  
    return (prefDim);
  }

  // Java 1.0 begin
  public Dimension minimumSize(){  
    return (minDim);
  }
  
  public Dimension preferredSize(){  
    return (prefDim);
  }
  // Java 1.0 end

    
   public void run() {
     //     System.out.println("Running ");
     
     while (true){
       if (musync.shouldWork()) {
	 paintupd();
	 FullPaint = true;
	 repaint(500);
       }
     }
   }    
   

  int lrnd(double dd) {
    if (dd>=0d){
      return((int)dd);
    } else {
      return((int)(dd+Double.MIN_VALUE-1));
    }    
  }
  
    
  public boolean mouseMove(Event evt, int sx, int sy) {
    int x,y;
    x = sx - tx;
    y = ty - sy;    
    String pos;
    
    pos= pix2pos(x,y).toString(Pone.MD);
    
    oldpos=pos;
  return true;
  }
  
public boolean handleEvent(Event event) {
  //System.out.println("IG event "+ event);
  if (event.id == Event.MOUSE_ENTER  ){
    requestFocus();
  }    
  return(super.handleEvent(event));
	    //  return(false); 
}
  

public boolean keyDown(Event evt, int key) {
  //  System.out.println("KD "+ evt);
  char tk = Character.toLowerCase((char)key);  
  if (tk=='t'){
    trackLog(evt.x,evt.y);
  } else if (tk=='p'){
    showPos(evt.x,evt.y);
  } else if (tk=='n'){
    newTrackLog();
  } else if (tk=='z'){
    theCF.pLabel.setText(" test " + "sxy("+evt.x+","+evt.x+")"+"tx("+tx+","+ty+","+tty+")"+
			 " res("+xres+","+yres+")");      
    
  }    
  return (true);  
}
  
  void newTrackLog()  {      
    TrackC.insertTrack(null);
    theCF.pLabel.setText(" Starting New track");      
  }
  

  void showPos(int sx, int sy)  {
    int x,y;
    cCursor = screenPix2Pos(sx,sy);
   
    CursorPaint = true;
    repaint();
    
    //	System.out.println("Mouse  cx ("+cx+","+cy+")"+"sxy("+sx+","+sy+")"+
    //			   "xy=("+x+","+y+")" );	        
    if (cCursor != null){
      if (cCursor.theDatum == theCF.mPositionDatum.theDatum) {
	theCF.pLabel.setText(" pos: " +  cCursor.toString(theCF.posFm));
      } else {
	theCF.pLabel.setText(" pos: " +  
			     cCursor.toString(theCF.posFm) +
			     " ("+cCursor.theDatum.name + ")  "+
			     cCursor.toDatum(theCF.mPositionDatum.theDatum).toString(theCF.posFm) +
			     "("+theCF.mPositionDatum.theDatum.name + ")"
			     );
      }            
    }
}
  

  void trackLog(int sx, int sy)  {
    int x,y;
    x = sx - tx;
    y = ty - sy;    
    Pos mc = pix2pos(x,y);
    TrackC.insertTrack(new TRPos(mc, simTime));
    theCF.pLabel.setText(
			 //"x(" + x +","+ y + ")"+
			 //" tx("+tx+","+ty+"/"+tty+")" + 
			 //" sx("+sx+","+sy+") pos:" + 
			 "Setting track log at " +
			 mc.toString(theCF.posFm)
			 //+" blp=" + bottomLeftPos.toString(theCF.posFm)
			 );
    AnnoPaint = true;
    repaint(20);
  }
  
  public boolean mouseDown(Event evt, int sx, int sy)  {
    String chartName;
    if (0!=(evt.modifiers & Event.ALT_MASK)) {       /* Middle */ 
      trackLog(sx,sy);
    } else if (0!=(evt.modifiers & Event.META_MASK)) {      /* Right */ 
      newTrackLog();
      } else {
	showPos(sx,sy);		
      }
  return (true);    
  }	
  
 int pos2xpix(Pos p){
   return((int) ((p.toDatum(theCF.mapDatum()).x.p - bottomLeftPos.x.p)*xres));
 }
  

  int pos2ypix(Pos p){
    return((int) ((p.toDatum(theCF.mapDatum()).y.p - bottomLeftPos.y.p)*yres));
  }


 int pos2sxpix(Pos p){
   return((int) ((p.toDatum(theCF.mapDatum()).x.p - bottomLeftPos.x.p)*xres +(double)tx));
 }

  int pos2tsypix(Pos ppos){
    /* pixels from bottom of canvas */
    return((int) ((ppos.toDatum(theCF.mapDatum()).y.p - bottomLeftPos.y.p)*yres -(double)tty));
  }

  int pos2sypix(Pos p){
    /* pixels from top of canvas */
    return((int) (ty-(p.toDatum(theCF.mapDatum()).y.p - bottomLeftPos.y.p)*yres));
  }
  
  boolean onScreen(Pos p) {
    int sx,sy;
    sx = pos2sxpix(p);
    sy = pos2sypix(p);
    return(onScreen(sx,sy));
    }

  boolean onScreen(int sx, int sy) {
    return (sx>=0 && sy >=0 && sx < ScreenWidth && sy < ScreenHeight);    
  }

  boolean onScreen(int sx0, int sy0, int sx1, int sy1) {
    //FIXME does this line show on the screen ?
    if ((sx0 <0 && sx1 < 0) ||
	(sx0 > ScreenWidth && sx1 > ScreenWidth) ||
	(sy0 <0 && sy1 < 0)||
	(sy0 > ScreenHeight && sy1 > ScreenHeight)
	 ) {
      return (false);
    } else {          
      return(true);
    }    
  }
   

  public void plotWP(Graphics g){
    int nw;
    WayPoint theWP;
    g.setColor(Color.red);
    g.setFont(waypointFont);
    g.setPaintMode();
    for (nw=0; nw<aWP.theWP.nWP;nw++){
      int sx,sy;
      theWP = aWP.theWP.wayPoints[nw];
      if (theWP==null) {
      } else {
	Pos nwpos = theWP.wpos.toDatum(theCF.mapDatum());	
	sx = tx + pos2xpix(nwpos);
	sy = ty - pos2ypix(nwpos);
	theWP.routeHere = 0;
	if (onScreen(sx,sy)){       
	  //	  System.out.println("plot wp nWP=:" + aWP.theWP.nWP +"sxy=  "+ sx+"," +sy);
	  g.fillArc(sx-4,sy-4,8,8,0,360);      
	  CAux.drawString(g,aWP.theWP.wayPoints[nw].name,sx,sy,2,Color.red);
	}
      }      
    }
  }


  public void plotTR(Graphics g) {
    int nt;
    plotTrInit(g);
    
    for (nt=0; nt<TrackC.nTR;nt++) {
      plotTrNext(g, TrackC.track[nt]);
    }
  }

  public void plotTR_NMEA(Graphics g) {
    int nt=0;

    g.setPaintMode();
    g.setColor(Color.green);
    
    while ((nt < TrackC.nTR) && TrackC.lastPlotted!=null &&
	   (TrackC.track[nt]==null || TrackC.track[nt] != TrackC.lastPlotted)) {
      nt ++;
    }
    nt++;
    while (nt<TrackC.nTR) {
      //System.out.println(" nmgg"+ TrackC.track[nt]);
      plotTrNext(g, TrackC.track[nt]);
      nt ++;
    }
  }
  
  public void plotTrInit(Graphics g) {
    g.setPaintMode();
    g.setFont(theCF.fh14);
    g.setColor(Color.green);
    TrackC.lastPlotted = TrackC.track[0];
    TrackC.lastTimed = TrackC.lastPlotted;
  }
  
  public void plotTrNext(Graphics g, TRPos theTP) {
    int nt;
    int sx,sy;    
    int oldsx=0,oldsy=0;
    long oldtime=-1;
    double dist=0f;
    int mindistq = 60*25; // ca.pixels
    long td;
    long tdmin= 60000; //milliseconds
    int px,py;
    Pos ntpos = null;
    //  System.out.println("GMAP Plot TR: "+ TrackC.nTR);
    
    if (theTP == null || theTP.tpos==null) {
      TrackC.lastPlotted = theTP;
      TrackC.lastTimed = null;
      TrackC.adist = 0d;
      return;      
    }
    
    ntpos = theTP.tpos.toDatum(theCF.mapDatum());
    if (TrackC.lastPlotted != null && TrackC.lastPlotted.tpos != null) {	
      sx = pos2sxpix(ntpos);
      sy = pos2sypix(ntpos);
      oldsx = pos2sxpix(TrackC.lastPlotted.tpos.toDatum(theCF.mapDatum()));
      oldsy = pos2sypix(TrackC.lastPlotted.tpos.toDatum(theCF.mapDatum()));
      	
      if (TrackC.lastTimed!=null) {	
	oldtime = TrackC.lastTimed.tm.getTime();
	td = theTP.tm.getTime() - oldtime;
	TrackC.adist += theTP.tpos.dist(TrackC.lastPlotted.tpos);

	if (TrackC.adist*xres < mindistq/2) {
	  TrackC.mx = sx;
	  TrackC.my = sy;
	  TrackC.mfound = true;
	} else if (TrackC.mfound) {
	  TrackC.mx = (sx +oldsx)/2;
	  TrackC.my = (sy +oldsy)/2;
	  TrackC.mfound = false;
	}
	//CAux.perr(" td="+td+" mx="+TrackC.mx+" my="+TrackC.my + 
	//	  "  adist=" + TrackC.adist +"/"+ TrackC.adist*xres,9);
	if ((TrackC.adist*xres > mindistq) && (td<0 ||td > tdmin)) {
	  g.fillRect(sx-4,sy-4,8,8);
	  CAux.drawString(g,CAux.frds(TrackC.adist*3600000d/td,2) + "Kt",
			  TrackC.mx,TrackC.my,1,Color.black);
	  g.setColor(Color.green);
	  TrackC.adist = 0d;
	  TrackC.mfound = true;
	  TrackC.lastTimed = theTP;	
	}
      }
      
      if (onScreen(sx,sy,oldsx,oldsy)) {	  
	g.fillArc(sx,sy,4,4,0,360);
	if (TrackC.lastPlotted.tpos!=null){
	  g.drawLine(sx,sy,oldsx,oldsy);
	}	  
      }
    }
    TrackC.lastPlotted = theTP;      
    if (TrackC.lastPlotted == null || TrackC.lastTimed ==null) {
      TrackC.lastTimed = theTP;	
    }    
  }


  public void plotRT(Graphics g){
    int rt;
    Pos p0, p1;
    int th;
    FontMetrics fm;
    Pos nrpos;
    
    WayPoint theWP;
    g.setFont(routeFont);
    for (rt=0; rt<RouteC.nRT;rt++){
      Route theRT = RouteC.routes[rt];
      int nw;
      double sumDist=0d;
      int sx0,sy0;

      g.setPaintMode();
      g.setFont(theCF.fh14b);
      fm = g.getFontMetrics();
      th = fm.getHeight();
      if (theRT.wpts.nWP >0){
	int sy2;
	nrpos = theRT.wpts.wayPoints[0].wpos.toDatum(theCF.mapDatum());
	
	sx0 = tx + pos2xpix(nrpos);
	sy0 = ty - pos2ypix(nrpos);	
	theRT.wpts.wayPoints[0].routeHere++;
	sy2 = sy0-theRT.wpts.wayPoints[0].routeHere*th-4;
	CAux.drawString(g,"Start: " + theRT.name +  " 0 Nm", sx0,sy2,2,Color.blue);
      }
      for (nw=1; nw<theRT.wpts.nWP;nw++){
	int sx1,sy1;
	p0 =theRT.wpts.wayPoints[nw-1].wpos.toDatum(theCF.mapDatum());
	p1 = theRT.wpts.wayPoints[nw].wpos.toDatum(theCF.mapDatum());
	sx0 = tx + pos2xpix(p0);
	sy0 = ty - pos2ypix(p0);
	sx1 = tx + pos2xpix(p1);
	sy1 = ty - pos2ypix(p1);
	sumDist += p0.dist(p1);
	
	if (onScreen(sx0,sy0,sx1,sy1)){	
	  String ofText = CAux.frds(sumDist,2) +  " Nm of "+ theRT.name;
	  int sy2;
	  
	  theRT.wpts.wayPoints[nw].routeHere++;
	  g.setColor(Color.white);
	  sy2 = sy1-theRT.wpts.wayPoints[nw].routeHere*th-4;
	  CAux.drawString(g,ofText, sx1,sy2,2,Color.blue);
	  g.drawLine(sx0,sy0,sx1,sy1);
 	  CAux.drawString(g,CAux.frds(p0.dist(p1),2) + "Nm",
 		       (sx0+sx1)/2,(sy0+sy1)/2,2,Color.blue);
	  // 	  g.drawString("dist:" + "x0="+p0.x.r()+" y0="+p0.y.r()+
	  // 		       "x1"+p1.x.r()+"y1"+p1.y.r()+
	  // 		       "==" + p0.dist(p1),
	  // 		       (sx0+sx1)/2,(sy0+sy1)/2);
	  
	}
      }
      g.setFont(routeFont);
    }
  }

  
  void makeGrid(Graphics g){
    int dx,dy;
    int sx,sy;
    double fx,fy;
    double fmax;
    
    g.setFont(theCF.fh14);
    dx = tx % ChartDim.width;
    dy = -tty % ChartDim.height;
  
    fmax = (double) ScreenWidth;
    for (fx=dx; fx<fmax; fx+=(double)ChartDim.width){
      g.setColor(Color.black);
      g.drawLine((int)fx,ScreenHeight,(int)fx,0);
    }
//    System.out.println(" grid  ty="+ ty+" tty="+tty+ " dy= "+dy);
    
    g.setColor(Color.black);
    for (fy=(double)(ScreenHeight-dy); fy>=0f ; fy-= (double)ChartDim.height){
      sy = (int) fy;
      g.drawLine(0,sy,ScreenWidth,sy);      
    }
  }


  void plotcCur(Graphics g, Pos cc) {
    int sx,sy;       
    int rc = 4;
    int rd = 8;
    if (cc==null){
      return;    
    }    
    sx = tx+pos2xpix(cc);
    sy = ty-pos2ypix(cc);
    g.setColor(Color.green);
    g.setXORMode(Color.black);
    //    System.out.println("ccu  tx ("+tx+","+ty+")"+"sxy("+sx+","+sy+")");       
    
    g.fillArc(sx-rc,sy-rc,2*rc,2*rc,0,360);      
    g.drawArc(sx-rd,sy-rd,2*rd,2*rd,0,360);
  }

  public void annotate(Graphics g){
    FontMetrics fm;
    int minWidth;
    int nPerMin;

    int dfac[] = {2,5,10,30,60,120,300,600};
    int mfac[] = {2,5,10,20,50,100,200,500,1000};
    Pos blc;
    blc = bottomLeftPos.eCopy();
    blc.theDatum = theCF.mPositionDatum.theDatum;
    

    plotWP(g);
    plotTR(g);
    plotRT(g);
    makeGrid(g);
    g.setColor(Color.black);
    g.drawRect(0,0,ScreenWidth,10);
    g.drawRect(0,0,10,ScreenHeight);
    g.setFont(theCF.fh14);
    double sx,sy;
    
    double dx,dy;
    int dx0,dy0;
    double xunit = xres/60d;
    double yunit = yres/60d;
    double xCunit = 1.0/60.0;
    double yCunit = 1.0/60.0;

    
    //2,3,4,5,6,10,12,15,20,30
    if (xunit < 20d || yunit < 20d ){
      int nDegree=0;
      while ((nDegree <= 8) && (xunit < 20d || yunit < 20d)) {
	xunit = xres/60*dfac[nDegree];
	yunit = yres/60*dfac[nDegree];
	xCunit = dfac[nDegree]/60d;
	yCunit = dfac[nDegree]/60d;
	nDegree++;
      }
      while (xunit < 20d || yunit < 20d) {
	xunit *= 2;
	yunit *= 2;
	xCunit *= 2;
	yCunit *= 2;
      }
    } else {
      nPerMin=0;
      while (nPerMin<8 && xunit > 100d && yunit > 100d ) {
	xunit = xres/60d/mfac[nPerMin];
	yunit = yres/60d/mfac[nPerMin];
	xCunit = 1d/60d/mfac[nPerMin];
	yCunit = 1d/60d/mfac[nPerMin];
	nPerMin++;
      }
      while (xunit > 100d && yunit > 100d ) {
	xunit = xres/60d/10d;
	yunit = yres/60d/10d;
	xCunit = 1d/60d/10d;
	yCunit = 1d/60d/10d;
      }
    }
    
    Pos dmd = bottomLeftPos.eCopy();
    Pos dmdP;
    dmd.theDatum = theCF.mPositionDatum.theDatum;
    //System.out.println(" dD =  " + bottomLeftPos.toDatum(theCF.mPositionDatum.theDatum)
    //	       .toDatum(theCF.mMapDatum.theDatum));

    dmdP = dmd.toDatum(theCF.mMapDatum.theDatum);
    dx0 = ((pos2sxpix(dmdP)));
    dy0 = ((pos2tsypix(dmdP)));
    dx = (double)(dx0 % xunit);
    dy = (double)(dy0 % yunit);
    CAux.perr("anno: dx0="+dx0+" dy0="+dy0 +" xunit="+xunit+" yunit="+yunit,5);
    //CAux.perr("anno: dx="+dx+" dy="+dy,5);ww
    
    //System.out.println(" (dx,dy) =  (" + dx + ","+ dy+ ") (xres,yres)=("+xres+","+yres+")");

    for (sx = dx ;  sx < ScreenWidth; sx = sx+xunit){
      g.drawLine( (int)sx,1,(int)sx,10);
    }
    for (sy = ScreenHeight - dy; sy >0; sy -= yunit){
      g.drawLine( 1,(int)sy,10,(int)sy);
    }
    // Print Long. positions on border
    fm = g.getFontMetrics();
    minWidth = fm.stringWidth("55g88.88  ");

    
    if (minWidth> xres/60d && xunit<minWidth) {
      xunit=xres/60d;
      yunit=yres/60d;
      xCunit=1d/60d;
      yCunit=1d/60d;
      int nDegree=0;
      while ((nDegree <= 8) && (ScreenWidth/(int)xunit >10 || 
	     ScreenHeight/((int)yunit) >10 ||
	      (xunit < minWidth))) {
	xunit = xres/60*dfac[nDegree];
	yunit = yres/60*dfac[nDegree];
	xCunit = dfac[nDegree]/60d;
	yCunit = dfac[nDegree]/60d;
	nDegree++;
      }
    }
    
    while (ScreenWidth/(int)xunit >10 || ScreenHeight/((int)yunit) >10 
	   || (xunit < minWidth)){
      if (ScreenWidth/xunit >30){
	xunit *=10d;
	yunit *=10d;
	xCunit *=10d;
	yCunit *=10d;
      } else {
	xunit *=2d;
	yunit *=2d;
	xCunit *=2d;
	yCunit *=2d;
      }
    }
     

    int xunitoff = (int) ((tx+pos2xpix(dmdP)) / xunit);
    int yunitoff = (int) ((-tty+pos2ypix(dmdP) ) / yunit);
    
    blc.x.p -= ( xunitoff * xCunit);
    blc.y.p -= ( yunitoff * yCunit);
    CAux.perr("yCunit="+yCunit+" ty="+ty+" p2p="+ pos2ypix(dmdP)+ 
	      " blc="+blc.toString(Pone.MDD) + "  mul="+ yunitoff,5);
    //blc.y.p += (dy0 / yunit) * yCunit;    
    //CAux.perr("anno: blp=" +dmd+"   dmdP="+dmdP + " inv="+dmdP.toDatum(theCF.mPositionDatum.theDatum),5);

    if (xunit*yunit>100f) {
      String spos;
      int pformat=Pone.DMM;

      dx = pos2sxpix(blc);
      dy = pos2tsypix(blc);
    
       // Print Long. positions on border
      //    System.out.println("Lat ba1r= yunit" + yunit + " dy=" + dy);
      if ((xunit * 60 >= xres) && (yunit * 60 >= yres)) {	   
	pformat = Pone.DM;
      }	 
      for (sx = dx ; sx <ScreenWidth; sx += xunit){
	g.drawLine((int)sx+1,1,(int)sx+1,20);
	spos = blc.x.toString(pformat);
	CAux.drawString(g,spos,(int)sx - fm.stringWidth(spos)/2,(int)30,1,Color.black);
	blc.x.p += xCunit;
      }
      
       // Print Lat. positions on border
      //       System.out.println("Lat bar= yunit" + yunit + " dy=" + dy);
      //CAux.perr("xres="+xres+" xunit="+xunit + " yCunit="+yCunit+ " fm="+pformat,3);      
       for (sy = ScreenHeight - dy ;sy >34; sy -= yunit){
	 // 34 to awoid overwriting long. position
	 g.drawLine( 1,(int)sy,20,(int)sy);
	 spos = blc.y.toString(pformat);
	 CAux.drawString(g,spos, 22,(int)sy + fm.getHeight()/2 -2,1,Color.black);
	 blc.y.p += yCunit;
       }
    }     
  } 
  

  Pos screenPix2Pos(int sx, int sy){
    return(pix2pos(sx-tx, ty-sy));    
  }
  
  Pos pix2pos(int x, int y){
    // Convert offset in pixels from BottomLeftPos to pos.
    return(new Pos(
		   ((double) x)/xres + bottomLeftPos.x.p,
		   ((double) y)/yres + bottomLeftPos.y.p,
		   theCF.mMapDatum.theDatum
		   )
	   );
  }
  
  int pos2cx(Pos pos) {
    return ((int)lrnd((pos.x.p- bottomLeftPos.x.p)/fLong));
  }
  
  int pos2cy(Pos pos) {
    return ((int)lrnd((pos.y.p- bottomLeftPos.y.p/fLat)));
  }
  
  public boolean imageUpdate(Image img, int flags, int x, int y, int w, int h){
    if ((flags&ALLBITS)!=0) {
      CAux.perr("GMAP Image Update fin: "+img + "  fl="+flags + 
		"pos=(" + x + "," + y + ")" +
		"dim=(" + w + "," + h + ")",8);
      FullPaint = true;
      repaint(100);
    } 
    return (true);
  }
  

  synchronized void updCursor(Graphics g) {
    plotcCur(g,oldcCursor);
    plotcCur(g,cCursor);
    oldcCursor = cCursor;
  }
  
  public void update(Graphics g) {    

    if (FullPaint) {
      FullPaint = false;      
      CursorPaint = false;      
      NMEAPaint = false;      
      AnnoPaint = false;      
      g.clearRect(0, 0,ScreenWidth, ScreenHeight);
      paint1(g);
      annotate(g);
      return;      
    }  

    if (CursorPaint) {
      CursorPaint = false;      
      updCursor(g);
    }        

    if (NMEAPaint) {
      NMEAPaint = false;      
      plotTR_NMEA(g);
      return;
    }        
    
    if (AnnoPaint){
      AnnoPaint = false;      
      annotate(g);
    }
  }
  
  int ldv(int a,int b) {
    if (a>=0) {
      return (a/b);
    } else {
      return ((a-b+1)/b);
    }       
  }  

       
   
  public void paint(Graphics g) {
    //System.out.println("PAINT");
    boolean mustUpdate;
    try {
      mustUpdate = (ScreenWidth==getSize().width && ScreenHeight==getSize().height);
    } catch (NoSuchMethodError ex) {
      mustUpdate = (ScreenWidth==size().width && ScreenHeight==size().height);
    }
    
    if (mustUpdate){
      FullPaint = true;
      update(g);
    } else {      
      musync.upd(100);
    }    
  }


  public void ggoto(Pos newPos){
    int cx, cy;
    Pos newMapPos;
    theCF.horz.setValue(500);	  
    theCF.vert.setValue(500);	  
    newMapPos= newPos.toDatum(theCF.mapDatum());

    ttx = tx0 = (int)((newMapPos.x.p - bottomLeftPos.x.p)*xres - (double)ScreenWidth/2f);
    tty = ty0 = (int)((newMapPos.y.p - bottomLeftPos.y.p)*yres - (double)ScreenHeight/2f);
    FullPaint =true;
    CAux.perr("blp="+ bottomLeftPos,8);    
    //CAux.perr(" xres= " + xres + " p*xres="+(df.width)*xres,7);    
    CAux.perr("ggoto " + newPos + " ttx="+ttx+" tty="+tty,7);    
    musync.upd(0);    
    repaint(100);
  }
  


  public void jumpTo(Pos newPos, boolean center){
    int cx,cy;
    Pos newMapPos;
    
    newMapPos= newPos.toDatum(theCF.mapDatum());
    
    CAux.perr("Cleaning up XC=(" + XCharts+ ","+YCharts+")" + "cxy="+
	      "("+cx0 +","+cy0+") nlm="+nLoadMaps,3);
    
    CAux.perr("Jumping from "+ bottomLeftPos + ":XC(" + XCharts+ ","+YCharts+")",3);
    CAux.perr("Jumpto"+newMapPos,5);
    
    // Make sure we COPY here
    theCF.horz.setValue(500);	  
    theCF.vert.setValue(500);	  
    
    bottomLeftPos.x.p = newMapPos.x.p;
    bottomLeftPos.y.p = newMapPos.y.p;
    
    
    //System.out.println(" blp0 = " +bottomLeftPos + " xres ="+xres+ " yres ="+yres + "SH="+ScreenHeight);
    if (center) {
      bottomLeftPos.x.p -= ScreenWidth/xres/2;  
      bottomLeftPos.y.p -= ScreenHeight/yres/2;  
    }     
    bottomLeftPos.x.p = ((double)((int)(bottomLeftPos.x.p/fLong)))*fLong;
    bottomLeftPos.y.p = ((double)((int)(bottomLeftPos.y.p/fLat)))*fLat;

    CAux.perr("Jumping to "+ newPos +" blp="+bottomLeftPos,3);
    for (cx= -nLoadMaps; cx<=nLoadMaps; cx++){
      for (cy= -nLoadMaps; cy<=nLoadMaps; cy++){
	if (loadedMaps[cx+nLoadMaps][cy+nLoadMaps] != null){
	   loadedMaps[cx+nLoadMaps][cy+nLoadMaps].chart=null;
	   loadedMaps[cx+nLoadMaps][cy+nLoadMaps].tried=0;
	 }	  
      }
    }

    // We should at least holdt a screenful at this zooming     
    if (nLoadMaps <= XCharts || nLoadMaps <= YCharts) 
      {
	nLoadMaps = Math.max(XCharts,YCharts)+4;
	loadedMaps = new ChartInfo[nLoadMaps*2+1][nLoadMaps*2+1];	  
	CAux.perr("New LoadMaps",2);
      }
    
    
    ttx = tx0 = (int)((newMapPos.x.p - bottomLeftPos.x.p)*xres - (double)ScreenWidth/2f);
    tty = ty0 = (int)((newMapPos.y.p - bottomLeftPos.y.p)*yres - (double)ScreenHeight/2f);
    
    tx = -ttx;
    ty = tty + ScreenHeight;

    cx0 = ldv(-tx,ChartDim.width);
    cy0 = ldv(tty,ChartDim.height);
  
    cx1 = ldv((-tx+ScreenWidth-1),ChartDim.width);
    cy1 = ldv((tty+ScreenHeight-1),ChartDim.height);
    CAux.perr("Jumping to ttx="+ ttx+" tty="+tty,3);
  }  


  public void paintupd() {
  int cx,cy;
  String chartName;
  URL chartURL=null;
  lastZoom = theCF.zoom;
  Pos newPos=new Pos();
  
  oldpos="";

  ChartDim.height = (menv.naturalDim.height * theCF.zoom)/100;
  ChartDim.width = (menv.naturalDim.width * theCF.zoom)/100;
  
  try {
    ScreenWidth=getSize().width;
    ScreenHeight=getSize().height;
  } catch (NoSuchMethodError ex) {
    ScreenWidth=size().width;
    ScreenHeight=size().height;
  }
    
  XCharts= (ScreenWidth + ChartDim.width -1)/ ChartDim.width;
  YCharts= (ScreenHeight + ChartDim.height -1)/ ChartDim.height;

  yres = ChartDim.height / fLat;
  xres = ChartDim.width / fLong;  
  tx = -ttx;
  ty = tty + ScreenHeight;
  
  cx0 = ldv(-tx,ChartDim.width);
  cy0 = ldv(tty,ChartDim.height);
  
  cx1 = ldv((-tx+ScreenWidth-1),ChartDim.width);
  cy1 = ldv((tty+ScreenHeight-1),ChartDim.height);
  CAux.perr("paintupd ttx="+ttx+" tty="+tty,5);
  
  
  // System.out.println(" PUU tx = "+tx +" ty="+ty+" fLat="+fLat+" cy0="+ cy0);
  
  if ((Math.abs(cy0)+XCharts> nLoadMaps) || (Math.abs(cx0)+XCharts> nLoadMaps)) {
    newPos = screenPix2Pos(ScreenWidth/2,ScreenHeight/2);
    jumpTo(newPos, false);    
    tx = -ttx;
    ty = tty + ScreenHeight;
    FullPaint =true;
    repaint(500);
  }
  CAux.perr("cx0="+cx0+" cx1="+cx1+" cy0="+cy0+" cy1="+cy1,7);
  
  for (cx=cx0; cx<=cx1 && Math.abs(cx)<=nLoadMaps ;cx++){
    for (cy=cy0; cy<=cy1 && Math.abs(cy)<=nLoadMaps;cy++){
      //      System.out.println("EIMAGE"+"txy(" + tx +","+ ty + "/"+tty+ ")"	 );
      if (loadedMaps[cx+nLoadMaps][cy+nLoadMaps]==null ||
	  (loadedMaps[cx+nLoadMaps][cy+nLoadMaps].tried ==0)) {
	Pos thePos;
	String imgName;
	int imgSuffix;
	
	thePos = pix2pos(cx*ChartDim.width,cy*ChartDim.height);	
	// System.out.println(" p " + cx+","+cy+" = "+thePos.toString(1)+" to be loaded");
	
	imgName= thePos.toString(Pone.MD);
	imgSuffix = imgNames.indexOf(imgName);
	loadedMaps[cx+nLoadMaps][cy+nLoadMaps] = new ChartInfo();
	loadedMaps[cx+nLoadMaps][cy+nLoadMaps].tried=1;	
	try {	  
	  theCF.outArea.append("Loading chart: "+ " "+ imgName+"\n");
	} catch (NoSuchMethodError ex) {
	  System.out.println("Loading chart: "+ " "+ imgName+"\n");
	}
		
	if (imgSuffix>0) {
	  loadedMaps[cx+nLoadMaps][cy+nLoadMaps].tried=1;	
	  chartName = menv.chartdir+ "/" + imgName + 
	    imgNames.substring(imgSuffix+imgName.length(),
		imgSuffix+4+imgName.length());
	  try {
	    chartURL = new URL(menv.epsBase,chartName);
	  }catch (MalformedURLException me) {
	    System.out.println("MalformedURLException: " + me);
	  } 
	   //System.out.println("Map load imgs="+ imgSuffix + " cn="+chartName + 
	  //		     " URL:"+cx +","+cy+ " URL:"+ chartURL);
	  if (chartURL!=null){
	      loadedMaps[cx+nLoadMaps][cy+nLoadMaps].chart = 
	      getToolkit().getImage(chartURL);
	      if (!theCF.isJDK11) {
		getToolkit().prepareImage(loadedMaps[cx+nLoadMaps]
					  [cy+nLoadMaps].chart, 
					  ChartDim.width, ChartDim.height,this);
	      }
	  }
	} else {
	  //theCF.outArea.append("Chart file \"" + imgName + "\"  does not exist"+"\n");	  
	  CAux.perr("Chart file \"" + imgName + "\"  does not exist",1);	  
	}	
	
      }
      
      if (
	  (loadedMaps[cx+nLoadMaps][cy+nLoadMaps]!=null) &&
	  ((loadedMaps[cx+nLoadMaps][cy+nLoadMaps].chart!=null) 
	   //	  ||(loadedMaps[cx+nLoadMaps][cy+nLoadMaps].tried==0)
	   )
	  ) {
	loadedMaps[cx+nLoadMaps][cy+nLoadMaps].tried++;

	if (loadedMaps[cx+nLoadMaps][cy+nLoadMaps].zoom != theCF.zoom) {	    
	  loadedMaps[cx+nLoadMaps][cy+nLoadMaps].zoom= theCF.zoom;
	  if (!theCF.isJDK11) {
	    getToolkit().checkImage(loadedMaps[cx+nLoadMaps][cy+nLoadMaps].chart, 
				    ChartDim.width, ChartDim.height,this);
	    getToolkit().prepareImage(loadedMaps[cx+nLoadMaps][cy+nLoadMaps].chart, 
				      ChartDim.width, ChartDim.height,this);
	  }	  
	}
      } 
    }
  }
}


  public void paint1(Graphics g) {
    int cx,cy;
    
    g.setPaintMode();
    for (cx=cx0; cx<=cx1 && Math.abs(cx)<=nLoadMaps ;cx++){
      for (cy=cy0; cy<=cy1 && Math.abs(cy)<=nLoadMaps;cy++){
	if (
	    (loadedMaps[cx+nLoadMaps][cy+nLoadMaps]!=null) &&
	    ((loadedMaps[cx+nLoadMaps][cy+nLoadMaps].chart!=null) 
	     //	  ||(loadedMaps[cx+nLoadMaps][cy+nLoadMaps].tried==0)
	     )
	    ) {
	  loadedMaps[cx+nLoadMaps][cy+nLoadMaps].tried++;
	  
	  if (loadedMaps[cx+nLoadMaps][cy+nLoadMaps].zoom == theCF.zoom) {	    
	    // 	    System.out.println("Chart file cx("+cx+","+cy +  ")" +  
	    // 			       "cx0("+cx0+","+cy0  + " draw at " +
	    // 			       (tx+cx*ChartDim.width) +"," +
	    // 			       + (ty-(cy+1)*ChartDim.height));
	    

	    try {	      
	      int ch,cw;	      
	      Image theChart = loadedMaps[cx+nLoadMaps][cy+nLoadMaps].chart;
	      cw =theChart.getWidth(null);
	      ch = theChart.getHeight(null);
	      // Begin Use this with JDK 1.1
	      int dx1,dy1,dx2,dy2,sx1,sx2,sy1,sy2;
	      dx1=Math.max(tx + cx*ChartDim.width,0);
	      dx2=Math.min(tx + (cx+1)*ChartDim.width ,ScreenWidth);

	      dy1=Math.max(ty - (cy+1)*ChartDim.height,0);
	      dy2=Math.min(ty - (cy)*ChartDim.height,ScreenHeight);

	      sx1=Math.max(-(tx + cx*ChartDim.width),0);
	      sx2=ChartDim.width-Math.max(tx + cx*ChartDim.width +ChartDim.width - 
					  ScreenWidth,0);

	      sy1=Math.max(-(ty - (cy+1)*ChartDim.height),0);
	      sy2=ChartDim.height-Math.max(ty - (cy+1)*ChartDim.height +
					   ChartDim.height-ScreenHeight,0);

	      if (ch>0 && cw >0){
		sx1 = sx1 * cw/ChartDim.width;
		sx2 = sx2 * cw/ChartDim.width;
		sy1 = sy1 * ch/ChartDim.height;
		sy2 = sy2 * ch/ChartDim.height;
	      } else {
		// FIXME should wait for dimensions
		sx1 = sx1 *100/theCF.zoom;
		sx2 = sx2 *100/theCF.zoom;
		sy1 = sy1 *100/theCF.zoom;
		sy2 = sy2 *100/theCF.zoom;
	      }
	      
	      
	      g.drawImage(theChart, 
			  dx1, dy1, 
			  dx2, dy2,
			  sx1, sy1,
			  sx2, sy2,
			  this);
	      //     System.out.println(" src=("+sx1 +","+sy1+"),("+sx2 +","+sy2+"),"+
	      // 		       "dst=("+dx1 +","+dy1+"),("+dx2 +","+dy2+")");

	      // End Use this with JDK 1.1
	      //       img - the specified image to be drawn 
	      //       dx1 - the x coordinate of the first corner of the destination rectangle 
	      //       dy1 - the y coordinate of the first corner of the destination rectangle 
	      //       dx2 - the x coordinate of the second corner of the destination rectangle 
	      //       dy2 - the y coordinate of the second corner of the destination rectangle 
	      //       sx1 - the x coordinate of the first corner of the source rectangle 
	      //       sy1 - the y coordinate of the first corner of the source rectangle 
	      //       sx2 - the x coordinate of the second corner of the source rectangle 
	      //       sy2 - the y coordinate of the second corner of the source rectangle
	      if (!theCF.isJDK11){		
		theCF.isJDK11 = true;
		System.out.println(" is JDK11");
	      }	      
	    } catch (NoSuchMethodError e) {
	      theCF.isJDK11 = false;
	      g.drawImage(loadedMaps[cx+nLoadMaps][cy+nLoadMaps].chart, 
			  tx + cx*ChartDim.width, ty - (cy+1)*ChartDim.height,
			  ChartDim.width, ChartDim.height,this);
	    }
	  } 
	}
      }
    }
    plotcCur(g,cCursor);
  }  
}

class ChartInfo {
  Image chart;
  int tried;  
  int zoom = 100;
}

class Usync {
   private boolean again=true;
   private boolean working=false;
   private ImageGMap GMhandle;
   private int toWait=400;
  
   Usync(ImageGMap h) {
     GMhandle =h;
   }
   

   public synchronized void upd(int wt) {
     toWait = wt;
     if (working) {      
       again = true;
       notify();
     } else {
       again = true;    
       notify();
     }  
   }
   
   
   public synchronized boolean shouldWork() {
     boolean ta = again;
     again=false;
     working = ta;
     if (!ta) {
       try {
	 wait();
       } catch (InterruptedException e) {
       }        
       while (again){
	 again=false;
	 try {
	   wait(toWait);
	 } catch (InterruptedException e) {
	 }        
       }       
     }
     return (true);    
  }

}

