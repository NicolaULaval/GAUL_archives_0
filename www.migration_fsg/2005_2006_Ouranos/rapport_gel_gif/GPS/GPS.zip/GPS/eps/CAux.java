// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>
//
// Version 0.3.1 added n & t keys in ImageMap

import java.io.*;
import java.awt.*;
import java.net.*;
import java.util.Date;
import java.text.*;

class CAux {
  static int tLevel = 0;

  static SimpleDateFormat localDFTZ = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss z");
  static SimpleDateFormat localDFDKTZ = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss z");
  static SimpleDateFormat localDF = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
  static SimpleDateFormat localDFDE = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
  static SimpleDateFormat localDFISO = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
  static SimpleDateFormat localDFISOTZ = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss z");
  static SimpleDateFormat localOutDefault = localDFISOTZ;

  public static Date readDate(String ds) {
    SimpleDateFormat myf;
    try {
      if (ds.length()>19) {
	if (ds.charAt(4) == '.') {
	  myf=localDFISOTZ;
	} else {
	  myf=localDFDKTZ;
	}		
      } else {
	if (ds.charAt(2) == '.') {
	  myf = localDFDE;
	} else {
	  myf = localDF;
	}
      }
      return myf.parse(ds);
    }
    catch (ParseException me) {
      System.out.println("Could Not Parse: \"" + ds + "\" as Date ");
      System.out.println(" err: " + me);
      return (new Date(0L));      
    }    
    catch (IllegalArgumentException me) {
      CAux.perr("Could not parse: " + ds + me,-1);
    } catch (NullPointerException me) {
      CAux.perr("Could Not Parse: " + ds +me,-1);
      me.printStackTrace();
    }  
    return null;
  }
  
  public static String epsversion = "0.5.2";
  //     static Date a1990 = new Date(0L);
  //     static Date a1970 = new Date(0L);
  static long JavaGrmTimeDiff = 631152000000L - 2*43200000L; 
  /* - a1970.getTime() + a1990.getTime()*/

  static void fo(String so,DataOutputStream dos, TextArea ta) throws IOException{
    int fi;
    if (ta!=null){
      try {
	ta.append(so);
      } catch (NoSuchMethodError ex) {
	CAux.perr(so,0);
      }
    } else {
      dos.writeBytes(so);            
    }
  }

  static void perr(String theE, int level)  {
    if (level <= tLevel){
      System.out.println(theE);
      //System.out.flush();
    }    
  }
  
  static Date usecs2td (long usecs)    {
    return new Date(usecs + JavaGrmTimeDiff );
    }
  
/****************************************************************************/
/* Convert dat in seconds since 01/01/90 00:00:00                           */  
/****************************************************************************/
static  long dt2usecs(Date dt, int offset)
    {
      return  (dt.getTime() - JavaGrmTimeDiff);
    }


  static void drawString(Graphics g, String ss, int x, int y, int d,Color cl) {
    g.setColor(Color.white);
    g.drawString(ss, x-d,y);
    g.drawString(ss, x+d,y);
    g.drawString(ss, x,y+d);
    g.drawString(ss, x,y-d);
    g.setColor(cl);
    g.drawString(ss, x,y);
}


  static String spad(String ss, int len, char pc){
    int miss;
    String rs=ss;
    
    if (len<0){
      miss = -len - ss.length();
      while (miss-->0) {
	rs = pc + rs;
      }    
    } else {
      miss = len - ss.length();
      while (miss>0) {
	rs = rs + pc;
	miss--;	
      }    
    }    
    return(rs);
  }
  
  static String frds(double x,int dg){
    String rs = ""+frd(x,dg);
    double d1=frd(x,dg);
    int xi;

    rs = ""+((int) d1)+".";
    for (xi=0;xi<dg;xi++){
      d1 = 10d*(d1 - ((int) d1));
      rs = rs+((int) d1);      
    }
    if (dg==0)
      {
	rs = rs.substring(0,rs.length()-1);
      }
      return(rs);
  }


  // Bug in java
  static String frds0(double x,int dg){
    String rs = ""+frd(x,dg);
    double d1=frd(x,dg);
    int rsl,xi=0,pad;
    rsl = rs.length();
    while (xi < rsl &&rs.charAt(xi)!='.'){
      xi ++;
    }    
    if (xi>= rsl){
      rs = rs+".";
      pad = dg;
    } else {
      pad = xi+1+dg;
    }
    if (pad < rsl) {
      return(rs.substring(0,pad));
    } else {         
      return(spad(rs,pad,'0'));
    }
  }
 

  static double frd(double x,int dg){
    double md = Math.pow(0.1d,dg);
    double x1 = x+ md/2;
    return((double)(x1 - x1 % md));
  }
  
  static String getCol(String sp, int scol, char sep) {
//    System.out.println("scol "+scol+ " sp " + sp );
    int colStart, colEnd;
    int cc=scol;
    int spi=0;
    int spl=sp.length();
    String rs;    

    while (cc>0){
      cc--;
      while (spi<spl && sp.charAt(spi) != sep){
	spi++;
      }
      spi++;
      while (sep!=',' && spi<spl && sp.charAt(spi) == sep){
	spi++;
      }
    }
    colStart = spi;
    
    while (spi < spl && sp.charAt(spi) != sep){
      spi ++;      
    }
    colEnd = spi;
  
    //    System.out.println("s2: cc=" + cc +" cs:" + colStart + " ce:" + colEnd+ " scol="+scol + " sep="+sep+"x");
    rs = sp.substring(colStart,colEnd);
    
    return(rs);
  }

  static String readCharts(URL epsBase, String chartdir){
    int posFmt=0;
    URL tURL;
    BufferedReader dis;
    String inputLine;
    String rs = " ";
    try 
      {
	URL chartURL = new URL(epsBase,chartdir+"/index.html");
	
	dis = new BufferedReader(new InputStreamReader(chartURL.openStream()));
      
	//System.out.println("Ch open" + chartURL);
	while ((inputLine = dis.readLine())!=null){
	  if (inputLine.endsWith("Image")||
	      inputLine.endsWith("jpg")||
	      inputLine.endsWith("gif")){
	    int ss, se;
	    
	    if (((se = inputLine.indexOf(".jpg"))>0) ||
		((se = inputLine.indexOf(".gif"))>0)) {
	     ss = se-1;
	     //System.out.println("Ch se="+ se);
	     while (ss>=0 && inputLine.charAt(ss)!='\\' && inputLine.charAt(ss)!='/'){
	       ss --;
	     }	     
	     // System.out.println("Ch ss="+ ss);
	     String fs=inputLine.substring(ss+1,se+4);
	     rs = rs + " " + fs;	       
	   }
	 }
      }
    }
    catch (MalformedURLException me) {
      System.out.println("MalformedURLException: " + me);
    } catch (FileNotFoundException fe) {
      System.out.println("Charts file not found: " + fe);
    } catch (IOException ioe) {
      System.out.println("Charts Not found " + ioe);
  }
    
    //System.out.println("Ch rs="+ rs);
    return (rs);
    
  }
}
