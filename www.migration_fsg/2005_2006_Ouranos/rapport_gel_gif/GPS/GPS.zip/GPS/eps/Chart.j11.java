// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>
import java.awt.*;
import java.io.*;
import java.net.*;
import java.awt.event.*;

public class Chart extends java.applet.Applet implements ItemListener{
    Checkbox chbx;
      String PropertyFileName = null;
    int nIM=1;
    public void init() 
      //throws IOException 

    {     
      PropertyFileName = getParameter("PropertyFile");
      if (PropertyFileName==null) {
	PropertyFileName="eps.prp";
      }	    
      // System.out.println("GMenv:" + ge.toString());    
      chbx = new Checkbox("Start EPS");
      chbx.addItemListener(this);
      add(chbx);         
      }

    public void itemStateChanged(ItemEvent event) {
      if (nIM>0) {
	nIM--;
	ChartFrame1 window=null;
	try{
	  window = new ChartFrame1(new URL(getDocumentBase(),PropertyFileName));
	}
    
	catch (IOException ioe) {
	  System.out.println("Proporties Not found " + ioe);
	  System.exit(0);
	}
	window.inAnApplet = true;      
	window.setTitle("Elgaard GPS Chart");
	window.pack();
	window.show();
      }
    }
}
