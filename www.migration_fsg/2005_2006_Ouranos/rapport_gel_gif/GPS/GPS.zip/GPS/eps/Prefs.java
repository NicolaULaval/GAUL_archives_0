// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>

class Prefs{
  static public int DMS=0;
  static public  int DMM =1;
  static public  int DDD =2;
  static public  int UTM =3;
  static public  int BNG =4;
  static public  int ITM =5;
  static public  int SUI =6;
  
  static public  int  OKITEM		= 1;	/* OK button */
  static public  int  CANCELITEM		= 2;	/* Cancel button */
  static public  int  LISTITEM		=3;	/* Datum list */
  static public  int  DESCITEM		=4;	/* Datum description static text item */
  static public  int  DMSITEM		=5;	/* D�MM'SS.S" format radio button */
  static public  int  DMMITEM		=6;	/* D�MM.MMM' format radio button */
  static public  int  DDDITEM		=7;	/* D.DDDDD format radio button */
  static public  int  UTMITEM		=8;	/* UTM format radio button */
  static public  int  BNGITEM		=9;	/* British Grid format radio button */
  static public  int  ITMITEM		=10;	/* Irish Grid format radio button */
  static public  int  SUIITEM		=11;	/* Swiss Grid format radio button */ 
  static public  int  CREATITEM		=12;	/* Text file creator edit text item */ 
  static public  int 	OFFSETITEM	=13;	/* Local time - UTC offset edit text item */
  static public  int  DUMMYITEM		=14;  /* used so that one can set up the default item. */
  
  /* Resource ID's */
  
  static public  int  DIALOGID	= 129;
  
/* Maximum length of description field */
  
  static public  int  DESC_LEN	= 30;  

  short  datum;
  int format;
  double offset;
  char    Devise[] = new char[255];
}
