// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>

import java.awt.*;
import java.io.*;
import java.net.*;
import java.lang.Runtime;
import java.util.Date;
import java.text.*;
import java.util.Locale;
import netscape.security.PrivilegeManager;
import netscape.security.ForbiddenTargetException;


class TrackC {
  static int nTR=0, maxTR=200;
  static TRPos track[] = new TRPos[maxTR];
  static TRPos lastPlotted=new TRPos(null,null);
  static TRPos lastTimed=new TRPos(null,null);
  static double adist=0;
  static int mx,my;
  static boolean mfound=true;

  static void readTracks(URL epsBase, String trfile, int filf, GMenv menv){
    int posFmt=Pone.DDD;
    URL tURL;
    BufferedReader dis;
    String inputLine;
    int  lineN =0;
    menv.trfile = trfile;
    Datum pDatum = Pos.WGS84;

    try {	      
      if (epsBase !=null){
	tURL =new URL(epsBase,trfile);
	dis = new BufferedReader(new InputStreamReader(tURL.openStream()));
      } else {
	dis = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec(trfile+ " -dt").getInputStream()));
      }      
      if ((inputLine = dis.readLine())!=null){
	  if (filf==Pone.ffGPSTRANS){
	    if (inputLine.substring(0,7).equals("Format:")){
	      if (inputLine.substring(8,11).equals("DDD")){
		posFmt =Pone.DDD;
	      } else {
		posFmt =Pone.MDD;
	      }
	      int datumNo = Integer.parseInt(inputLine.substring(43,46));
	      pDatum = Pos.getGtDatum(datumNo);
	      inputLine = dis.readLine();
	    }	  
	  } else if (filf==Pone.ffGRM){
	    while ((inputLine = dis.readLine()) != null &&
		   inputLine.length()==0 ||
		   inputLine.charAt(0)!='T') {
	    }
	  }
	
	  while ((inputLine = dis.readLine()) != null) {
	    lineN++;
	    if (inputLine.length()<3){
	      insertTrack(new TRPos(null,new Date(0)));
	    }else{
	      TRPos newTP;
	      
	      newTP = new TRPos();
	      if (filf==Pone.ffGPSTRANS){
		String ds;
		newTP.tpos.y =  Pone.str2Pone(inputLine,2,posFmt,filf);
		newTP.tpos.x =  Pone.str2Pone(inputLine,3,posFmt,filf);
		ds = CAux.getCol(inputLine,1,'\t');
		//System.out.println(" ds=" + ds);
		  newTP.tm = CAux.readDate(ds);
	      } else if (filf==Pone.ffGRM){
		newTP.tpos.y =  Pone.str2Pone(inputLine,1,posFmt,filf);
		newTP.tpos.x =  Pone.str2Pone(inputLine,2,posFmt,filf);
		  newTP.tm = CAux.readDate(inputLine.substring(26,44));
	      }
	      
	      //	    System.out.println(" parsing time"+CAux.getCol(inputLine,1,'\t'));
	      newTP.tpos.theDatum = pDatum;	      
	      insertTrack(newTP);
	      //	  System.out.println("new tr" +  " "+track[nTR].toString(0));
	      //	    System.out.println("new tr" +  " " + newTP.toString(1));
	    }
	  }
	}
	
	dis.close();
      }
      catch (MalformedURLException me) {
	System.out.println("MalformedURLException: " + me);
      } catch (FileNotFoundException fe) {
	System.out.println("Tracks file not found: " + fe);
      } catch (IOException ioe) {
	System.out.println("Track not found: " + ioe);
      } catch (StringIndexOutOfBoundsException ioe) {
	System.out.println("Could not read Track file line" + lineN);
	ioe.printStackTrace();
      } catch (NumberFormatException ioe) {
	System.out.println("Could not read Track file " + ioe);
	ioe.printStackTrace();
      } catch (SecurityException ioe) {
	System.out.println("tr read not allowed " + ioe);
      }      
    }
    
  static void deleteAll()     {
      nTR=0;
    }
  
  static void insertTrack(TRPos tr){
    if (nTR>= maxTR) {
      int xi;
      TRPos t0[] = track;
      track = new TRPos[2*maxTR];      
      for (xi=0; xi<maxTR; xi++){
	track[xi] = t0[xi];    
      }            
      maxTR=2*maxTR;
    }
    track[nTR]=tr;      
    nTR++;
  }


  static public void output(TextArea ta, int ff,int off,Datum datum, String fn, String gt){
    String tmp_file = "/tmp/gpstrans_upl_track";
    String fn1 = fn;      
    try {
      boolean ferr = false;
      DataOutputStream dos;

      try {
	PrivilegeManager.enablePrivilege("UniversalFileWrite" /*, fn1*/);
      } catch (ForbiddenTargetException me) {
	CAux.perr("No FTE PM",3);
      } catch (NoClassDefFoundError me) {
	CAux.perr("No TR PM",3);
//       } catch (IOException me) {
// 	CAux.perr("IO problem" + me,3);
      }
	try {
	  if (gt!=null){
	    fn1 = tmp_file;
	  }
	  File oFile = new File(fn1);
	  dos = new DataOutputStream(new FileOutputStream(oFile));
	  output(null,dos,ff,off,datum);
	}
      catch (SecurityException me) {
	ferr= true;
	System.out.println(" SecurityException: " + me);
      }
      catch (IOException me) {
	System.out.println(" File IOException: Upl TR" + me);
	ferr= true;
      }    
      
    if (gt!=null){
      Process prc;
      prc = Runtime.getRuntime().exec(gt + " -ut " + tmp_file);
    } else if (ta!=null && ferr){
      ta.setText("");
      output(ta,null,ff,off,datum);
    }
    }
    
    catch (IOException me) {
      System.out.println(" File IOException: Upl TR" + me);
    }    
  }

  static public void output(TextArea ta, DataOutputStream dos, int ff, int off, Datum datum)
    throws IOException{
    int nt;
    String Soff = ""+off;
    String Sdatum = ""+datum.gpstransNo;
    String is = "Format: DDD  UTC Offset:" + "    ".substring(0,4-Soff.length()) + Soff +
      ".00 hrs  Datum["+ "000".substring(0,3-Sdatum.length()) + Sdatum+
      "]:"+datum.name+"\n";
    if (ff==Pone.ffGPSTRANS){
      CAux.fo(is,dos,ta);
      for (nt=0; nt < nTR; nt++){
	if (track[nt]==null || track[nt].tpos==null){
	  CAux.fo("\n",dos,ta);
	} else {	  
	  Date dt = track[nt].tm;
	  String dstr = CAux.localOutDefault.format(dt);

	  CAux.fo("T" + "\t" + 
		  dstr +
		  "\t"+ track[nt].tpos.toDatum(datum).toString(Pone.pfGPSTRANS)+
		  "\n",dos,ta);
	}    
      }     
      if (dos !=null){
	dos.close();
      }
    } else if (ff==Pone.ffGARLINK) {
      CAux.fo("Sorry, don't know this track file format\n",dos,ta);
    }
  }
}
