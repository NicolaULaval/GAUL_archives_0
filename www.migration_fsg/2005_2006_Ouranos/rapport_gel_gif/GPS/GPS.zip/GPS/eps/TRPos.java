// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>

import java.util.Date;

class TRPos {
  Pos tpos;
  Date tm;;
  
  TRPos(){
    tpos  = new Pos();
    tm = new Date(44);
  }
    
  TRPos(Pos p, Date t){
    tpos = p;
    tm = t;    
  }

  public String toString() {
    if (tpos == null) {
      return(" null tpos");
    } else {
      return(tpos.toString(1));
    }
  }

  public String toString(int pf) {
    return(tpos.toString(pf)+":"+tm);
  }
}

