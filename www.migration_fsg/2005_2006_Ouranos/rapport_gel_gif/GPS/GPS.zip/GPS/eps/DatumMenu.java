import java.awt.*;

class DatumMenuItem extends MenuItem {
public Datum theDatum = Pos.WGS84;
  DatumMenuItem(String lb,Datum d)  {      
    super(lb);
    theDatum =d;  
  }

// public boolean postEvent(Event event) {
//   System.out.println("DMI PE: ");
//   return false;  
// }    
 }


class DatumMenu extends Menu {
public Datum theDatum = Pos.WGS84;
  MenuItem now = new MenuItem("now: WGS84");
    public ImageGMap IGMCanvas;  

  DatumMenu(String name) {
    
    super(name);
    
    int di=0;   
    add(now);  
    addSeparator();   
    while (Pos.datumList[di]!=null) {     
      add (new DatumMenuItem(Pos.datumList[di].name, Pos.datumList[di]));
      di++;     
    }
  }
  
public void setDatum(Datum d) {
  theDatum =d;
  now.setLabel("now: "+theDatum.name);
  //Could be done more elegant in Java 1.1
  
}

public boolean postEvent(Event event) {
  //System.out.println("DM PE: " + event);
  if (event.target == now){
    return true;
  }  
  IGMCanvas.FullPaint=true;
  IGMCanvas.repaint(50);
  setDatum(((DatumMenuItem) event.target).theDatum);
  //System.out.println("Map now: " + theDatum.name);
  return true;  
}    
}

