// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>
import  java.util.Date;

  
class WayPoint {
  Pos wpos;
  String name;
  String comment = "NO COMMENT";
  Date timestamp = new Date(0);
    boolean isnew;
  GTime wtime;
  int routeHere = 0; // for plotting purposes
	

  WayPoint(){
    wpos = new Pos();
  }
  
  WayPoint(String nm, Pos pos){
    name = nm;
    wpos = pos;
  }

  WayPoint(String nm, Pos pos, String co){
    name = nm;
    wpos = pos;
    comment = co.toUpperCase();    
  }

  WayPoint(String nm, Pos pos, String co, Date ts){
    name = nm;
    wpos = pos;
    comment = co.toUpperCase();
    timestamp = ts;    
  }
  
  public String toString() {
    return toString(Pone.MDD);    
  }
  public String toString(int pf) {
    return(name + " at " + wpos.toString(pf));
  }
}
