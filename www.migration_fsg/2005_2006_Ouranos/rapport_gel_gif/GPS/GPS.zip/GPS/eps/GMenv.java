// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>

import java.io.*;
import java.awt.*;
import java.net.*;


class GMenv {
  String wpfile, rtfile="r0.rt", trfile="t0.trk", chartdir="charts";
  URL epsBase;
  Dimension naturalDim = new Dimension(960,560);
  int cw=10, ch=10;
  String fileFormat="gpstrans";
  String posFormat="1";
  String gtpgm;
  int UTC_off=0;
   DatumMenu positionDatum;
  DatumMenu chartDatum;
  
  double initLat=55.9089,initLong=12.6779;

  GMenv() {
    try {
      epsBase = new URL("http://www.diku.dk/users/elgaard/eps/");
    } catch (MalformedURLException ioe) {
      System.out.println("m ex prp  " + ioe);
    }
  }
  
  GMenv(String W, String R, String T,  String cd, URL ebase, Dimension nd, int cw0, 
	int ch0, String ff, String pf, String gt, DatumMenu mdatum,DatumMenu pdatum, double iLa, double iLo){
    wpfile = W;
    rtfile = R;
    trfile = T;
    chartdir = cd;
    epsBase = ebase;
    naturalDim = nd;    
    cw=cw0;    
    ch=ch0;
    fileFormat=ff;        
    posFormat=pf;        
    gtpgm=gt;
    //UTC_off = off;
    chartDatum = mdatum;
    positionDatum = pdatum;
    initLong = iLo;
    initLat = iLa;
  }

  public String toString() 
    {
      return("wf=" + wpfile+ " rf=" + rtfile + " tr="+trfile+ " cd ="+chartdir + 
	     "\n EPS Base=" +epsBase   + "\nnd=" + 
	     naturalDim + "\nch " + ch + " cw " + cw + " fileFormat="+fileFormat+
	     " posFormat="+posFormat+
	     " gtpgm="+gtpgm+
	     " chart datum=" +chartDatum.theDatum.name + " pos datum=" + positionDatum.theDatum.name + 
	     " dlo="+initLong+" dLa="+initLat);      
    }
  
}
