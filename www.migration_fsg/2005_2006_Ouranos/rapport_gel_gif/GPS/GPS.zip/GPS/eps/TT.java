import java.awt.*;
import  java.text.*;
import  java.util.Date;
class TT {
  static public void main(String argv[]) {
    Date a1990 = new Date(1990,1,1);
    Date a1970 = new Date(1970,1,1);
    System.out.println("diff="+ (a1990.getTime()-a1970.getTime()));

  }
}

