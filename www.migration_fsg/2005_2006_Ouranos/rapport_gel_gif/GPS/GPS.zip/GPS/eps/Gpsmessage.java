
// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>

// Garmin communication code is based on Gpstrans by Carsten Tschach 
// (tschach@zedat.fu-berlin.de)


/****************************************************************************/
/* Define Garmin-Protocol commands.                                         */
/****************************************************************************/
class Gpsmessage {  

  static public int  MAX_LENGTH = 100;	
  /* maximum length of Garmin binary message */
  // static public int MAX_LINE =200;
  /* data file maximum line length */


  /* Garmin message type characters */
  static public byte RTE_NAM =(byte)0x1d;	/* Route name record */
  static public byte RTE_WPT = (byte)0x1e;	/* Route waypoint record */
  static public byte ALM 		= (byte)0x1f;	/* Almanac record */
  static public byte TRK 	= (byte)0x22;	/* Track record */
  static public byte WPT 	=(byte)0x23;	/* Waypoint record */
  static public byte ACK 	=(byte)0x06;	/* Waypoint record */
  static public byte NACK 	=(byte)0x15;	/* Waypoint record */
  static public byte GMNID  = (byte)0x7e;    /* Request Garmin ID */
  static public byte GMNAK  = (byte)0x15;    /* NAK */
  static public byte NUMREC  = (byte)0x1b;    /* Number of DB records */
  static  double CONVERT  = 11930464.7111111111111d;        /* 2^31 / 180 */
  
  /* Transfer types */
  static public int ALMANAC	= 700;
  static public int ROUTE	=701;
  static public int TRACK	=702;
  static public int WAYPOINT	=703;
  static public int TOFF	=604;

  static public   boolean DEBUG = true;
  
  static public int NONE =0;
  static public int GARMIN =1;
  static public int NMEA =2;

  static byte m1[]	= {(byte)0xfe,(byte)0x01,(byte)0x20};     
  /* Get the model and version number */
  static byte m2[]	= {(byte)0x06,(byte)0x02,(byte)0xff,(byte)0x00};
  /* unknown */
  
  static byte p1[]	= {(byte)0x06,(byte)0x02,(byte)0x1b,(byte)0x00};
  /* Get 1st packet */
  static byte p2[]	= {(byte)0x06,(byte)0x02,(byte)0x0c,(byte)0x00};
  /* Get last packet */
  
  static byte alm1[]	= {(byte)0x0a,(byte)0x02,(byte)0x01,(byte)0x00};
  /* Send almanac command */
  static byte alm2[]	= {(byte)0x06,(byte)0x02,ALM,(byte)0x00}; 
  /* Get next packet */
  
  static byte trk1[]	= {(byte)0x0a,(byte)0x02,(byte)0x06,(byte)0x00};
  /* Get track command */
  static byte trk2[]	= {(byte)0x06,(byte)0x02,TRK,(byte)0x00};
  /* Get next packet */

  static byte wpt1[]	= {(byte)0x0A,(byte)0x02,(byte)0x07,(byte)0x00};
  /* Get waypoint command */
  static byte wpt2[]	= {(byte)0x06,(byte)0x02,WPT,(byte)0x00};
  /* Get next packet */

  static byte rte1[]     = {(byte)0x0a,(byte)0x02,(byte)0x04,(byte)0x00};
  /* Get route command */
  static byte rte2[]	= {(byte)0x06,(byte)0x02,RTE_NAM,(byte)0x00};
  /* Get next packet */

  static byte test[]     = {(byte)0x1c,(byte)0x02,(byte)0x00,(byte)0x00};
  /* Getting respond from Garmin */

  static byte gid4[]     = {(byte)0xfe,(byte)0x00};
  /* Get Garmin model & Software rev */
  static byte gid5[]     = {(byte)0x06,(byte)0x02,(byte)0xff,(byte)0x00};  

  static byte off1[]     = {(byte)0x0a,(byte)0x02,(byte)0x08,(byte)0x00};
  /* Turn Garmin Off */
  static byte tim1[]     = {(byte)0x0a,(byte)0x02,(byte)0x05,(byte)0x00};
  /* Get UTC Time */

  static byte almt[]	= {(byte)0x0c, (byte)0x02, (byte)0x01, (byte)0x00};
  /* Almanac data base terminator */
  static byte rtet[]	= {(byte)0x0c, (byte)0x02, (byte)0x04, (byte)0x00};
  /* Route data base terminator */
  static byte trkt[]	= {(byte)0x0c, (byte)0x02, (byte)0x06, (byte)0x00};
  /* Track data base terminator */
  static  byte wptt[]	= {(byte)0x0c, (byte)0x02, (byte)0x07, (byte)0x00};
  /* Waypoint data base terminator */

/****************************************************************************/
/* Converts Garmin integer format to double precision decimal degrees.      */
/****************************************************************************/
  static double int2deg(long n) {
    double  res;
    res = (double) ((double)n / CONVERT);
    return (res);
  }

  static  boolean isDEBUG()
  {
    return DEBUG;
  }
 
  /****************************************************************************/
  /* Converts double precision decimal degrees to Garmin integer format.      */
  /****************************************************************************/
  static int deg2int(double x)
  {
    int res; 
    res = (int) (x * CONVERT);
    return (res);
  }
}

