
// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>

import java.awt.*;
import java.lang.Math;
import java.io.*;
import java.net.*;
import java.util.Properties;
import  java.util.Date;
import java.util.Locale;
import java.awt.event.*;
import netscape.security.PrivilegeManager;
import netscape.security.ForbiddenTargetException;

class ChartFrame1 extends ICF {
  ImageGMap IGMCanvas;
  static Dimension mS = new Dimension(500,400);
  static Dimension pS = new Dimension(800,700);
  

  static Properties applicationProps = new Properties();
  static boolean isWin = true;
  GMenv epsEnv;  
  boolean inAnApplet = false;
  float zzoom = 1;  
  int activeRoute;
  Toolkit toolK = this.getToolkit();
  ChartFrame1 myself=this;
  
  boolean sjump=false;
  String loadFile="w2.swp";  
  TextField loadFileArea = new TextField("",15);
  TextField NameArea = new TextField("",6);
  String jvver;
  String jver;
  String jcver;
  boolean NMEAactive = false;
  Thread hThread;
  Thread GMThread;
  Label zoomLabel = new Label("  100% zoom", Label.RIGHT);
  Label NMEALabel = new Label("");
  List routeWPList = new List(10, false);
  GrmInWPMIAC grmInWPListener = new GrmInWPMIAC();
  GrmInRouteMIAC grmInRouteListener = new GrmInRouteMIAC();
  GrmInTrackMIAC grmInTrackListener = new GrmInTrackMIAC();

  GrmOutWPMIAC grmOutWPListener = new GrmOutWPMIAC();
  GrmOutRouteMIAC grmOutRouteListener = new GrmOutRouteMIAC();
  GrmOutTrackMIAC grmOutTrackListener = new GrmOutTrackMIAC();
  Scrollbar zoomSlider;
  Button loadWPBut, loadTRBut, loadRTBut;
  Button addWPBut,addPWPBut, gotoWPBut, addRTBut, addWPRTBut;
  MenuItem exitMI =new MenuItem("Exit");
  MenuItem saveOptionsMI =new MenuItem("Save options");
  MenuItem grmInMI =new MenuItem("input WP + Route + track from GPS Unit");

  MenuItem grmInRouteMI =new MenuItem("  input Route from GPS Unit");
  MenuItem grmInWPMI =new MenuItem("  input WP from GPS Unit");
  MenuItem grmInTrackMI =new MenuItem("  input Track from GPS Unit");

  MenuItem grmOutMI =new MenuItem("output WP + Route + track to GPS Unit");
  MenuItem grmOutRouteMI =new MenuItem("  output Route to GPS Unit");
  MenuItem grmOutWPMI =new MenuItem("  output WP to GPS Unit");
  MenuItem grmOutTrackMI =new MenuItem("  output Track to GPS Unit");

  MenuItem NMEAMI =new MenuItem("Display NMEA output");
  MenuItem StopMI =new MenuItem("Stop Communication");
  
  MenuItem trDelMI =new MenuItem("Track");
  MenuItem allDelMI =new MenuItem("All (wp,track, and route)");
  MenuItem wpDelMI =new MenuItem("WayPoint");
  MenuItem rtDelMI =new MenuItem("Route");
  MenuItem rtwpDelMI =new MenuItem("WayPoint from Route");

  //MenuItem SetUTCMI;
  MenuItem SetNHMI;
  MenuItem SetNWMI;
  MenuItem SetCHMI;
  MenuItem SetCWMI;
  //MenuItem SetCDWMI;
  MenuItem SetIPWMI;
  MenuItem SetGTWMI;

  MenuItem printMI =new MenuItem("Print");
  MenuItem printChartMI =new MenuItem("Print Chart");
  MenuItem wpMI =new MenuItem("WayPoints");
  MenuItem pf1MI =new MenuItem("Positions as d.dddd");
  MenuItem pf2MI =new MenuItem("Positions as d\u00b0mm.mm\'");
  MenuItem ffGPSTRANSMI =new MenuItem("GPStrans file format");
  MenuItem ffGLMI =new MenuItem("GARLINK file format");
  MenuItem ffGRMMI =new MenuItem("GARMIN file format");
  MenuItem trMI = new MenuItem("Track");  
  MenuItem trcMI = new MenuItem("Track");
  MenuItem rMI = new MenuItem("Routes");
  MenuItem rcMI = new MenuItem("Routes");

  MenuItem SetPortName;

  Label WPLLabel = new Label("WayPoints");
  Panel WPLPanel = new Panel();
  Panel WActionPanel = new Panel();
  Label RouteLLabel = new Label("Routes");
  Panel RouteLPanel = new Panel();
  Panel WayPointLPanel = new Panel();
  Label RouteWPLLabel = new Label("WP's in Route");
  Panel RouteWPLPanel = new Panel();
  
  Panel addPanel = new Panel();
  Panel bottomPanel = new Panel();
  Panel IGMPanel = new Panel();
  Panel centerPanel = new Panel();
  Panel loadPanel = new Panel();
  Panel inputPanel = new Panel();
  Panel wpPanel = new Panel();

  Panel posPanelLat = new Panel();
  Panel posPanelLong = new Panel();
  NSEW NSArea = new NSEW('N');
  NSEW EWArea = new NSEW('E');
  PosField LatPosDegree;
  PosField LongPosDegree;
  PosField LatPosMin;  
  PosField LongPosMin;
  
  Label dgLabelLat = new Label("\u00b0", Label.LEFT);
  Label mnLabelLat = new Label("\'", Label.LEFT);
  Label dgLabelLong = new Label("\u00b0", Label.LEFT);
  Label mnLabelLong = new Label("\'", Label.LEFT);

  
//   Menu routeMenu = new Menu("Route");
  //   Menu wayPointMenu= new Menu("Route");
  MenuBar mb = new MenuBar();
  Menu mf = new Menu("File");
  Menu mo = new Menu("Save");
  Menu mclr = new Menu("Clear");
  Menu mPosFormat = new Menu("Pos. Formats");
  Menu mFileFormat = new Menu("File Formats");
  Menu mDelete = new Menu("Delete");
  Menu mSet = new Menu("Set");
   URL propURL;

  public ChartFrame1(URL ep) {
    PanAdapter aPanAdapter;    
    propURL = ep;
    String cD="default", pD = "default";
    URL tbase = null;

    try{
      URL tURL;
      System.out.println("base is: " + ep);
      //  tURL =new URL(base,PropertyFileName);
      DataInputStream appStream = new DataInputStream(ep.openStream());
      applicationProps.load(appStream);
      appStream.close();
    }
    catch (FileNotFoundException fe) {
      System.out.println("Proporties file not found: " + fe);
      System.exit(0);
    } catch (IOException ioe) {
      System.out.println("Proporties Not found " + ioe);
      System.exit(0);
    }
    try {
      String baseS = applicationProps.getProperty("eps.base");
      if (baseS != null){
	tbase = new URL(baseS);
      }
	
      if (tbase == null) {
	tbase = ep;
      }
      
      cD = applicationProps.getProperty("eps.ChartDatum","WGS84");
      pD = applicationProps.getProperty("eps.PositionDatum","WGS84");


      //System.out.println("pd: \"" + cD +"\""+",\"" +pD+"\"");
      //System.out.println("pdd: " + mMapDatum.theDatum.name +":" +mPositionDatum.theDatum.name);
      
      epsEnv = new GMenv(applicationProps.getProperty("eps.wpts"),
		 applicationProps.getProperty("eps.routes",null),
		 applicationProps.getProperty("eps.track",null),
		 applicationProps.getProperty("eps.chartdir"), 
		 tbase,
		 new Dimension(
			   Integer.parseInt(applicationProps.getProperty("eps.naturalWidth")),
			   Integer.parseInt(applicationProps.getProperty("eps.naturalHeight"))
			   ),
		 Integer.parseInt(applicationProps.getProperty("eps.ChartWidth")), 
		 Integer.parseInt(applicationProps.getProperty("eps.ChartHeight")),
		 applicationProps.getProperty("eps.fileFormat",null),
		 applicationProps.getProperty("eps.posFormat",null),
		 applicationProps.getProperty("eps.gpstranspgm",null),
			 //Integer.parseInt(applicationProps.getProperty("eps.UTCoff","0")),
			 
		 mMapDatum,
		 mPositionDatum,
		 Double.valueOf(applicationProps.getProperty("eps.initLatitude","55")).doubleValue(),
		 Double.valueOf(applicationProps.getProperty("eps.initLongitude","12")).doubleValue()
		 );
      Garmincomm.portName = applicationProps.getProperty("eps.portName",null);
      isWin = System.getProperty("os.name").toUpperCase().indexOf("WINDOWS") >=0;

      
      if (Garmincomm.portName == null){
        if (isWin) {
          Garmincomm.portName = "COM1";          
        } else {
          Garmincomm.portName = "/dev/cua0";          
        }                
      }      
      SetPortName =new MenuItem("Port name: "+ Garmincomm.portName);
    }  
    catch (MalformedURLException fe) {
      System.out.println(" URL: " + fe);
    }    

    Garmincomm.setup();
    
    mMapDatum = new DatumMenu("Chart Datum");
    mPositionDatum = new DatumMenu("Position Datum");
    mMapDatum.setDatum(Pos.getNamedDatum(cD));
    mPositionDatum.setDatum(Pos.getNamedDatum(pD));
      
    epsEnv.chartDatum =mMapDatum;
    epsEnv.positionDatum =mPositionDatum;
    horz = new Scrollbar(Scrollbar.HORIZONTAL,500,25,0,1025);
    vert = new Scrollbar(Scrollbar.VERTICAL  ,500,25,0,1025);
    horz.setUnitIncrement(25);
    vert.setUnitIncrement(25);

    horz.addAdjustmentListener(new PanAdapter(false));
    vert.addAdjustmentListener(new PanAdapter(true));
    
   pLabel = new Label("Position                                                                   ", 
		      Label.LEFT);   
    

   //SetUTCMI =new MenuItem("Offset to UTC: "+epsEnv.UTC_off);
  SetNHMI =new MenuItem("Natural Height: "+epsEnv.naturalDim.height);
  SetNWMI =new MenuItem("Natural Width: "+epsEnv.naturalDim.width);
  SetCHMI =new MenuItem("Chart Height: "+epsEnv.ch);
  SetCWMI =new MenuItem("Chart Width: "+epsEnv.cw);
  //SetCDWMI =new MenuItem("Chart Datum: "+epsEnv.Chart_Datum);
  SetIPWMI =new MenuItem("Initial Position: "+ (new Pos(epsEnv.initLong,
				        epsEnv.initLat,
				        mMapDatum.theDatum)).toString(posFm));
  //SetGTWMI =new MenuItem("gpstrans pgm: "+ epsEnv.gtpgm);
  
    grmInMI.addActionListener(grmInWPListener);
    grmInMI.addActionListener(grmInRouteListener);
    grmInMI.addActionListener(grmInTrackListener);

    grmOutMI.addActionListener(grmOutWPListener);
    grmOutMI.addActionListener(grmOutRouteListener);
    grmOutMI.addActionListener(grmOutTrackListener);

    grmInWPMI.addActionListener(grmInWPListener);
    grmInTrackMI.addActionListener(grmInTrackListener);
    grmInRouteMI.addActionListener(grmInRouteListener);

    grmOutWPMI.addActionListener(grmOutWPListener);
    grmOutTrackMI.addActionListener(grmOutTrackListener);
    grmOutRouteMI.addActionListener(grmOutRouteListener);

    NMEAMI.addActionListener(new NMEAMIAC());
    StopMI.addActionListener(new StopMIAC());
    trDelMI.addActionListener(new TrDelMIAC());
    wpDelMI.addActionListener(new WpDelMIAC());
    rtwpDelMI.addActionListener(new RtwpDelMIAC());
    allDelMI.addActionListener(new AllDelMIAC());
    rtDelMI.addActionListener(new RtDelMIAC());

    //SetUTCMI.addActionListener(new SetUTCMIAC());
    SetNHMI.addActionListener(new SetNHMIAC());
    SetNWMI.addActionListener(new SetNWMIAC());
    SetCHMI.addActionListener(new SetCHMIAC());
    SetCWMI.addActionListener(new SetCWMIAC());
    SetIPWMI.addActionListener(new SetIPWMIAC());
    SetPortName.addActionListener(new SetPortNameAC());
    printMI.addActionListener(new PrintMIAC());
    printChartMI.addActionListener(new PrintChartMIAC());
    wpMI.addActionListener(new WpMIAC());
    rMI.addActionListener(new RMIAC());
    trMI.addActionListener(new TrMIAC());
    ffGPSTRANSMI.addActionListener(new FfGPSTRANSMIAC());
    ffGRMMI.addActionListener(new FfGRMMIAC());
    ffGLMI.addActionListener(new FfGLMIAC());
    pf1MI.addActionListener(new Pf1MIAC());
    pf2MI.addActionListener(new Pf2MIAC());
    exitMI.addActionListener(new ExitMIAC());
    saveOptionsMI.addActionListener(new SaveOptionsMIAC());

  setFont(fh12);
  LatPosDegree = new PosField(false,3,90d);
  LongPosDegree = new PosField(false,3,180d);
  LatPosMin = new PosField(true,7,60d);
  LongPosMin = new PosField(true,7,60d);
  
  WPLPanel.setLayout(new BorderLayout());
  routeMenu = new Menu("Route");
  WActionPanel.setLayout(new BorderLayout());
  RouteWPLPanel.setLayout(new BorderLayout());
  RouteLPanel.setLayout(new BorderLayout());
  WayPointLPanel.setLayout(new BorderLayout());
  
  IGMPanel.setLayout(new BorderLayout());
  loadPanel.setLayout(new GridLayout(0,5));
  inputPanel.setLayout(new GridLayout(0,1));
  addPanel.setLayout(new FlowLayout());
  posPanelLat.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
  posPanelLong.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
  
  wpPanel.setLayout(new GridLayout(5,1));
  bottomPanel.setLayout(new BorderLayout());
  waypointList = new List(15, false);
  waypointList.setForeground(Color.red);
  
  routeList = new List(10, false);
  waypointList.addActionListener(new gotoWPButAC());
  waypointList.addItemListener(new WPListAdapter());
  routeList.addItemListener(new RTListAdapter());
  routeList.setForeground(Color.blue);
  routeList.setBackground(Color.white);
   
  routeWPList.setForeground(Color.blue);
  routeWPList.setBackground(Color.white);
  waypointList.setBackground(Color.white);
   
  fh20 = new Font("Helvetica", Font.PLAIN, 20); 
  fh14 = new Font("Helvetica", Font.PLAIN, 14); 
  fh14b = new Font("Helvetica", Font.BOLD, 14); 
  fh12 = new Font("Helvetica", Font.PLAIN, 12); 
  
  try {
    int joff;
    jver = System.getProperties().getProperty("java.version");
    jcver = System.getProperties().getProperty("java.class.version");
     
    
    System.out.println(" We are running java " + jver + " c "+jcver );
     jcver = System.getProperties().getProperty("java.class.version");
     System.out.println("    class " + jcver);
     jvver = System.getProperty("java.vendor");
     System.out.println("    vendor " + jvver);
     System.out.println("    os= " + System.getProperty("os.name") + ", " +
			System.getProperty("os.arch") +", " +
			System.getProperty("os.version") 	    							);
     //System.out.println("    prp " + System.getProperties());
  } catch (SecurityException ioe) {
    System.out.println("Could not read system properties " + ioe);
  }

  int posFm = 1;  
   if (epsEnv.fileFormat!= null){
     if (epsEnv.fileFormat.equals("gpstrans")){
       fileFormat=Pone.ffGPSTRANS;
     } else if (epsEnv.fileFormat.equals("garlink")){
       fileFormat=Pone.ffGARLINK;  
     } else if (epsEnv.fileFormat.equals("garmin")){
       fileFormat=Pone.ffGRM;
     }
   }
      
   setBackground(new Color(173, 223, 255));
   setForeground(Color.black);
   setLayout(new BorderLayout());
  //Set up the menu bar.
   posPanelLat.add(LatPosDegree);
   posPanelLat.add(dgLabelLat);
   posPanelLat.add(LatPosMin);
   posPanelLat.add(mnLabelLat);
   posPanelLat.add(NSArea);

   posPanelLong.add(LongPosDegree);
   posPanelLong.add(dgLabelLong);
   posPanelLong.add(LongPosMin);
   posPanelLong.add(mnLabelLong);
   posPanelLong.add(EWArea);

   mo.add(wpMI);
   mo.add(rMI);
   mo.add(trMI);
   mo.add(printChartMI);
   mo.add(printMI);

   //mSet.add(SetUTCMI);
   mSet.add(SetNHMI);
   mSet.add(SetNWMI);
   mSet.add(SetCHMI);
   mSet.add(SetCWMI);
   mSet.add(SetIPWMI);
   //mSet.add(SetGTWMI);
   mSet.add(SetPortName);
   //   mSet.add(SetEpscomm);
   
   mDelete.add(allDelMI);
   mDelete.add(wpDelMI);
   mDelete.add(rtDelMI);
   mDelete.add(rtwpDelMI);
   mDelete.add(trDelMI);

   //mFileFormat.add(ffGPSTRANSMI);
   mFileFormat.add(ffGRMMI);
   mFileFormat.add(ffGLMI);
   mPosFormat.add(pf1MI);
   mPosFormat.add(pf2MI);

   mf.add(exitMI);
   mf.add(StopMI);
   mf.add(saveOptionsMI);
   //mf.add(grmInMI); //Carefull here
   mf.add(grmInWPMI);
   mf.add(grmInRouteMI);
   mf.add(grmInTrackMI);
   // mf.add(grmOutMI); // do not do it
   mf.add(grmOutWPMI);
   mf.add(grmOutRouteMI);
   mf.add(grmOutTrackMI);
   mf.add(NMEAMI);
   mb.add(mf);
   mb.add(mo);
   mb.add(mPosFormat);
   mb.add(mFileFormat);
   mSet.add(mMapDatum);
   mSet.add(mPositionDatum);
   mb.add(mDelete);
   mb.add(mSet);
   setMenuBar(mb);
   outArea = new TextArea(
			  "Elgaard Positioning System (EPS)\n"+
			  "version "+CAux.epsversion+", Copyright (C) 1997, \n"+
			  "Niels Elgaard Larsen\n"+
			  "EPS comes with ABSOLUTELY NO WARRANTY.\n"+
			  "This is free software, and you are \nwelcome to redistribute it"+
			  "under certain conditions;\n"	  
			  ,10,5);
   outArea.setEditable(false);
   IGMCanvas = new ImageGMap(epsEnv, (ICF)this);
   mPositionDatum.IGMCanvas = IGMCanvas;
   mMapDatum.IGMCanvas = IGMCanvas;
   hThread = new Thread(IGMCanvas,"EPS thread");
   hThread.start();
//    System.out.println(" blp= " + IGMCanvas.bottomLeftPos.toString(Pone.MALL));
//    System.out.println(" ny pos"+ (new Pos(epsEnv.initLong,epsEnv.initLat)));
//    System.out.println(" env: " +epsEnv);
   //Add small things at the bottom of the window.
   
//   bottomPanel.add(chbx);
//   posFormat.addItem("Positions as d.dddd");
//   //  posFormat.addItem("Positions as d�mm.mm\'");
//   posFormat.addItem("Positions as dgmm.mm\'");
//   bottomPanel.add("West",posFormat);


   zoomSlider=new Scrollbar(Scrollbar.HORIZONTAL, 100, 5, 10, 1000);
   zoomSlider.addAdjustmentListener(new ZoomAdapter());
   zoomSlider.setSize(50,20);   
   bottomPanel.add("East",zoomLabel);
   bottomPanel.add("Center",zoomSlider);

   bottomPanel.add("North",pLabel);
   add("South", bottomPanel);
  
   loadWPBut = new Button("Load Waypoints");
   loadRTBut = new Button("Load Routes");
   addWPBut = new Button("Add cursor WP");
   addPWPBut = new Button("Add Pos. WP");
   gotoWPBut = new Button("Goto Waypoint");
   addRTBut = new Button("Add Route");
   addWPRTBut = new Button("Add WP to Route");
   loadTRBut = new Button("Load Track");
   loadWPBut.addActionListener(new LoadWPButAC());
   loadRTBut.addActionListener(new LoadRTButAC());
   addWPBut.addActionListener(new addWPButAC());
   addPWPBut.addActionListener(new addPWPButAC());
   gotoWPBut.addActionListener(new gotoWPButAC());
   addWPRTBut.addActionListener(new addWPRTButAC());
   loadTRBut.addActionListener(new LoadTRButAC());
   
   loadPanel.add(loadWPBut);
   loadPanel.add(loadTRBut);
   loadPanel.add(loadRTBut);

   loadPanel.add(addWPBut);
   loadPanel.add(addPWPBut);
   loadPanel.add(gotoWPBut);
   loadPanel.add(addRTBut);
   loadPanel.add(addWPRTBut);

   inputPanel.add(loadFileArea);
   inputPanel.add(posPanelLat);
   inputPanel.add(posPanelLong);
   WActionPanel.add("South",inputPanel);
   WActionPanel.add("North",NMEALabel);
   //WActionPanel.add("Center",loadPanel);
   IGMPanel.add("West", vert);
   IGMPanel.add("South", horz);
   IGMPanel.add("Center",IGMCanvas);
   //   IGMPanel.add("Center",IGMCanvas);
   add("North", loadPanel);
   add("Center", IGMPanel);

   add("South",bottomPanel);   

   WPLPanel.add("South",WActionPanel);


//   wpPanel.add(loadPanel);

   WayPointLPanel.add("Center",waypointList);
   WayPointLPanel.add("North", WPLLabel);

   RouteLPanel.add("Center",routeList);
   RouteLPanel.add("West",RouteLLabel);

   RouteWPLPanel.add("Center",routeWPList);
   RouteWPLPanel.add("North",RouteWPLLabel);

   wpPanel.add(WPLPanel); 

//   wpPanel.add("North",WPLLabel);
   wpPanel.add(waypointList);
   wpPanel.add(RouteLPanel); 
   wpPanel.add(RouteWPLPanel); 
   wpPanel.add( outArea); 

  add("East", wpPanel); 

  // validate();
   pack();
  }

  public Dimension getMinimumSize(){  
    return (mS);
  }


  public Dimension getPreferredSize(){  
    return (pS);
  }

  public Datum mapDatum(){
    return mMapDatum.theDatum;  
  }

  void saveOptions()
    {
      try {
	DataOutputStream dos;
	File oFile = new File(propURL.getFile());
	dos = new DataOutputStream(new FileOutputStream(oFile));
	//dos = new DataOutputStream(propURL.openStream());
	//dos = ep.getOutputStream();
	dos.writeBytes("#EPS options file\n");
	dos.writeBytes("eps.chartdir="+epsEnv.chartdir+"\n");
	dos.writeBytes("eps.wpts="+ epsEnv.wpfile +"\n");
	dos.writeBytes("eps.routes=" + epsEnv.rtfile + "\n");
	dos.writeBytes("eps.track=" + epsEnv.trfile + "\n");
	dos.writeBytes("eps.naturalHeight="+epsEnv.naturalDim.height +"\n");
	dos.writeBytes("eps.naturalWidth="+epsEnv.naturalDim.width+"\n");
	dos.writeBytes("eps.ChartHeight="+epsEnv.ch +"\n");
	dos.writeBytes("eps.ChartWidth="+epsEnv.cw+"\n");
	dos.writeBytes("eps.fileFormat="+Pone.ffString(fileFormat)+"\n");
	dos.writeBytes("eps.posFormat="+posFm+"\n");
	//dos.writeBytes("eps.UTCoff=" + epsEnv.UTC_off+"\n");
	dos.writeBytes("eps.ChartDatum="+epsEnv.chartDatum.theDatum.name+"\n");
	dos.writeBytes("eps.PositionDatum="+epsEnv.positionDatum.theDatum.name+"\n");
	dos.writeBytes("eps.initLongitude=" + epsEnv.initLong+"\n");
	dos.writeBytes("eps.initLatitude="+ epsEnv.initLat+"\n");
	//dos.writeBytes("eps.gpstranspgm="+ epsEnv.gtpgm+"\n");
	dos.writeBytes("eps.portName="+ Garmincomm.portName+"\n");
	//	dos.writeBytes("eps.epscomm="+ Garmincomm.epscomm+"\n");
      }
      catch (SecurityException me) {
	System.out.println(" Security problem " + me);
	  outArea.setText("Could not save options\n" + "You can edit the options in the file: "+propURL.getFile());
      }
      catch (IOException me) {
	System.out.println(" File IOException RT: " + me);
	  outArea.setText("Could not save options\n" + "You can edit the options in the file: "+propURL.getFile());
      }    

    }

  public int sign (int x){
    return (x>0?1:-1);
  }  

  Pos getPos() {
    Pos theP = new Pos((LongPosDegree.val() +LongPosMin.val()/60d)*EWArea.sign,
		       (LatPosDegree.val() +LatPosMin.val()/60d)*NSArea.sign,
		       mMapDatum.theDatum);
    return  theP.toDatum(mMapDatum.theDatum);
  }
  


  
  class GrmOutWPMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
	     outArea.setText("Uploading Waypoints\n");
	     if (GMThread != null) {
	       GMThread.stop();      
	     }      
	     GMThread = new Thread(new Sendgpsinfo(Gpsmessage.WAYPOINT), 
				   "Snd WP");
	     GMThread.setPriority(10);	     
	     GMThread.start();
    }
  }
  

  class GrmOutRouteMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
	     outArea.setText("Uploading Routes\n");
	     if (GMThread != null) {
	       GMThread.stop();      
	     }      
	     GMThread = new Thread(new Sendgpsinfo(Gpsmessage.ROUTE),
				   "Snd ROUTE");
	     GMThread.start();
    }
  }
  
  class GrmOutTrackMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
	     outArea.setText("Uploading Track log\n");
	     if (GMThread != null) {
	       GMThread.stop();      
	     }      
	     GMThread = new Thread(new Sendgpsinfo(Gpsmessage.TRACK),
				   "Snd Track");
	     GMThread.start();
    }
  }
  

  class TrDelMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      TrackC.deleteAll();
      IGMCanvas.FullPaint = true;
      IGMCanvas.repaint(200);
    }
  }
  

  class AllDelMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      aWP.theWP.deleteAll();
      RouteC.deleteAll();
      TrackC.deleteAll();
      waypointList.removeAll();
      routeWPList.removeAll();
      routeList.removeAll();
      epsEnv.rtfile = null;    
      epsEnv.trfile = null;    
      epsEnv.wpfile = null;    

      IGMCanvas.FullPaint= true;
      IGMCanvas.repaint(200);
    }
  }
    

  class WpDelMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      int activeWP = waypointList.getSelectedIndex();
      if (activeWP>=0) {
	Route wroute;
	wroute = RouteC.findWPinRoute(aWP.theWP.wayPoints[activeWP]);
	if (wroute!=null){
	  outArea.setText("Cannot delete waypoint in route "+ wroute.name+ "\n");
	} else {
	aWP.theWP.delete(activeWP);
	aWP.theWP.flushList(waypointList,false);
	IGMCanvas.FullPaint = true;
	IGMCanvas.repaint(500);
      }
      }      
      IGMCanvas.FullPaint = true;
      IGMCanvas.repaint(100);
     }
  }
  
    
  class RtwpDelMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      int activeRT = routeList.getSelectedIndex();
      if (activeRT>=0) {
	int activeWP = routeWPList.getSelectedIndex();
	if (activeWP>=0) {
	  RouteC.routes[activeRT].wpts.delete(activeWP);
	  RouteC.routes[activeRT].wpts.flushList(routeWPList,true);
	  IGMCanvas.FullPaint = true;
	  IGMCanvas.repaint(100);
	  }      
//	  RouteC.flushList(routeList);
      }      
    }
  }
      

  class RtDelMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      int activeRT = routeList.getSelectedIndex();
      if (activeRT>=0) {
	RouteC.delete(activeRT);
	if (routeWPList.getItemCount()>0){
	  // netscape problem
	  routeWPList.removeAll();
	  IGMCanvas.FullPaint = true;
	  IGMCanvas.repaint(100);
	}      
	RouteC.flushList(routeList);
      }
    }
  }
  
    
//   class SetUTCMIAC implements ActionListener {
//     public void actionPerformed(ActionEvent event) {
//       String lv = loadFileArea.getText().trim();
//       epsEnv.UTC_off = Integer.parseInt(lv);
//       SetUTCMI.setLabel("Offset to UTC: "+epsEnv.UTC_off);
//     }
//   }
  
  class SetNHMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      String lv = loadFileArea.getText().trim();
      epsEnv.naturalDim.height = Integer.parseInt(lv);      
      SetNHMI. setLabel("Natural Height: "+epsEnv.naturalDim.height);
    }
  }
  


  class SetNWMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      String lv = loadFileArea.getText().trim();
      epsEnv.naturalDim.width = Integer.parseInt(lv); 
      SetNWMI. setLabel("Natural Width: "+epsEnv.naturalDim.width);
    }
  }
  
  class SetCHMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      String lv = loadFileArea.getText().trim();
      epsEnv.ch = Integer.parseInt(lv); 
      SetCHMI. setLabel("Chart Height: "+epsEnv.ch);
    }
  }
  
  class SetCWMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      String lv = loadFileArea.getText().trim();
      epsEnv.cw = Integer.parseInt(lv); 
      SetCWMI. setLabel("Chart Width: "+epsEnv.cw);     
    }
  }
  


  class SetIPWMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      Pos tpos = getPos();      
      epsEnv.initLat = tpos.y.p;
      epsEnv.initLong= tpos.x.p;
      //epsEnv.initLat = epsEnv.initLat - epsEnv.initLat % (epsEnv.ch/60d);
      //epsEnv.initLong= epsEnv.initLong - epsEnv.initLong % (epsEnv.cw/60d);
      SetIPWMI. setLabel("Initial position: "+ 
			 (new Pos(epsEnv.initLong,
				  epsEnv.initLat,
				  mMapDatum.theDatum)).toString(posFm));      
    }
  }
  

  class SetPortNameAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      Garmincomm.portName = loadFileArea.getText().trim();
      Garmincomm.setup();
      SetPortName.setLabel("Port name: "+ Garmincomm.portName);
    }
  }
  

  class PrintMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
    try {
      PrivilegeManager.enablePrivilege("UniversalPrintJobAccess");	
    } catch (ForbiddenTargetException me) {
      CAux.perr("No FTE PM",3);
    } catch (NoClassDefFoundError me) {
      CAux.perr("No Print PM",3);
    }
    try {
      PrintJob pjob = toolK.getPrintJob(myself, "eps", null);
      if (pjob == null) {
	System.out.println("pjob=null");
      } else {
	Graphics pg = pjob.getGraphics();
	if (pg == null) {
	  System.out.println("printing, pg=" + pg);
	} else {
	  myself.printAll(pg);
	  pg.dispose(); 		// flush page
	}
	pjob.end();
      }
    } catch (Exception ex) {
      System.out.println("print error" + ex);
      ex.printStackTrace();
      }
    }
  }
  
  class PrintChartMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      try {
	PrintJob pjob = toolK.getPrintJob(myself, "eps", null);
	if (pjob == null) {
	  System.out.println("pjob=null");
	} else {
	  Graphics pg = pjob.getGraphics();
	  if (pg == null) {
	    System.out.println("printing, pg=" + pg);
	  } else {
	    IGMCanvas.printAll(pg);
	    pg.dispose(); 		// flush page
	  }
	  pjob.end();
	}
      } catch (Exception ex) {
	System.out.println("print error" + ex);
	ex.printStackTrace();
      }
    }
  }
  

  class WpMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      aWP.theWP.output(outArea,fileFormat,epsEnv.UTC_off,mPositionDatum.theDatum,
		       loadFileArea.getText().trim(),null);
    }
  }
  

  class RMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      RouteC.output(outArea,fileFormat,epsEnv.UTC_off,mPositionDatum.theDatum,
		    loadFileArea.getText().trim(),null);
    }
  }
  


  class TrMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      TrackC.output(outArea,fileFormat,epsEnv.UTC_off,mPositionDatum.theDatum,
		    loadFileArea.getText().trim(),null);
    }
  }
  
  class FfGPSTRANSMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      fileFormat=Pone.ffGPSTRANS;
    }
  }
  

  class FfGRMMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      fileFormat=Pone.ffGRM;
    }
  }
  
  class FfGLMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      fileFormat=Pone.ffGARLINK;
    }
  }


  class Pf1MIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      posFm=Pone.DDD;
    }
  }
  
  class Pf2MIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      posFm=Pone.MDD;
    }
  }
  

  class ExitMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
	hThread.stop();      
	if (GMThread != null) {
	  GMThread.stop();      
	}
	Garmincomm.serialClose();
      if (inAnApplet) {
	System.out.println("Exit EPS applet");
	dispose();
      } else {
	System.out.println("Exit EPS application ");
	System.exit(0);
      }
    }
  }
  

  class SaveOptionsMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      saveOptions();
    }
  }
  

  class gotoWPButAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
       int activeWP;
       WayPoint theWP=null;
       String wpName=loadFileArea.getText().trim().toUpperCase();
       activeWP = waypointList.getSelectedIndex();
       if (activeWP>=0) {
	// System.out.println("  goto active WP " + activeWP);
	 theWP = aWP.theWP.wayPoints[activeWP];	
	 // System.out.println("  active WP is "+ theWP.name);
       } else if (wpName != null && wpName.length()>0) {
	 theWP=aWP.theWP.findWP(wpName);
       }
       
       if (theWP != null) {
	 IGMCanvas.ggoto(theWP.wpos);
	 IGMCanvas.FullPaint = true;
	 IGMCanvas.musync.upd(50);
       }
       IGMCanvas.FullPaint = true;
       IGMCanvas.repaint(100);

    }
  }
  
    

  class GrmInRouteMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
	int activeRT = routeList.getSelectedIndex();

	if (GMThread != null) {
	  GMThread.stop();      
	}      
	GMThread = new Thread(new Getgpsinfo(Gpsmessage.ROUTE, 
					     waypointList, 
					     routeList,null,IGMCanvas),
			      "Gm ROUTE in");
	GMThread.start();
	//	Getgpsinfo.getGPSInfo(Gpsmessage.ROUTE);
	if (activeRT>=0) {
	  routeWPList.removeAll();	  
	}	
	IGMCanvas.FullPaint = true;
	IGMCanvas.repaint(100);
    }
  }
  

  class GrmInTrackMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
	if (GMThread != null) {
	  GMThread.stop();      
	}      
	GMThread = new Thread(new Getgpsinfo(Gpsmessage.TRACK, 
					     null,null,null,IGMCanvas),
			      "Gm Track in");
	GMThread.start();
	IGMCanvas.FullPaint = true;
	IGMCanvas.repaint(100);
      }
  }


  class addWPRTButAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      WayPoint theWP=null;
      int activeWP;
      String wpName;
      wpName = loadFileArea.getText().trim().toUpperCase();
      activeRoute = routeList.getSelectedIndex();
      RouteWPLLabel.setText("WP's in Route "+ RouteC.routes[activeRoute].name+":");
      if (activeRoute >= 0) {
	// System.out.println(" AWR active Route "+activeRoute);
	activeWP = waypointList.getSelectedIndex();
	if (activeWP>=0) {
	  // System.out.println("  active WP " + activeWP);
	  theWP = aWP.theWP.wayPoints[activeWP];	
	  // System.out.println("  active WP is "+ theWP.name);
	} else if (wpName != null && wpName.length()>0) {
	  if (!((theWP=aWP.theWP.findWP(wpName))!=null)) {
	    if (IGMCanvas.cCursor != null){
	      theWP = new WayPoint(wpName,IGMCanvas.cCursor);
	      aWP.theWP.insertWP(outArea,waypointList,theWP,false);
	    }	    	   
	  }
	}

	if (theWP != null){
	  RouteC.routes[activeRoute].wpts.insertWP(outArea,routeWPList,theWP,true);
	  IGMCanvas.AnnoPaint = true;
	  IGMCanvas.musync.upd(500);
	}	
      }
    }
  }
  


  class LoadWPButAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      //System.out.println("  read "+ loadFileArea.getText());
      aWP.theWP.readWayPoints(outArea,waypointList,epsEnv.epsBase, 
			      loadFileArea.getText().trim(),
			      fileFormat, epsEnv);
       IGMCanvas.FullPaint = true;
       IGMCanvas.musync.upd(500);
    }
  }
  

  class LoadTRButAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      TrackC.readTracks(epsEnv.epsBase, loadFileArea.getText(),fileFormat,epsEnv);
      IGMCanvas.FullPaint = true;
      IGMCanvas.repaint(100);
    }
  }
  


  class LoadRTButAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      RouteC.readRoutes(outArea,routeList,routeWPList, waypointList, epsEnv.epsBase, 
			loadFileArea.getText().trim(),fileFormat,epsEnv);
      IGMCanvas.FullPaint = true;
      IGMCanvas.repaint(100);
    }
  }
  

  class StopMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      if (GMThread != null) {
	GMThread.stop();      
	GMThread = null;      
      }      
      Garmincomm.serialClose();	
    }
  }
  
  class NMEAMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      if (GMThread != null) {
	GMThread.stop();      
	GMThread = null;      
      }      
      GMThread = new Thread(new NMEA(IGMCanvas,NMEALabel),"NMEA thread");
      GMThread.start();
    }
  }
  
    

  class GrmInWPMIAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
	if (GMThread != null) {
	  GMThread.stop();      
	  GMThread = null;      
	}      
	GMThread = new Thread(new Getgpsinfo(Gpsmessage.WAYPOINT,
					     waypointList,null,null,
					     IGMCanvas), 
			      "Gm WP in");
	GMThread.start();
      }
  }
    

  class addWPButAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      if (IGMCanvas.cCursor != null){
	aWP.theWP.insertWP(outArea,waypointList, 
		   new WayPoint(loadFileArea.getText().trim().toUpperCase(), 
				IGMCanvas.cCursor),false);
	IGMCanvas.AnnoPaint = true;
	IGMCanvas.repaint(50);

      }    
    }
  }
  
  class addPWPButAC implements ActionListener {
    public void actionPerformed(ActionEvent event) {
      Pos np;
      np = getPos();
      
      aWP.theWP.insertWP(outArea,waypointList, 
		 new WayPoint(loadFileArea.getText().trim().toUpperCase(), 
			      np),false);
      IGMCanvas.AnnoPaint = true;
      IGMCanvas.repaint(50);
    }
  }
  

  class RTListAdapter implements ItemListener {
    public void itemStateChanged(ItemEvent event) {
      Route cr;
      
      activeRoute = routeList.getSelectedIndex();
      if (activeRoute>=0){
	cr = RouteC.routes[activeRoute];
	// System.out.println(" new  Route "+ cr.name);
	cr.wpts.flushList(routeWPList,true);
	RouteWPLLabel.setText("WP's in Route "+ cr.name+":");
      }          
    }
  }
  
  class WPListAdapter implements ItemListener {
    public void itemStateChanged(ItemEvent event) {
      //Object target = event.getItem();
      int activeWP;
      Pos wpos;      

      if (event.getStateChange() == ItemEvent.SELECTED) {
	WayPoint theWP=null;
	activeWP = waypointList.getSelectedIndex();
	theWP = aWP.theWP.wayPoints[activeWP];	
	wpos = theWP.wpos.toDatum(mPositionDatum.theDatum);
	
	LatPosDegree.setText(""+(int)(Math.abs(wpos.y.p)));
	LongPosDegree.setText(""+(int)(Math.abs(wpos.x.p)));

	LatPosMin.setText(wpos.y.toStringMin());
	LongPosMin.setText(wpos.x.toStringMin());
	
	NSArea.setText(wpos.y.p>0?"N":"S");
	EWArea.setText(wpos.x.p>0?"E":"W");
      } else if (event.getStateChange() == ItemEvent.DESELECTED) {
       WayPoint theWP=null;
       activeWP = waypointList.getSelectedIndex();
       
       LatPosDegree.setText("0");
       LongPosDegree.setText("0");

       LatPosMin.setText("0");
       LongPosMin.setText("0");
       if (activeWP>=0){
	 waypointList.deselect(activeWP);
       }
      }    
    }
  }
  

  class ZoomAdapter implements AdjustmentListener {
    
    public void adjustmentValueChanged(AdjustmentEvent event) {
      zzoom = (float) zoomSlider.getValue()/zoom;
      zoom = zoomSlider.getValue();
      horz.setValue(500);	  
      vert.setValue(500);	  
      zoomLabel.setText("zoom: "+zoom+"%");
      
      // System.out.println(" zoom:" + zoom +" ty=" + IGMCanvas.ty0 + " tx0="+IGMCanvas.tx0);
      
      IGMCanvas.ttx = IGMCanvas.tx0 = (int)
	(zzoom* IGMCanvas.ttx +
	 (zzoom-1f)*IGMCanvas.ScreenWidth/2f);
      
      IGMCanvas.tty = IGMCanvas.ty0 = (int)
	(zzoom * (IGMCanvas.tty) +
	 (zzoom-1f)*IGMCanvas.ScreenHeight/2f);
	
      IGMCanvas.FullPaint = true;
      IGMCanvas.musync.upd(500);
    }
  }
  
  class PanAdapter implements AdjustmentListener {
      boolean isVert;
      PanAdapter(boolean isv) {
	isVert=isv;
      }

    public void adjustmentValueChanged(AdjustmentEvent event) {
      int atp = event.getAdjustmentType();
      CAux.perr(" pandap vt "+ event + " atp="+atp,12);
      switch (atp) {
      case AdjustmentEvent.ADJUSTMENT_VALUE_CHANGED :
      case AdjustmentEvent.TRACK :
      case AdjustmentEvent.UNIT_DECREMENT:
      case AdjustmentEvent.UNIT_INCREMENT:
      case AdjustmentEvent.BLOCK_DECREMENT:
      case AdjustmentEvent.BLOCK_INCREMENT:
	if (isVert) {	  
	  int nv = vert.getValue();	  
	  if (nv<=25 && atp==AdjustmentEvent.UNIT_DECREMENT) {	      
	    vert.setValue(500);	  
	    IGMCanvas.ty0 += 500;
	  }else if (nv>=999 && atp ==AdjustmentEvent.UNIT_INCREMENT) {
	    vert.setValue(500);	  
	    IGMCanvas.ty0 -= 500;
	  }
	  nv = vert.getValue();	  
	  if (nv==0) {
	    vert.setValue(1);
	    nv=1;
	  } else if (nv>=1000) {
	    vert.setValue(999);
	  }	  
	  
	  IGMCanvas.tty = IGMCanvas.ty0 +(500 - nv);	  
	  IGMCanvas.FullPaint = true;
	  IGMCanvas.musync.upd(300);
	  
	  //	  IGMCanvas.repaint(1000);
	} else /*HORZ */ {
	  int nv = horz.getValue();	  
	  if (nv>=999 && atp == AdjustmentEvent.UNIT_INCREMENT) {
	    horz.setValue(500);	  
	    IGMCanvas.tx0 += 500;
	  }else if (nv<=1 && atp==AdjustmentEvent.UNIT_DECREMENT) {
	    horz.setValue(500);	  
	    IGMCanvas.tx0 -= 500;
	  }
	  nv = horz.getValue();	  
	  if (nv==0) {
	    horz.setValue(1);
	    nv=1;
	  } else if (nv>=1000) {
	    horz.setValue(999);
	  }
	  
	  // System.out.println(" horz = "+nv);
	  IGMCanvas.ttx = IGMCanvas.tx0 + nv - 500;	  
	  
	  IGMCanvas.FullPaint = true;
	  IGMCanvas.musync.upd(300);
	}
      default:{	
	}
      }
    }
  }
  

 }

 class NSEW extends TextField implements KeyListener, MouseListener {
   double sign = 1d;
   String pc,other;

  NSEW(char lb){
    super(" ",1);
    pc = ""+lb;
    if (lb=='S' || lb=='W'){
      sign = -1d;      
    }
    if (lb=='N'){
      other = "S";
    } else if (lb=='S'){
      other = "N";
    } else if (lb=='E'){
      other = "W";
    } else if (lb=='W'){
      other = "E";
    }
    setText(pc);
    addKeyListener(this);
    addMouseListener(this);
  }
  
  public synchronized void toggle(){
    String tc=pc;
    pc = other;
    other =tc;
    sign = -sign;  
    setText(pc);
  }

  public void keyTyped(KeyEvent e) {
  }

  public void keyPressed(KeyEvent evt) {
    toggle();
    evt.consume();    
  }
  public void keyReleased(KeyEvent e) {
  }

  public void mousePressed (MouseEvent evt) {
       toggle();
  }
  public void mouseEntered (MouseEvent evt) {
    //System.out.println("IG event "+ event);
      requestFocus();
  }

  public void mouseExited (MouseEvent evt) {}
  
  public void mouseReleased (MouseEvent evt) {}

  public void mouseClicked (MouseEvent evt) {}

}

class PosField extends TextField implements KeyListener{
  boolean dok;
  double vmax;
  String ov;

  PosField(boolean isMin, int wd, double vm){
    super("00.00000".substring(0,wd),wd);
    dok = isMin;
    vmax = vm;
    addKeyListener(this);    
  }

// public Dimension minimumSize(){  
//   FontMetrics fm;
//   fm = getFontMetrics(ChartFrame1.fh12);
//   return (new Dimension(fm.stringWidth("88.888"),fm.getHeight()));
//   }

  public double val(){
    String gt = getText().trim();
    if (gt == null || gt.length()==0){
      return(0d);
    }

    return(new Double(gt)).doubleValue();
  }
  
  public void keyTyped(KeyEvent event) {
  }

  public void keyPressed(KeyEvent event) {
    //CAux.perr("Kevent +"+event,7);
       if (
	   event.getKeyCode() == KeyEvent.VK_RIGHT 
	   || event.getKeyCode() == KeyEvent.VK_LEFT 
	   || event.getKeyCode() == KeyEvent.VK_TAB 
	   || event.getKeyCode() == KeyEvent.VK_DELETE
	   || event.getKeyCode() == KeyEvent.VK_BACK_SPACE
	   ){
	 ov = getText();
	 return;	 
       }       
       if (dok && event.getKeyChar() == '.'){
	 if (getText().indexOf('.')>=0) {
	   event.consume();
	 }	 
	 return;
       }
       
       if (Character.isDigit((char)event.getKeyChar())) {
	 ov = getText();
       } else {	 
	 event.consume();
       }
       
  }

  public void keyReleased(KeyEvent e) {
    if (val()>vmax){
      setText(ov);
    } else if (getText().trim().length()==0) {
      ov = "0";	   
      setText(ov);
    }	 
  }
}      

