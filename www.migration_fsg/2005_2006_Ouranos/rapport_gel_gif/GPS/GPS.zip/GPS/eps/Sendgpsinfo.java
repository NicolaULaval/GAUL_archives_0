
// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>

// Garmin communication code is based on Gpstrans by Carsten Tschach 
// (tschach@zedat.fu-berlin.de)

import  java.util.Date;
import netscape.security.PrivilegeManager;
import netscape.security.ForbiddenTargetException;
//Ported to java by Niels Elgaard Larsen                                                                          

class Sendgpsinfo implements Runnable{  
  
  int ptype;
  static byte  newTrack;
  static byte  message[] = new byte[100];
  Prefs gFilePrefs;
  
  Sendgpsinfo(int pt){
    ptype =pt;    
  }
  
  /****************************************************************************/
  /* Send "commit-suicide-command" to GPS.                                    */
  /****************************************************************************/
  static void sendGPSOff()
  {
    int         err;
    
    /* First check it GPS responds to the "are-you-ready" package */
    if (!Garmincomm.CheckGPS()) {
      CAux.perr("GPS is not responding - make sure it is on and set  to GRMN/GRMN protocol.",4);
    }
 
    /* open serial device */
    if ((err = Garmincomm.serialOpen(Garmincomm.GRM_comm)) != 0) {
      CAux.perr( "The port initialization  has failed.",4);
      // Continue. Netscape/IE problem
    }
    /* send command - no respond is send from GPS */
    Garmincomm.sendGPSMessage(Gpsmessage.off1, 4);
    
    /* close serial device */
    Garmincomm.serialClose();
  }
 

  /****************************************************************************/
  /* Send multiple line packages to GPS (route, waypoint, track)              */
  /****************************************************************************/
  public void run() {    
    int  recs, processed = 0;
    int  err;
    int result    = 1;
    String   rType ="?";
    byte   term[]= null;
  
    try {
      PrivilegeManager.enablePrivilege("UniversalFileAccess"/*,"Serial Port"*/);
      PrivilegeManager.enablePrivilege("UniversalExecAccess" /*,"To set serial Port params" */);
    } catch (ForbiddenTargetException me) {
      CAux.perr("No Snd PM",3);
    } catch (NoClassDefFoundError me) {
      CAux.perr("No S PM",3);
    }
    /* First check it GPS responds to the "are-you-ready" package */
    if (!Garmincomm.CheckGPS()) {
      CAux.perr("GPS is not responding - make sure it is on and set  to GRMN/GRMN protocol.",4);
    }

    /* open serial device */
    if ((err = Garmincomm.serialOpen(Garmincomm.GRM_comm)) != 0) {
      CAux.perr("The port initialization of " + ptype +" has failed.",4); 
      // Continue. Netscape/IE problem
    }
  
    recs = records(ptype);
  
    /* Continue only if GPS responds to the send-request package */
    CAux.perr("sending "+ recs + " records",1);
    if (sendRecords(recs) > 0) { 
      /* process different requests */
      if (ptype== Gpsmessage.ALMANAC) {
      } else if (ptype== Gpsmessage.ROUTE){
	WayPoint wp;
	int nw;	
	Route rt;
	int nr;	
	rType = "routes";
	term = Gpsmessage.rtet;
	CAux.perr("Route",1);
	
	for (nr=0 ; nr<RouteC.nRT ; nr++){
	  rt = RouteC.routes[nr];
	  result = doRoute(rt,  nr);
	  
	  for (nw=0; nw < rt.wpts.nWP; nw++){
	    wp=rt.wpts.wayPoints[nw];
	    result = doWaypoint(Gpsmessage.ROUTE, wp);
	  }
	}
      } else if (ptype == Gpsmessage.TRACK){
	int nt;
	
	rType = "track";
	term = Gpsmessage.trkt;
	newTrack = (byte) 1;
	
	for (nt=0; nt < TrackC.nTR; nt++) {
	  if (TrackC.track[nt]==null || TrackC.track[nt].tpos==null) {
	    newTrack = (byte) 1;	    
	  } else {	  
	    CAux.perr("TR "+nt,2);	    
	    result = doTrack(TrackC.track[nt]);
	  }	  
	}	
      } else if (ptype == Gpsmessage.WAYPOINT){
	int nw;
	rType = "waypoint";
	term = Gpsmessage.wptt;
	for (nw=0 ; nw<aWP.theWP.nWP ; nw++){
	  result = doWaypoint(Gpsmessage.WAYPOINT,aWP.theWP.wayPoints[nw]);
  	}
      }
      
      /* send terminator message to tell GPS - its over */
      if (result != 0) {
	CAux.perr("Final send F GPSM " + result,3);
	Garmincomm.sendGPSMessage(term, 4);
	
	if (Gpsmessage.isDEBUG()){
	  CAux.perr("Final responce",1);
	} 
        /* get final response but ignore it */	 
	Garmincomm.getGPSMessage();

        /* print number of packages transfered */
	CAux.perr(recs+" "+rType +
		  " packets were transfered to the GPS receiver",2);
      }
  }
  
    /* close serial device */
    Garmincomm.serialClose();
  }



  /****************************************************************************/
  /* Process Waypoint package - return 0 if GPS not respond.                  */
  /****************************************************************************/
  static int doWaypoint( int ptype, WayPoint wp) {
    double  latitude, longitude, x, y;
    long  lat, lon ,dat;    
    short   zone;
    String    bgzone; //5
    Date dt;
    int ii;
    String  nsZone; //20
    Pos trans = wp.wpos.toDatum(Pos.WGS84);
    CAux.perr("doWaypoint: " + wp,2);
  
    dt = wp.timestamp;
  
    /* handle various grids */  
    latitude = trans.y.p;
    longitude = trans.x.p;;
  
    /* convert numbers to GPS bytes */ 
    lat = Gpsmessage.deg2int(latitude);
    lon = Gpsmessage.deg2int(longitude);
    dat = CAux.dt2usecs(dt,0)/1000L;
  
    /* create package header */ 
    if (ptype == Gpsmessage.WAYPOINT){
      message[0] = Gpsmessage.WPT;
    }  else {        /* ptype == ROUTE */
      message[0] = Gpsmessage.RTE_WPT;
    }  

    /* number of message bytes to follow */
    message[1] = (byte)58;
    
    /* copy position and time to GPS package */ 
    cpystr(message, wp.name, 2,6);
    copyNumber(message,8, lat);
    copyNumber(message,12, lon);
    copyNumber(message,16, dat);
    //fileData[strlen(fileData)-1] = 0;		/* replace newline with null */
    cpystr(message, wp.comment, 20,40);

    //System.out.println(" lng = " + longitude + " t=" + lon + "  c2=" + 
    //		    message[12]+" " +message[13]+" " + message[14]+" "+message[15]);
  
    /* send package to GPS */ 
    Garmincomm.sendAndGetMessage(message, 60);
    return 1;
  }


  /****************************************************************************/
  /* Process Track package - return 0 if GPS not respond.                     */
  /****************************************************************************/
  static int doTrack(TRPos tr)
  {
    double  latitude, longitude, x, y;
    long    lat, lon, dat;
    short   zone;
    Date dt;
    char     nsZone; 
    Pos trans = tr.tpos.toDatum(Pos.WGS84);
  
    dt = tr.tm;
  
    /* handle various grids */ 
    latitude = trans.y.p;
    longitude = trans.x.p;;
    
    /* convert numbers to GPS bytes */ 
    lat = Gpsmessage.deg2int(latitude);
    lon = Gpsmessage.deg2int(longitude);
    dat = (CAux.dt2usecs(dt, 0)/1000L);
    CAux.perr("dat="+dat ,3);    
    /* create package header */ 
    message[0] = (byte) 0x22;
    
    /* number of message bytes to follow */
    message[1] = (byte)13;
    
    /* copy position and time to GPS package */ 
    copyNumber(message,2, (int)lat);
    copyNumber(message,6, (int)lon);
    copyNumber(message,10, dat);

    /* set "new track flag" */
    message[14] = newTrack;
    newTrack    = (byte) 0;

    /* send package to GPS */ 
    Garmincomm.sendGPSMessage(message, 15);
    
    /* make sure GPS respond */
    return Garmincomm.getGPSMessage();
  }


/****************************************************************************/
/* Process Route package - return 0 if GPS not respond.                     */
/****************************************************************************/
static int doRoute(Route rt, int route)
{
  if (Gpsmessage.DEBUG){
    CAux.perr("do Route " + route, 2);
  }
 
  /* create package header */ 
  message[0] = (byte)0x1d;

  /* number of message bytes to follow */
  message[1] = (byte)21;

  /* copy route data to GPS package */
  message[2] =(byte) route;
  //printf("rt=%d\n",route);
  cpystr(message, rt.name, 3,20);

    //  printf("send to unit\n");
  /* send package to GPS */ 
  Garmincomm.sendGPSMessage(message, 23);
  
  if (Gpsmessage.DEBUG) {
    //printf("sgp\n");
  }
  
  /* make sure GPS respond */
  return Garmincomm.getGPSMessage();
}


/****************************************************************************/
/* Process Almanac package - uploading almanac data is no longer supported. */
/****************************************************************************/

static int doAlmanac()
{
  return (0);
}


/****************************************************************************/
/* Return number of records in input-file.                                  */
/****************************************************************************/
static int records(int ptype)
{
  
  /* process different types */
  if (ptype ==Gpsmessage.ALMANAC) {
    CAux.perr("Amanac not yet implemnted",9);
  } else if (ptype ==Gpsmessage.ROUTE) {
    int nr,nrec=RouteC.nRT;
    for (nr=0 ; nr<RouteC.nRT ; nr++){
      nrec += RouteC.routes[nr].wpts.nWP;
    }
    return(nrec);      
  } else if (ptype ==Gpsmessage.TRACK) {
    int nt,nrec=0;
    for (nt=0; nt < TrackC.nTR; nt++){
      if (TrackC.track[nt]!=null) {
	nrec++;
      }
    }
    return(nrec);    
  } else if (ptype ==Gpsmessage.WAYPOINT) {
    return(aWP.theWP.nWP);
  }
  /* return number of records */
  return (-1);
}


/****************************************************************************/
/* Send a message containing the number of records to follow. Returns a     */
/* result code - zero if GPS did not respond.                               */
/****************************************************************************/
static int sendRecords(int recs)
{
  int  result;

  /* create package header */ 
  message[0] = Gpsmessage.NUMREC;

  /* number of message bytes to follow */
  message[1] = 0x02;

  /* convert number of records to GPS bytes */
  message[2] = (byte)(recs % 256);              /* LSB of number of records */
  message[3] = (byte)(recs / 256);              /* MSB */

  /* send package to GPS */ 
  Garmincomm.sendGPSMessage(message, 4);

  /* make sure GPS respond */
  result = Garmincomm.getGPSMessage();
  return result;
}


/****************************************************************************/
/* Convert long number to bytes.                                            */
/****************************************************************************/
static void copyNumber(byte p[], int st, long n0)
{	
  long p0,p1,p2,p3,n;
  
  if (n0>=0) {
    n=n0;
  } else {
    n=0x1000000000L + n0;
  }


  p3 =   n/0x1000000L;
  p2 = (n-p3*0x1000000L)/0x10000L;
  p1 = (n - p3*0x1000000L - p2*0x10000L)/0x100L;
  p0 = n - p1*0x100L - p2*0x10000L -p3*0x1000000L;
  
  //System.out.println("p0= " + p0 + " p1=" + p1+ "  p2=" + p2 + "  p3=" + p3);

  p[st+3] = (byte)p3;
  p[st+2] = (byte)p2;
  p[st+1] = (byte)p1;
  p[st  ] = (byte)p0;
  
}


/****************************************************************************/
/* Copy a string to GPS bytes.                                              */
/****************************************************************************/
static void cpystr(byte p[], String q, int st, int n)
{
  int ix=0;
  
  while (ix<n && ix < q.length()) {
    p[st+ix] = (byte)q.charAt(ix);
    ix ++;    
}
  while (ix<n) {    
    p[st+ix] = ' ';
    ix++;  
  }  
}


/****************************************************************************/
/*                                                                          */
/*  The following function retrieves the file format info from the first    */
/*  line of the data file. This is highly dependent upon the following      */
/*  format for the first line in the file -- note that there are not        */
/*  embedded tabs. See the file "getGPSInfo.c" for further information.     */
/*                                                                          */
/*  Format: DDD  UTC Offset:  -6.00 hrs  Datum[061]: NAD27 CONUS            */
/*          |||              ||||||            |||                          */
/*  0         1         2         3         4         5         6           */
/*  0123456789012345678901234567890123456789012345678901234567890123456789  */
/*                                                                          */
/****************************************************************************/
}
