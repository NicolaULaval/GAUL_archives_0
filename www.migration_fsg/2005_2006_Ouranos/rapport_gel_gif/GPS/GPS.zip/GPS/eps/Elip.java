// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>

class Elip {
  double a,rf;

  Elip(double ta, double trf)   {
    a = ta;
    rf =trf;
  }
  

static Elip  Airy1830 = 		new Elip( 6377563.396,	299.3249646);
static Elip  Bessel1841 = 		new Elip( 6377397.155, 	299.1528128);
static Elip  Clarke1866 = 		new Elip( 6378206.4,	 	294.9786982);
static Elip  Clarke1880 = 		new Elip( 6378249.145,	293.465);
static Elip  Everest1830 = 		new Elip( 6378276.345,	300.8017);
static Elip  Fischer1960 = 		new Elip( 6378166.0,		298.3);
static Elip  Fischer1968 = 		new Elip( 6378150.0,		298.3);
static Elip  GRS1967 = 		new Elip( 6378160.0,		298.247167427);
static Elip  GRS1975 = 		new Elip( 6378140.0,		298.257);
static Elip  GRS1980 = 		new Elip( 6378137.0,		298.257222101);
static Elip  Hough1956 = 		new Elip( 6378270.0,   	297.0);
static Elip  International = 		new Elip( 6378388.0,		297.0);
static Elip  Krassovsky1940 = 	new Elip( 6378245.0,		298.3);
static Elip  SouthAmerican1969 =	new Elip( 6378160.0,   	298.25);
static Elip  WGS60 = 		new Elip( 6378165.0,		298.3);
static Elip  WGS66 = 		new Elip( 6378145.0,		298.25);
static Elip  WGS72 = 		new Elip( 6378135.0,		298.26);
static Elip  WGS84 = 		new Elip( 6378137.0,		298.257223563);
}
