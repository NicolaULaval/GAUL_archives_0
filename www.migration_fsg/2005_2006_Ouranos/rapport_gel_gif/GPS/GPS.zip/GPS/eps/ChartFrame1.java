// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>

import java.awt.*;
import java.lang.Math;
import java.io.*;
import java.net.*;
import java.util.Properties;
import  java.util.Date;
import java.util.Locale;
import java.awt.event.*;
import netscape.security.PrivilegeManager;
import netscape.security.ForbiddenTargetException;

class ChartFrame1 extends ICF {
  ImageGMap IGMCanvas;
  static Dimension mS = new Dimension(500,400);
  static Dimension pS = new Dimension(800,700);
  

  static Properties applicationProps = new Properties();
  static boolean isWin = true;
  GMenv epsEnv;  
  boolean inAnApplet = false;
  float zzoom = 1;  
  int activeRoute;
  Toolkit toolK = this.getToolkit();
  ChartFrame1 myself=this;
  
  boolean sjump=false;
  String loadFile="w2.swp";  
  TextField loadFileArea = new TextField("",15);
  TextField NameArea = new TextField("",6);
  String jvver;
  String jver;
  String jcver;
  boolean NMEAactive = false;
  Thread hThread;
  Thread GMThread;
  Label zoomLabel = new Label("  100% zoom", Label.RIGHT);
  Label NMEALabel = new Label("");
  List routeWPList = new List(10, false);
  Scrollbar zoomSlider;
  Button loadWPBut, loadTRBut, loadRTBut;
  Button addWPBut,addPWPBut, gotoWPBut, addRTBut, addWPRTBut;
  MenuItem exitMI =new MenuItem("Exit");
  MenuItem saveOptionsMI =new MenuItem("Save options");
  MenuItem grmInMI =new MenuItem("input WP + Route + track from GPS Unit");

  MenuItem grmInRouteMI =new MenuItem("  input Route from GPS Unit");
  MenuItem grmInWPMI =new MenuItem("  input WP from GPS Unit");
  MenuItem grmInTrackMI =new MenuItem("  input Track from GPS Unit");

  MenuItem grmOutMI =new MenuItem("output WP + Route + track to GPS Unit");
  MenuItem grmOutRouteMI =new MenuItem("  output Route to GPS Unit");
  MenuItem grmOutWPMI =new MenuItem("  output WP to GPS Unit");
  MenuItem grmOutTrackMI =new MenuItem("  output Track to GPS Unit");

  MenuItem NMEAMI =new MenuItem("Display NMEA output");
  MenuItem StopMI =new MenuItem("Stop Communication");
  
  MenuItem trDelMI =new MenuItem("Track");
  MenuItem allDelMI =new MenuItem("All (wp,track, and route)");
  MenuItem wpDelMI =new MenuItem("WayPoint");
  MenuItem rtDelMI =new MenuItem("Route");
  MenuItem rtwpDelMI =new MenuItem("WayPoint from Route");

  //MenuItem SetUTCMI;
  MenuItem SetNHMI;
  MenuItem SetNWMI;
  MenuItem SetCHMI;
  MenuItem SetCWMI;
  //MenuItem SetCDWMI;
  MenuItem SetIPWMI;
  MenuItem SetGTWMI;

  MenuItem printMI =new MenuItem("Print");
  MenuItem printChartMI =new MenuItem("Print Chart");
  MenuItem wpMI =new MenuItem("WayPoints");
  MenuItem pf1MI =new MenuItem("Positions as d.dddd");
  MenuItem pf2MI =new MenuItem("Positions as d\u00b0mm.mm\'");
  MenuItem ffGPSTRANSMI =new MenuItem("GPStrans file format");
  MenuItem ffGLMI =new MenuItem("GARLINK file format");
  MenuItem ffGRMMI =new MenuItem("GARMIN file format");
  MenuItem trMI = new MenuItem("Track");  
  MenuItem trcMI = new MenuItem("Track");
  MenuItem rMI = new MenuItem("Routes");
  MenuItem rcMI = new MenuItem("Routes");

  MenuItem SetPortName;

  Label WPLLabel = new Label("WayPoints");
  Panel WPLPanel = new Panel();
  Panel WActionPanel = new Panel();
  Label RouteLLabel = new Label("Routes");
  Panel RouteLPanel = new Panel();
  Panel WayPointLPanel = new Panel();
  Label RouteWPLLabel = new Label("WP's in Route");
  Panel RouteWPLPanel = new Panel();
  
  Panel addPanel = new Panel();
  Panel bottomPanel = new Panel();
  Panel IGMPanel = new Panel();
  Panel centerPanel = new Panel();
  Panel loadPanel = new Panel();
  Panel inputPanel = new Panel();
  Panel wpPanel = new Panel();

  Panel posPanelLat = new Panel();
  Panel posPanelLong = new Panel();
  NSEW NSArea = new NSEW('N');
  NSEW EWArea = new NSEW('E');
  PosField LatPosDegree;
  PosField LongPosDegree;
  PosField LatPosMin;  
  PosField LongPosMin;
  
  Label dgLabelLat = new Label("\u00b0", Label.LEFT);
  Label mnLabelLat = new Label("\'", Label.LEFT);
  Label dgLabelLong = new Label("\u00b0", Label.LEFT);
  Label mnLabelLong = new Label("\'", Label.LEFT);

  
//   Menu routeMenu = new Menu("Route");
  //   Menu wayPointMenu= new Menu("Route");
  MenuBar mb = new MenuBar();
  Menu mf = new Menu("File");
  Menu mo = new Menu("Save");
  Menu mclr = new Menu("Clear");
  Menu mPosFormat = new Menu("Pos. Formats");
  Menu mFileFormat = new Menu("File Formats");
  Menu mDelete = new Menu("Delete");
  Menu mSet = new Menu("Set");
   URL propURL;

  public ChartFrame1(URL ep) {
    propURL = ep;
    String cD="default", pD = "default";
    URL tbase = null;
    try {
      CAux.perr("EPS locale "+ Locale.getDefault().getCountry()+"-"+Locale.getDefault().getLanguage(),2);
      if (Locale.getDefault().getCountry()==null || Locale.getDefault().getLanguage()==null||
	   Locale.getDefault().getCountry().length()==0 || Locale.getDefault().getLanguage().length()==0) {
	Locale.setDefault(Locale.US);	
	CAux.perr("now locale "+ Locale.getDefault().getCountry()+"-"+Locale.getDefault().getLanguage(),2);
      }
      
    } catch (SecurityException ioe) {
      System.out.println("s ex " + ioe);
    }
    
    

    try{
      URL tURL;
      System.out.println("BASE is: " + ep);
      //  tURL =new URL(base,PropertyFileName);
      DataInputStream appStream = new DataInputStream(ep.openStream());
      applicationProps.load(appStream);
      appStream.close();
    }
    catch (FileNotFoundException fe) {
      System.out.println("Proporties file not found: " + fe);
      //System.exit(0);
    } catch (SecurityException ioe) {
      System.out.println("prp ld " + ioe);
    } catch (IOException ioe) {
      System.out.println("Proporties Not found " + ioe);
      //System.exit(0);
    }
      System.out.println("now t base: " + ep);

      try {
	String baseS = applicationProps.getProperty("eps.base");
	if (baseS != null){
	  tbase = new URL(baseS);
	}
	
	if (tbase == null) {
	  tbase = ep;
	}
      
	cD = applicationProps.getProperty("eps.ChartDatum","WGS84");
	pD = applicationProps.getProperty("eps.PositionDatum","WGS84");


	//System.out.println("pd: \"" + cD +"\""+",\"" +pD+"\"");
	//System.out.println("pdd: " + mMapDatum.theDatum.name +":" +mPositionDatum.theDatum.name);
	if (applicationProps==null) {
	  epsEnv = new GMenv();
	} else {	
	  epsEnv = new GMenv(applicationProps.getProperty("eps.wpts"),
			     applicationProps.getProperty("eps.routes",null),
			     applicationProps.getProperty("eps.track",null),
			     applicationProps.getProperty("eps.chartdir"), 
			     tbase,
			     new Dimension(
					 Integer.parseInt(applicationProps.getProperty("eps.naturalWidth")),
					 Integer.parseInt(applicationProps.getProperty("eps.naturalHeight"))
					 ),
			   Integer.parseInt(applicationProps.getProperty("eps.ChartWidth")), 
			   Integer.parseInt(applicationProps.getProperty("eps.ChartHeight")),
			   applicationProps.getProperty("eps.fileFormat",null),
			   applicationProps.getProperty("eps.posFormat",null),
			   applicationProps.getProperty("eps.gpstranspgm",null),
			   //Integer.parseInt(applicationProps.getProperty("eps.UTCoff","0")),
			   
			   mMapDatum,
			   mPositionDatum,
			   Double.valueOf(applicationProps.getProperty("eps.initLatitude","55")).doubleValue(),
			   Double.valueOf(applicationProps.getProperty("eps.initLongitude","12")).doubleValue()
			   );
	Garmincomm.portName = applicationProps.getProperty("eps.portName",null);
      }
      
      isWin = System.getProperty("os.name").toUpperCase().indexOf("WINDOWS") >=0;

      
      if (Garmincomm.portName == null){
        if (isWin) {
          Garmincomm.portName = "com1";          
        } else {
          Garmincomm.portName = "/dev/cua0";          
        }                
      }      
      SetPortName =new MenuItem("Port name: "+ Garmincomm.portName);
    }  
    catch (MalformedURLException fe) {
      System.out.println(" URL: " + fe);
    }    

    Garmincomm.setup();
    
    mMapDatum = new DatumMenu("Chart Datum");
    mPositionDatum = new DatumMenu("Position Datum");
    mMapDatum.setDatum(Pos.getNamedDatum(cD));
    mPositionDatum.setDatum(Pos.getNamedDatum(pD));
      
    epsEnv.chartDatum =mMapDatum;
    epsEnv.positionDatum =mPositionDatum;
    horz = new Scrollbar(Scrollbar.HORIZONTAL,500,25,0,1025);
    vert = new Scrollbar(Scrollbar.VERTICAL  ,500,25,0,1025);
    //horz.setUnitIncrement(25);
    //vert.setUnitIncrement(25);
   pLabel = new Label("Position                                                                   ", 
		      Label.LEFT);   
    

   //SetUTCMI =new MenuItem("Offset to UTC: "+epsEnv.UTC_off);
  SetNHMI =new MenuItem("Natural Height: "+epsEnv.naturalDim.height);
  SetNWMI =new MenuItem("Natural Width: "+epsEnv.naturalDim.width);
  SetCHMI =new MenuItem("Chart Height: "+epsEnv.ch);
  SetCWMI =new MenuItem("Chart Width: "+epsEnv.cw);
  //SetCDWMI =new MenuItem("Chart Datum: "+epsEnv.Chart_Datum);
  SetIPWMI =new MenuItem("Initial Position: "+ (new Pos(epsEnv.initLong,
				        epsEnv.initLat,
				        mMapDatum.theDatum)).toString(posFm));
  //SetGTWMI =new MenuItem("gpstrans pgm: "+ epsEnv.gtpgm);
  
  setFont(fh12);
  LatPosDegree = new PosField(false,3,90d);
  LongPosDegree = new PosField(false,3,180d);
  LatPosMin = new PosField(true,7,60d);
  LongPosMin = new PosField(true,7,60d);
  
  WPLPanel.setLayout(new BorderLayout());
  routeMenu = new Menu("Route");
  WActionPanel.setLayout(new BorderLayout());
  RouteWPLPanel.setLayout(new BorderLayout());
  RouteLPanel.setLayout(new BorderLayout());
  WayPointLPanel.setLayout(new BorderLayout());
  
  IGMPanel.setLayout(new BorderLayout());
  loadPanel.setLayout(new GridLayout(0,5));
  inputPanel.setLayout(new GridLayout(0,1));
  addPanel.setLayout(new FlowLayout());
  posPanelLat.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
  posPanelLong.setLayout(new FlowLayout(FlowLayout.LEFT,0,0));
  
  wpPanel.setLayout(new GridLayout(5,1));
  bottomPanel.setLayout(new BorderLayout());
  waypointList = new List(15, false);
  waypointList.setForeground(Color.red);
  
  routeList = new List(10, false);
  routeList.setForeground(Color.blue);
  routeList.setBackground(Color.white);
   
  routeWPList.setForeground(Color.blue);
  routeWPList.setBackground(Color.white);
  waypointList.setBackground(Color.white);
   
  fh20 = new Font("Helvetica", Font.PLAIN, 20); 
  fh14 = new Font("Helvetica", Font.PLAIN, 14); 
  fh14b = new Font("Helvetica", Font.BOLD, 14); 
  fh12 = new Font("Helvetica", Font.PLAIN, 12); 
  
  try {
    int joff;
    jver = System.getProperties().getProperty("java.version");
    jcver = System.getProperties().getProperty("java.class.version");
     
    
    System.out.println(" We are running java " + jver + " c "+jcver );
     jcver = System.getProperties().getProperty("java.class.version");
     System.out.println("    class " + jcver);
     jvver = System.getProperty("java.vendor");
     System.out.println("    vendor " + jvver);
     System.out.println("    os= " + System.getProperty("os.name") + ", " +
			System.getProperty("os.arch") +", " +
			System.getProperty("os.version") 	    							);
     //System.out.println("    prp " + System.getProperties());
  } catch (SecurityException ioe) {
    System.out.println("Could not read system properties " + ioe);
  }

  int posFm = 1;  
   if (epsEnv.fileFormat!= null){
     if (epsEnv.fileFormat.equals("gpstrans")){
       fileFormat=Pone.ffGPSTRANS;
     } else if (epsEnv.fileFormat.equals("garlink")){
       fileFormat=Pone.ffGARLINK;  
     } else if (epsEnv.fileFormat.equals("garmin")){
       fileFormat=Pone.ffGRM;
     }
   }
      
   setBackground(new Color(173, 223, 255));
   setForeground(Color.black);
   setLayout(new BorderLayout());
  //Set up the menu bar.
   posPanelLat.add(LatPosDegree);
   posPanelLat.add(dgLabelLat);
   posPanelLat.add(LatPosMin);
   posPanelLat.add(mnLabelLat);
   posPanelLat.add(NSArea);

   posPanelLong.add(LongPosDegree);
   posPanelLong.add(dgLabelLong);
   posPanelLong.add(LongPosMin);
   posPanelLong.add(mnLabelLong);
   posPanelLong.add(EWArea);

   mo.add(wpMI);
   mo.add(rMI);
   mo.add(trMI);
   mo.add(printChartMI);
   mo.add(printMI);

   //mSet.add(SetUTCMI);
   mSet.add(SetNHMI);
   mSet.add(SetNWMI);
   mSet.add(SetCHMI);
   mSet.add(SetCWMI);
   mSet.add(SetIPWMI);
   //mSet.add(SetGTWMI);
   mSet.add(SetPortName);
   //   mSet.add(SetEpscomm);
   
   mDelete.add(allDelMI);
   mDelete.add(wpDelMI);
   mDelete.add(rtDelMI);
   mDelete.add(rtwpDelMI);
   mDelete.add(trDelMI);

   //mFileFormat.add(ffGPSTRANSMI);
   mFileFormat.add(ffGRMMI);
   mFileFormat.add(ffGLMI);
   mPosFormat.add(pf1MI);
   mPosFormat.add(pf2MI);

   mf.add(exitMI);
   mf.add(StopMI);
   mf.add(saveOptionsMI);
   //mf.add(grmInMI); //Carefull here
   mf.add(grmInWPMI);
   mf.add(grmInRouteMI);
   mf.add(grmInTrackMI);
   // mf.add(grmOutMI); // do not do it
   mf.add(grmOutWPMI);
   mf.add(grmOutRouteMI);
   mf.add(grmOutTrackMI);
   mf.add(NMEAMI);
   mb.add(mf);
   mb.add(mo);
   mb.add(mPosFormat);
   mb.add(mFileFormat);
   mSet.add(mMapDatum);
   mSet.add(mPositionDatum);
   mb.add(mDelete);
   mb.add(mSet);
   setMenuBar(mb);
   outArea = new TextArea(
			  "Elgaard Positioning System (EPS)\n"+
			  "version "+CAux.epsversion+", Copyright (C) 1997, \n"+
			  "Niels Elgaard Larsen\n"+
			  "EPS comes with ABSOLUTELY NO WARRANTY.\n"+
			  "This is free software, and you are \nwelcome to redistribute it"+
			  "under certain conditions;\n"	  
			  ,10,5);
   outArea.setEditable(false);
   IGMCanvas = new ImageGMap(epsEnv, (ICF)this);
   mPositionDatum.IGMCanvas = IGMCanvas;
   mMapDatum.IGMCanvas = IGMCanvas;
   hThread = new Thread(IGMCanvas,"EPS thread");
   hThread.start();
//    System.out.println(" blp= " + IGMCanvas.bottomLeftPos.toString(Pone.MALL));
//    System.out.println(" ny pos"+ (new Pos(epsEnv.initLong,epsEnv.initLat)));
//    System.out.println(" env: " +epsEnv);
   //Add small things at the bottom of the window.
   
//   bottomPanel.add(chbx);
//   posFormat.addItem("Positions as d.dddd");
//   //  posFormat.addItem("Positions as d�mm.mm\'");
//   posFormat.addItem("Positions as dgmm.mm\'");
//   bottomPanel.add("West",posFormat);


   zoomSlider=new Scrollbar(Scrollbar.HORIZONTAL, 100, 5, 10, 1000);
   //zoomSlider.addAdjustmentListener(new ZoomAdapter());
   try {     
     zoomSlider.setSize(50,20);   
   } catch (NoSuchMethodError ex) {
     CAux.perr("Hmmm, you better upgrade your VM/browser",1);
   }		  
   
   bottomPanel.add("East",zoomLabel);
   bottomPanel.add("Center",zoomSlider);

   bottomPanel.add("North",pLabel);
   add("South", bottomPanel);
  
   loadWPBut = new Button("Load Waypoints");
   loadRTBut = new Button("Load Routes");
   addWPBut = new Button("Add cursor WP");
   addPWPBut = new Button("Add Pos. WP");
   gotoWPBut = new Button("Goto Waypoint");
   addRTBut = new Button("Add Route");
   addWPRTBut = new Button("Add WP to Route");
   loadTRBut = new Button("Load Track");
   
   loadPanel.add(loadWPBut);
   loadPanel.add(loadTRBut);
   loadPanel.add(loadRTBut);

   loadPanel.add(addWPBut);
   loadPanel.add(addPWPBut);
   loadPanel.add(gotoWPBut);
   loadPanel.add(addRTBut);
   loadPanel.add(addWPRTBut);

   inputPanel.add(loadFileArea);
   inputPanel.add(posPanelLat);
   inputPanel.add(posPanelLong);
   WActionPanel.add("South",inputPanel);
   WActionPanel.add("North",NMEALabel);
   //WActionPanel.add("Center",loadPanel);
   IGMPanel.add("West", vert);
   IGMPanel.add("South", horz);
   IGMPanel.add("Center",IGMCanvas);
   //   IGMPanel.add("Center",IGMCanvas);
   add("North", loadPanel);
   add("Center", IGMPanel);

   add("South",bottomPanel);   

   WPLPanel.add("South",WActionPanel);


//   wpPanel.add(loadPanel);

   WayPointLPanel.add("Center",waypointList);
   WayPointLPanel.add("North", WPLLabel);

   RouteLPanel.add("Center",routeList);
   RouteLPanel.add("West",RouteLLabel);

   RouteWPLPanel.add("Center",routeWPList);
   RouteWPLPanel.add("North",RouteWPLLabel);

   wpPanel.add(WPLPanel); 

//   wpPanel.add("North",WPLLabel);
   wpPanel.add(waypointList);
   wpPanel.add(RouteLPanel); 
   wpPanel.add(RouteWPLPanel); 
   wpPanel.add( outArea); 

  add("East", wpPanel); 

  // validate();
   pack();
  }

  public Dimension getMinimumSize(){  
    return (mS);
  }


  public Dimension getPreferredSize(){  
    return (pS);
  }

  // Java 1.0 begin
  public Dimension minimumSize(){  
    return (mS);
  }

  public Dimension preferredSize(){  
    return (pS);
  }
  // Java 1.0 end

  public Datum mapDatum(){
    return mMapDatum.theDatum;  
  }

  void saveOptions()
    {
      try {
	DataOutputStream dos;
	File oFile = new File(propURL.getFile());
	dos = new DataOutputStream(new FileOutputStream(oFile));
	//dos = new DataOutputStream(propURL.openStream());
	//dos = ep.getOutputStream();
	dos.writeBytes("#EPS options file\n");
	dos.writeBytes("eps.chartdir="+epsEnv.chartdir+"\n");
	dos.writeBytes("eps.wpts="+ epsEnv.wpfile +"\n");
	dos.writeBytes("eps.routes=" + epsEnv.rtfile + "\n");
	dos.writeBytes("eps.track=" + epsEnv.trfile + "\n");
	dos.writeBytes("eps.naturalHeight="+epsEnv.naturalDim.height +"\n");
	dos.writeBytes("eps.naturalWidth="+epsEnv.naturalDim.width+"\n");
	dos.writeBytes("eps.ChartHeight="+epsEnv.ch +"\n");
	dos.writeBytes("eps.ChartWidth="+epsEnv.cw+"\n");
	dos.writeBytes("eps.fileFormat="+Pone.ffString(fileFormat)+"\n");
	dos.writeBytes("eps.posFormat="+posFm+"\n");
	//dos.writeBytes("eps.UTCoff=" + epsEnv.UTC_off+"\n");
	dos.writeBytes("eps.ChartDatum="+epsEnv.chartDatum.theDatum.name+"\n");
	dos.writeBytes("eps.PositionDatum="+epsEnv.positionDatum.theDatum.name+"\n");
	dos.writeBytes("eps.initLongitude=" + epsEnv.initLong+"\n");
	dos.writeBytes("eps.initLatitude="+ epsEnv.initLat+"\n");
	//dos.writeBytes("eps.gpstranspgm="+ epsEnv.gtpgm+"\n");
	dos.writeBytes("eps.portName="+ Garmincomm.portName+"\n");
	//	dos.writeBytes("eps.epscomm="+ Garmincomm.epscomm+"\n");
      }
      catch (SecurityException me) {
	System.out.println(" Security problem " + me);
	  outArea.setText("Could not save options\n" + "You can edit the options in the file: "+propURL.getFile());
      }
      catch (IOException me) {
	System.out.println(" File IOException RT: " + me);
	  outArea.setText("Could not save options\n" + "You can edit the options in the file: "+propURL.getFile());
      }    

    }

  public int sign (int x){
    return (x>0?1:-1);
  }  

  Pos getPos() {
    Pos theP = new Pos((LongPosDegree.val() +LongPosMin.val()/60d)*EWArea.sign,
		       (LatPosDegree.val() +LatPosMin.val()/60d)*NSArea.sign,
		       mMapDatum.theDatum);
    return  theP.toDatum(mMapDatum.theDatum);
  }
  

public boolean action(Event event, Object arg) {
  //System.out.println("  action "+ event +":" + arg);
     if (event.target == addWPBut) {
      if (IGMCanvas.cCursor != null){
	aWP.theWP.insertWP(outArea,waypointList, 
		new WayPoint(loadFileArea.getText().trim().toUpperCase(), 
					IGMCanvas.cCursor),false);
	IGMCanvas.AnnoPaint = true;
	IGMCanvas.repaint(50);
      }  
     } else if (event.target == addPWPBut) {
       Pos np;
       np = getPos();
       
       aWP.theWP.insertWP(outArea,waypointList, 
		 new WayPoint(loadFileArea.getText().trim().toUpperCase(), 
			      np),false);
       IGMCanvas.AnnoPaint = true;
       IGMCanvas.repaint(50);

     } else if (event.target == gotoWPBut || event.target == waypointList) {
       int activeWP;
       WayPoint theWP=null;
       String wpName=loadFileArea.getText().trim().toUpperCase();
       activeWP = waypointList.getSelectedIndex();
       if (activeWP>=0) {
	// System.out.println("  goto active WP " + activeWP);
	 theWP = aWP.theWP.wayPoints[activeWP];	
       } else if (wpName != null && wpName.length()>0) {
	 theWP=aWP.theWP.findWP(wpName);
       }
       
       if (theWP != null) {
       CAux.perr("goto " + theWP,8);
	 IGMCanvas.ggoto(theWP.wpos);
       //IGMCanvas.moveTo(theWP.wpos,true);
	 IGMCanvas.FullPaint = true;
	 IGMCanvas.musync.upd(50);
       }
     } else if (event.target == addRTBut) {
       RouteC.insertRoute(outArea, routeList, 
			  new Route(loadFileArea.getText().trim().toUpperCase()));
    } else if (event.target == addWPRTBut) {
      WayPoint theWP=null;
      int activeWP;
      String wpName;
      wpName = loadFileArea.getText().trim().toUpperCase();
      activeRoute = routeList.getSelectedIndex();
      RouteWPLLabel.setText("WP's in Route "+ RouteC.routes[activeRoute].name+":");
      if (activeRoute >= 0) {
	// System.out.println(" AWR active Route "+activeRoute);
	activeWP = waypointList.getSelectedIndex();
	if (activeWP>=0) {
	  // System.out.println("  active WP " + activeWP);
	  theWP = aWP.theWP.wayPoints[activeWP];	
	  // System.out.println("  active WP is "+ theWP.name);
	} else if (wpName != null && wpName.length()>0) {
	  if (!((theWP=aWP.theWP.findWP(wpName))!=null)) {
	    if (IGMCanvas.cCursor != null){
	      theWP = new WayPoint(wpName,IGMCanvas.cCursor);
	      aWP.theWP.insertWP(outArea,waypointList,theWP,false);
	    }	    	   
	  }
	}

	if (theWP != null){
	  RouteC.routes[activeRoute].wpts.insertWP(outArea,routeWPList,theWP,true);
	  IGMCanvas.AnnoPaint = true;
	  IGMCanvas.musync.upd(500);
	}	
      }
    } else if (event.target == loadWPBut) {
      //System.out.println("  read "+ loadFileArea.getText());
      aWP.theWP.readWayPoints(outArea,waypointList,epsEnv.epsBase, 
			      loadFileArea.getText().trim(),
			      fileFormat, epsEnv);
       IGMCanvas.FullPaint = true;
       IGMCanvas.musync.upd(500);
    } else if (event.target == loadTRBut) {
      TrackC.readTracks(epsEnv.epsBase, loadFileArea.getText(),fileFormat,epsEnv);
      IGMCanvas.FullPaint = true;
      IGMCanvas.repaint(100);
    } else if (event.target == loadRTBut) {
      RouteC.readRoutes(outArea,routeList,routeWPList, waypointList, epsEnv.epsBase, 
			loadFileArea.getText().trim(),fileFormat,epsEnv);
      IGMCanvas.FullPaint = true;
      IGMCanvas.repaint(100);
    } else if (event.target == StopMI) {
      if (GMThread != null) {
	GMThread.stop();      
	GMThread = null;      
      }      
      Garmincomm.serialClose();	
    } else if (event.target == NMEAMI) {
      if (GMThread != null) {
	GMThread.stop();      
	GMThread = null;      
      }      
      GMThread = new Thread(new NMEA(IGMCanvas,NMEALabel),"NMEA thread");
      GMThread.start();
    } else if (event.target == grmInMI || 
	       event.target == grmInWPMI || 
	       event.target == grmInRouteMI || 
	       event.target == grmInTrackMI) {
      //aWP.theWP.theWP.readWayPoints(outArea,waypointList,null,epsEnv.gtpgm,Pone.ffGPSTRANS,epsEnv);
      //RouteC.readRoutes(outArea,routeList,waypointList,null,null,epsEnv.gtpgm,Pone.ffGPSTRANS,epsEnv);
      //TrackC.readTracks(null, epsEnv.gtpgm, Pone.ffGPSTRANS,epsEnv);
      if (event.target == grmInMI ||event.target == grmInWPMI){
	if (GMThread != null) {
	  GMThread.stop();      
	  GMThread = null;      
	}      
	GMThread = new Thread(new Getgpsinfo(Gpsmessage.WAYPOINT,
					     waypointList,
					     null,null,
					     IGMCanvas),
			      "Gm WP in");
	GMThread.start();
      }

      
      if (event.target == grmInMI ||event.target == grmInRouteMI){
	int activeRT = routeList.getSelectedIndex();

	if (GMThread != null) {
	  GMThread.stop();      
	}      
	GMThread = new Thread(new Getgpsinfo(Gpsmessage.ROUTE, 
					     waypointList, 
					     routeList,null,IGMCanvas),
			      "Gm ROUTE in");
	GMThread.start();
	//	Getgpsinfo.getGPSInfo(Gpsmessage.ROUTE);
	if (activeRT>=0) {
	  try {	    
	    routeWPList.removeAll();
	  }  catch (NoSuchMethodError ex) {
	    routeWPList.clear();
	}	  	  
	}	
      }
      
      if (event.target == grmInMI ||event.target == grmInTrackMI){
	if (GMThread != null) {
	  GMThread.stop();      
	}      
	GMThread = new Thread(new Getgpsinfo(Gpsmessage.TRACK, 
					     null,null,null,IGMCanvas),
			      "Gm Track in");
	GMThread.start();
      }
      IGMCanvas.FullPaint = true;
      IGMCanvas.repaint(100);
    }    
     else if (event.target == grmOutMI ||
	      event.target == grmOutWPMI || 
	      event.target == grmOutRouteMI || 
	      event.target == grmOutTrackMI) {
       
       //aWP.theWP.theWP.output(null,fileFormat,epsEnv.UTC_off,mPositionDatum.theDatum,null,epsEnv.gtpgm);
           if (event.target == grmOutMI ||event.target == grmOutWPMI) {
	     outArea.setText("Uploading Waypoints\n");
	     if (GMThread != null) {
	       GMThread.stop();      
	     }      
	     GMThread = new Thread(new Sendgpsinfo(Gpsmessage.WAYPOINT), 
				   "Snd WP");
	     GMThread.setPriority(Thread.MAX_PRIORITY);
	     GMThread.start();
	   }
	   
           if (event.target == grmOutMI ||event.target == grmOutRouteMI) {
	     outArea.setText("Uploading Routes\n");
	     if (GMThread != null) {
	       GMThread.stop();      
	     }      
	     GMThread = new Thread(new Sendgpsinfo(Gpsmessage.ROUTE),
				   "Snd ROUTE");
	     GMThread.start();
	   }
	   
	   //RouteC.output(null,fileFormat,epsEnv.UTC_off,mPositionDatum.theDatum,null,epsEnv.gtpgm);
           if (event.target == grmOutMI ||event.target == grmOutTrackMI) {
	     outArea.setText("Uploading Track log\n");
	     if (GMThread != null) {
	       GMThread.stop();      
	     }      
	     GMThread = new Thread(new Sendgpsinfo(Gpsmessage.TRACK),
				   "Snd Track");
	     GMThread.start();
	   }
     
       //TrackC.output(null,fileFormat,epsEnv.UTC_off,mPositionDatum.theDatum,null, epsEnv.gtpgm);
	   outArea.setText("done.\n");
     }    
    else if (event.target == routeList) {
      Route cr;
      
      activeRoute = routeList.getSelectedIndex();
      if (activeRoute>=0){
	cr = RouteC.routes[activeRoute];
	// System.out.println(" new  Route "+ cr.name);
	cr.wpts.flushList(routeWPList,true);
	RouteWPLLabel.setText("WP's in Route "+ cr.name+":");
      }
      
    } else if (event.target == trDelMI) {
      TrackC.deleteAll();
      IGMCanvas.FullPaint = true;
      IGMCanvas.repaint(200);
    } else if (event.target == allDelMI) {
      aWP.theWP.deleteAll();
      RouteC.deleteAll();
      TrackC.deleteAll();
      try {
	waypointList.removeAll();
	routeWPList.removeAll();
	routeList.removeAll();
      }  catch (NoSuchMethodError ex) {
	waypointList.clear();
	routeWPList.clear();
	routeList.clear();
      }	  	  

      epsEnv.rtfile = null;    
      epsEnv.trfile = null;    
      epsEnv.wpfile = null;    

      IGMCanvas.FullPaint= true;
      IGMCanvas.repaint(200);
    } else if (event.target == wpDelMI) {
      int activeWP = waypointList.getSelectedIndex();
      if (activeWP>=0) {
	Route wroute;
	wroute = RouteC.findWPinRoute(aWP.theWP.wayPoints[activeWP]);
	if (wroute!=null){
	  outArea.setText("Cannot delete waypoint in route "+ wroute.name+ "\n");
	} else {
	aWP.theWP.delete(activeWP);
	aWP.theWP.flushList(waypointList,false);
	IGMCanvas.FullPaint = true;
	IGMCanvas.repaint(500);
      }
      }      
      IGMCanvas.FullPaint = true;
      IGMCanvas.repaint(100);
    } else if (event.target == rtwpDelMI) {
      int activeRT = routeList.getSelectedIndex();
      if (activeRT>=0) {
	int activeWP = routeWPList.getSelectedIndex();
	if (activeWP>=0) {
	  RouteC.routes[activeRT].wpts.delete(activeWP);
	  RouteC.routes[activeRT].wpts.flushList(routeWPList,true);
	  IGMCanvas.FullPaint = true;
	  IGMCanvas.repaint(100);
	  }      
//	  RouteC.flushList(routeList);
	}      
    } else if (event.target == rtDelMI) {
      int activeRT = routeList.getSelectedIndex();
      if (activeRT>=0) {
	int numRouteList;
	try {	    
	  numRouteList = routeWPList.getItemCount();
	}  catch (NoSuchMethodError ex) {
	  numRouteList = routeWPList.countItems();
	}
	RouteC.delete(activeRT);
	if (numRouteList>0) {
	  // netscape problem
	  try {	    
	    routeWPList.removeAll();
	  }  catch (NoSuchMethodError ex) {
	    routeWPList.clear();
	}	  	  
	  IGMCanvas.FullPaint = true;
	  IGMCanvas.repaint(100);
	}      
	RouteC.flushList(routeList);
	}
//     } else if (event.target == SetUTCMI) {
//       String lv = loadFileArea.getText().trim();
//       epsEnv.UTC_off = Integer.parseInt(lv);
//       SetUTCMI.setLabel("Offset to UTC: "+epsEnv.UTC_off);
    } else if (event.target == SetNHMI) {
      String lv = loadFileArea.getText().trim();
      epsEnv.naturalDim.height = Integer.parseInt(lv);      
      SetNHMI. setLabel("Natural Height: "+epsEnv.naturalDim.height);
    } else if (event.target == SetNWMI) {
      String lv = loadFileArea.getText().trim();
      epsEnv.naturalDim.width = Integer.parseInt(lv); 
      SetNWMI. setLabel("Natural Width: "+epsEnv.naturalDim.width);
    } else if (event.target == SetCHMI) {
      String lv = loadFileArea.getText().trim();
      epsEnv.ch = Integer.parseInt(lv); 
      SetCHMI. setLabel("Chart Height: "+epsEnv.ch);
    } else if (event.target == SetCWMI) {
      String lv = loadFileArea.getText().trim();
      epsEnv.cw = Integer.parseInt(lv); 
      SetCWMI. setLabel("Chart Width: "+epsEnv.cw);     
    } else if (event.target == SetIPWMI) {
      Pos tpos = getPos();      
      epsEnv.initLat = tpos.y.p;
      epsEnv.initLong= tpos.x.p;
      //epsEnv.initLat = epsEnv.initLat - epsEnv.initLat % (epsEnv.ch/60d);
      //epsEnv.initLong= epsEnv.initLong - epsEnv.initLong % (epsEnv.cw/60d);
      SetIPWMI. setLabel("Initial position: "+ 
			 (new Pos(epsEnv.initLong,
				  epsEnv.initLat,
				  mMapDatum.theDatum)).toString(posFm));      
      //} else if (event.target == SetGTWMI) {
      //epsEnv.gtpgm = loadFileArea.getText().trim();
      //SetGTWMI. setLabel("Initial Position: "+  epsEnv.gtpgm);      
 
    } else if (event.target == SetPortName) {
      Garmincomm.portName = loadFileArea.getText().trim();
      SetPortName. setLabel("Port name: "+ Garmincomm.portName);
   } else if (event.target == printMI) {
      try {
	PrintJob pjob = this.getToolkit().getPrintJob(this, "eps", null);
	if (pjob == null) {
	  System.out.println("pjob=null");
	} else {
	  Graphics pg = pjob.getGraphics();
	  if (pg == null) {
	    System.out.println("printing, pg=" + pg);
	  } else {
	    this.printAll(pg);
	    pg.dispose(); 		// flush page
	  }
	  pjob.end();
	}
      } catch (Exception ex) {
	System.out.println("print error" + ex);
	ex.printStackTrace();
      }
    } else if (event.target == printChartMI) {
      try {
	PrintJob pjob = toolK.getPrintJob(myself, "eps", null);
	if (pjob == null) {
	  System.out.println("pjob=null");
	} else {
	  Graphics pg = pjob.getGraphics();
	  if (pg == null) {
	    System.out.println("printing, pg=" + pg);
	  } else {
	    IGMCanvas.printAll(pg);
	    pg.dispose(); 		// flush page
	  }
	  pjob.end();
	}
      } catch (Exception ex) {
	System.out.println("print error" + ex);
	ex.printStackTrace();
      }
    } else if (event.target == wpMI) {
      aWP.theWP.output(outArea,fileFormat,epsEnv.UTC_off,mPositionDatum.theDatum,
		       loadFileArea.getText().trim(),null);
    } else if (event.target == rMI) {
      RouteC.output(outArea,fileFormat,epsEnv.UTC_off,mPositionDatum.theDatum,
		    loadFileArea.getText().trim(),null);
    } else if (event.target == trMI) {
      TrackC.output(outArea,fileFormat,epsEnv.UTC_off,mPositionDatum.theDatum,
		    loadFileArea.getText().trim(),null);
    } else if (event.target == ffGPSTRANSMI) {
      fileFormat=Pone.ffGPSTRANS;
    } else if (event.target == ffGRMMI) {
      fileFormat=Pone.ffGRM;
    } else if (event.target == ffGLMI) {
      fileFormat=Pone.ffGARLINK;

    } else if (event.target == pf1MI) {
      posFm=Pone.DDD;
    } else if (event.target == pf2MI) {
      posFm=Pone.MDD;
    }else if (event.id == Event.WINDOW_DESTROY) {
	hThread.stop();      
	GMThread.stop();      
	Garmincomm.serialClose();
      if (inAnApplet) {
	System.out.println("Exit applet");
	dispose();
      } else {
	System.out.println("Exit application ");
	System.exit(0);
      }
    } else if (event.target == exitMI) {
	hThread.stop();      
	if (GMThread != null) {
	  GMThread.stop();      
	}
	Garmincomm.serialClose();
      if (inAnApplet) {
	System.out.println("Exit EPS applet");
	dispose();
      } else {
	System.out.println("Exit EPS application ");
	System.exit(0);
      }
    } else if (event.target == saveOptionsMI) {
      saveOptions();
    } else {
      return(false);
    }
     return(true);
   }

  
    

  
   public boolean handleEvent(Event event) {
     //System.out.println("event "+ event);
     if (event.target == zoomSlider) {
       zzoom = (float) zoomSlider.getValue()/zoom;
       zoom = zoomSlider.getValue();
       horz.setValue(500);	  
       vert.setValue(500);	  
       zoomLabel.setText("zoom: "+zoom+"%");
       //IGMCanvas.tx0 += IGMCanvas.ttx;
      //IGMCanvas.ty0 += IGMCanvas.tty;
       
       // System.out.println(" zoom:" + zoom +" ty=" + IGMCanvas.ty0 + " tx0="+IGMCanvas.tx0);

       IGMCanvas.ttx = IGMCanvas.tx0 = (int)
	 (zzoom* IGMCanvas.ttx +  (zzoom-1f)*(float)IGMCanvas.ScreenWidth/2f);
      
       IGMCanvas.tty = IGMCanvas.ty0 = (int)
	 (zzoom * (IGMCanvas.tty) + (zzoom-1f)*(float)IGMCanvas.ScreenHeight/2f);
       
       IGMCanvas.FullPaint = true;
       IGMCanvas.musync.upd(500);

     } else if (event.id == Event.LIST_SELECT && event.target == routeList) {
      Route cr;
      
      activeRoute = routeList.getSelectedIndex();
      if (activeRoute>=0){
	cr = RouteC.routes[activeRoute];
	// System.out.println(" new  Route "+ cr.name);
	cr.wpts.flushList(routeWPList,true);
	RouteWPLLabel.setText("WP's in Route "+ cr.name+":");
      }
      
    }else if (event.id == Event.LIST_SELECT && event.target == waypointList) {
       int activeWP;
       Pos wpos;      
       WayPoint theWP=null;
       activeWP = waypointList.getSelectedIndex();
       theWP = aWP.theWP.wayPoints[activeWP];	
       wpos = theWP.wpos.toDatum(mPositionDatum.theDatum);
       
       LatPosDegree.setText(""+(int)(Math.abs(wpos.y.p)));
       LongPosDegree.setText(""+(int)(Math.abs(wpos.x.p)));

       LatPosMin.setText(wpos.y.toStringMin());
       LongPosMin.setText(wpos.x.toStringMin());

       NSArea.setText(wpos.y.p>0?"N":"S");
       EWArea.setText(wpos.x.p>0?"E":"W");
       
    }else if ((event.target == waypointList) && (event.id == Event.LIST_DESELECT || event.id ==   Event.KEY_PRESS && event.key=='c')) {
       int activeWP;
       Pos wpos;      
       WayPoint theWP=null;
       activeWP = waypointList.getSelectedIndex();
       
       LatPosDegree.setText("0");
       LongPosDegree.setText("0");

       LatPosMin.setText("0");
       LongPosMin.setText("0");
       if (activeWP>=0){
	 waypointList.deselect(activeWP);
       }
     } else {	 
       switch (event.id) {
       case Event.SCROLL_LINE_UP:
       case Event.SCROLL_LINE_DOWN:
       case Event.SCROLL_PAGE_UP:
       case Event.SCROLL_PAGE_DOWN:
       case Event.SCROLL_ABSOLUTE:
	 if (event.target == vert) {
	   //System.out.println(" vt "+ event);
	   
	   int nv = vert.getValue();	  
	   if (nv<=1 && event.id==Event.SCROLL_LINE_UP) {	      
	     vert.setValue(500);	  
	     IGMCanvas.ty0 += 500;
	     IGMCanvas.mouseUp=false;
	   }else if (nv>=999 && event.id==Event.SCROLL_LINE_DOWN) {
	     vert.setValue(500);	  
	     IGMCanvas.ty0 -= 500;
	     IGMCanvas.mouseUp=false;
	   }
	   nv = vert.getValue();	  
	   if (nv==0) {
	     vert.setValue(1);
	     nv=1;
	   } else if (nv>=1000) {
	     vert.setValue(999);
	   }	  
	   
	   IGMCanvas.tty = IGMCanvas.ty0 +(500 - nv);	  
	   IGMCanvas.FullPaint = true;
	   IGMCanvas.musync.upd(300);
	   
	   //	  IGMCanvas.repaint(1000);
	 } else  if (event.target == horz) {
	   int nv = horz.getValue();	  
	   if (nv>=999 && event.id==Event.SCROLL_LINE_DOWN) {
	     horz.setValue(500);	  
	     IGMCanvas.tx0 += 500;
	     IGMCanvas.mouseUp=false;
	   }else if (nv<=1 && event.id==Event.SCROLL_LINE_UP) {
	     horz.setValue(500);	  
	     IGMCanvas.tx0 -= 500;
	   }
	   nv = horz.getValue();	  
	   if (nv==0) {
	     horz.setValue(1);
	     nv=1;
	   } else if (nv>=1000) {
	     horz.setValue(999);
	   }
	   
	   // System.out.println(" horz = "+nv);
	   IGMCanvas.ttx = IGMCanvas.tx0 + nv - 500;	  
	   
	   IGMCanvas.FullPaint = true;
	   IGMCanvas.musync.upd(300);
	 }
	 default:{	
	   //System.out.println(" passing event = "+event);
	   //return (false);	    
	    return(super.handleEvent(event));
	 }
       }
     }
     return(true);     
   }
 }

class NSEW extends TextField {
   double sign = 1d;
   String pc,other;

  NSEW(char lb){
    super(" ",1);
    pc = ""+lb;
    if (lb=='S' || lb=='W'){
      sign = -1d;      
    }
    if (lb=='N'){
      other = "S";
    } else if (lb=='S'){
      other = "N";
    } else if (lb=='E'){
      other = "W";
    } else if (lb=='W'){
      other = "E";
    }
    setText(pc);
  }
  
  public synchronized void toggle(){
    String tc=pc;
    pc = other;
    other =tc;
    sign = -sign;  
    setText(pc);
  }

   public boolean handleEvent(Event event) {
     if (event.id == Event.KEY_PRESS) {
       if (event.key == 9){
	 return false;
       }       
       //System.out.println(" now key "+event.key);
       toggle();
       return(true);
     } else if (event.id == Event.MOUSE_DOWN) {
       toggle();
       return(true);
     }
     
     return(false);
   }
  

  public boolean action(Event event, Object arg) {
    toggle();
    return(true);
  }            
}

class PosField extends TextField {
  boolean dok;
  double vmax;
  String ov;

  PosField(boolean isMin, int wd, double vm){
    super("00.00000".substring(0,wd),wd);
    dok = isMin;
    vmax = vm;
  }

// public Dimension minimumSize(){  
//   FontMetrics fm;
//   fm = getFontMetrics(ChartFrame1.fh12);
//   return (new Dimension(fm.stringWidth("88.888"),fm.getHeight()));
//   }

  public double val(){
    String gt = getText().trim();
    if (gt == null || gt.length()==0){
      return(0d);
    }

    return(new Double(gt)).doubleValue();
  }
  
   public boolean handleEvent(Event event) {
     if (event.id == Event.KEY_PRESS) {
       if (event.key == 9 ||
	   event.key == Event.RIGHT 
	   || event.key == Event.LEFT 
	   || event.key == 8 
	   || event.key == 127
	   ){
	 ov = getText();
	 boolean sv;
	 sv = super.handleEvent(event);
	 return (sv);
       }       
       //System.out.println(" now key "+event.key);
       if (dok && event.key == '.'){
	 return (getText().indexOf('.')>=0);
       }
       
       if (Character.isDigit((char)event.key)) {
	 //return false;
	 ov = getText();
	 return(false);
       }
       return(true);
     } else if (event.id == Event.KEY_RELEASE) {
       boolean sv;
       sv = super.handleEvent(event);
       if (val()>vmax){
	 setText(ov);
       } else 	 if (getText().trim().length()==0) {
	 ov = "0";	   
	 setText(ov);
       }	 
       return(sv);
     }     
     return(false);
   }
}      

