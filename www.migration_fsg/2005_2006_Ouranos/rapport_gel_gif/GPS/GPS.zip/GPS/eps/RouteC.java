// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>

import java.awt.*;
import java.io.*;
import java.net.*;
import java.lang.Runtime;
import  java.text.*;
import netscape.security.PrivilegeManager;
import netscape.security.ForbiddenTargetException;


class RouteC {
  static int nRT=0;
  static int maxRT=100;
  static Route routes[] = new Route[maxRT];


  static public void flushList(List rl){
    int nr;
    
    if (rl!=null){
      try {
	if (rl.getItemCount() >0){
	  // netscape problem
	  rl.removeAll();
	}     
      } catch (NoSuchMethodError ex) {
	if (rl.countItems() >0){
	  rl.clear();
	}
      }
      
      for (nr=0;nr<nRT;nr++){
	rl.addItem("" + 
		   //routes[nr].number + " "+ 
		   routes[nr].name);
      }
    }    
  }


  static Route findRT(String rname){
    int nrt=0;
    
    while (nrt < nRT) {
      if (routes[nrt].name.equals(rname)){
	return(routes[nrt]);
      }
      nrt++;
    }
    return(null);
  }

  static void readRoutes(TextArea err, List rl, List routeWPList, List wlist,URL epsBase, String rtfile, int filf,GMenv menv){
    int posFmt=Pone.DDD;
    URL tURL;
    BufferedReader dis;
    String inputLine;
    Route nRoute=null;
    menv.rtfile = rtfile;    
    Datum pDatum = Pos.WGS84;
    try {             
      if (epsBase !=null){
	tURL =new URL(epsBase,rtfile);
	dis = new BufferedReader(new InputStreamReader(tURL.openStream()));
      } else {
	dis = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec(rtfile+ " -dr").getInputStream()));
      }
      if (filf==Pone.ffGRM || filf==Pone.ffGPSTRANS) {	
	if (filf==Pone.ffGPSTRANS) {
	  if ((inputLine = dis.readLine())!=null) {	  
	    if (inputLine.substring(0,7).equals("Format:")) {
	      if (inputLine.substring(8,11).equals("DDD")) {
		posFmt = Pone.DDD;
	      } else {
		posFmt =Pone.MDD;
	      }
		int datumNo = Integer.parseInt(inputLine.substring(43,46));
		pDatum = Pos.getGtDatum(datumNo);
	    }
	  }
	}
	
	while ((inputLine = dis.readLine())!=null && 
	       (inputLine.length()==0 || 
		inputLine.charAt(0)!='R')){
	}
	
	while ((inputLine !=null) &&  
	       inputLine.length()>0 &&
	       inputLine.charAt(0)=='R') 
	  {	    
	    int routeNo;	
	    
	      nRoute = new Route();
	      routeNo =
		Integer.valueOf(CAux.getCol(inputLine,1,
					   (filf==Pone.ffGPSTRANS)?'\t':' ')).intValue();
	      
	      if (filf==Pone.ffGPSTRANS){
		nRoute.name = CAux.getCol(inputLine,2,(filf==Pone.ffGPSTRANS)?'\t':' ');
		nRoute.name = nRoute.name.toUpperCase();
	      } else {
		inputLine=dis.readLine();
		inputLine=dis.readLine(); // H line
		nRoute.name = "GRM Route "+routeNo;		
	      }
	      	      
	      insertRoute(err,rl,nRoute);	     
	      while ((inputLine = dis.readLine())!= null && 
		     (inputLine.length()==0||
		     (inputLine.charAt(0)=='W')) 
		     ) {
		String WPname;
		WayPoint thisWP;
		WPname = CAux.getCol(inputLine,1,(filf==Pone.ffGPSTRANS)?'\t':' ');
		WPname = WPname.toUpperCase();
		thisWP = aWP.theWP.findWP(WPname);
		
		if (thisWP == null) {
		  thisWP = aWP.theWP.readWP(err,null,inputLine, posFmt,filf,true);
		  thisWP.wpos.theDatum = pDatum;
		  try {
		    err.append("Waypoint "+ WPname+ " found in route, " +  " added to Waypoints\n");
		  } catch (NoSuchMethodError ex) {
		    CAux.perr("Waypoint "+ WPname+ " found in route, " +  " added to Waypoints",1);
		  }		  
		  aWP.theWP.flushList(wlist,false);
		  } 
		//System.out.println("new rt:nRT " +nRT + "" + nRoute.name + ": " 
		//			 + thisWP.toString(1));
		if (thisWP != null) {
		  nRoute.wpts.insertWP(err, null, thisWP, true);
		}	
	      }
	      nRoute.wpts.flushList(routeWPList,true);
	    }
	} else { //RWP
	  int pRoute=-1, rn;
	  WayPoint thisWP;
	  String WPname;
	  
	  while ((inputLine = dis.readLine())!=null){
	    rn =  Integer.valueOf(CAux.getCol(inputLine,0,' ')).intValue();
	    if (pRoute<0 || rn != pRoute){
	      nRoute= new Route();
	      nRoute.name = "Route" + rn;
	      insertRoute(err,rl,nRoute);
	      pRoute=rn;
	    }
	    WPname = CAux.getCol(inputLine,1,' ');
	    
	    thisWP = aWP.theWP.findWP(WPname);
	    if (thisWP == null) {
	      thisWP = aWP.theWP.readWP(err,null,inputLine, posFmt,filf,true);
	      try {
		err.append("Waypoint "+ WPname+ " Found in route, " + " added to Waypoints" +"\n");
	      } catch (NoSuchMethodError ex) {
		CAux.perr("Waypoint "+ WPname+ " Found in route, " + " added to Waypoints",0);
	      }
	      aWP.theWP.flushList(wlist,false);
	    } 
	    nRoute.wpts.insertWP(err,routeWPList, thisWP, false);
	  }
	}  
	dis.close();
      }
    catch (MalformedURLException me) {
      System.out.println("MalformedURLException: " + me);
    } catch (FileNotFoundException fe) {
      System.out.println("Route file not found: " + fe);
    } catch (IOException ioe) {
      System.out.println("Route Not found " + ioe);
    } catch (StringIndexOutOfBoundsException ioe) {
      System.out.println("Could not read route file " + "\""+rtfile+"\" "+ ioe);
      ioe.printStackTrace();
    } catch (NumberFormatException ioe) {
      System.out.println("Could not read route file " + ioe);
    } catch (SecurityException ioe) {
      System.out.println("Could not read route file " + ioe);
    }

   }

  static public Route findWPinRoute(WayPoint wp){
    int nrt=0;
    
    while (nrt < nRT) {
      if (routes[nrt].wpts.findWP(wp)!=null){
	return(routes[nrt]);
      }
      nrt++;
    }
    return(null);
}
  

  static public void insertRoute(TextArea err, List rl, Route ro ){
    int xi;
    int newMax = 2*maxRT;      
    Route r0[];
    MenuItem ri = new MenuItem(ro.name);

    if (findRT(ro.name)!=null){
      if (err!= null) {
	try {
	  err.append("Route \""+ro.name+ "\" already exist:"  + "\n");
	} catch (NoSuchMethodError ex) {
	  CAux.perr("Route \""+ro.name+ "\" already exist:",0);
	}
      } else {
	System.out.println("Route \""+ro.name+ "\" already exist:"  + "\n");
      }
      return;
    }
    
    if (nRT >= maxRT) {      
      r0 = routes;
      routes = new Route[newMax];      
      for (xi=0;xi<maxRT;xi++){
 	routes[xi] = r0[xi];    
 	maxRT=2*maxRT;
      }            
    }
    routes[nRT]=ro;      
    nRT = nRT+1;
    if (rl!= null) {
      rl.addItem(ro.name);
    }    
  }    

  static public void deleteAll(){
    nRT=0;
  }
  
  static public void delete(int nd){
    int nw;
    nRT--;
    for (nw=nd; nw < nRT; nw++){
      routes[nw] = routes[nw+1];
    }     
    routes[nRT]=null;    
  }
  
  static public void output(TextArea ta, int ff,int off,Datum datum, String fn, String gt) {
    String tmp_file = "/tmp/gpstrans_upl_route";
    try {
      DataOutputStream dos;
      boolean ferr = false;
      String fn1 = fn;      
      try {
	try {
	  PrivilegeManager.enablePrivilege("UniversalFileWrite" /*, fn1*/);
	} catch (ForbiddenTargetException me) {
	  CAux.perr("No FTE PM",3);
	} catch (NoClassDefFoundError me) {
	  CAux.perr("No RT PM",3);
	}
	if (gt!=null){
	  fn1 = tmp_file;
	}
	File oFile = new File(fn1);	
	dos = new DataOutputStream(new FileOutputStream(oFile));
	output(null,dos,ff,off,datum);
      }
      catch (SecurityException me) {
	System.out.println(" SecurityException: " + me);
	ferr=true;
      }
      catch (IOException me) {
	System.out.println(" File IOException RT: " + me);
	ferr=true;
      }    

      if (gt!=null){
	Process prc;
	prc = Runtime.getRuntime().exec(gt + " -ur "+tmp_file);
      } else if (ta!=null && ferr){
	ta.setText("");
	output(ta,null,ff,off,datum);
      }      
    }
    
  catch (IOException me) {
    System.out.println(" File IOException RT: " + me);
  }    
}
  
  static public void output(TextArea ta, DataOutputStream dos, int ff,int off,Datum datum) 
    throws IOException{
    int nw, nrt;
    Route tmpRoute;
    WayPoint wp;
    String Soff = ""+off;
    String Sdatum = ""+datum.gpstransNo;
    if (ff==Pone.ffGPSTRANS){
      CAux.fo(
	      "Format: DDD  UTC Offset:" + "    ".substring(0,4-Soff.length()) + Soff +
	      ".00 hrs  Datum["+ "000".substring(0,3-Sdatum.length()) + Sdatum+
	      "]:"+datum.name +"\n",dos,ta);
      for (nrt=0; nrt < nRT; nrt++){
	tmpRoute = routes[nrt];    
	CAux.fo("R" + "\t" + nrt + "\t" + tmpRoute.name + "\n",dos,ta);
	for (nw=0; nw < tmpRoute.wpts.nWP; nw++){
	  wp=tmpRoute.wpts.wayPoints[nw];
	  CAux.fo("W" + "\t" + wp.name+"\t" + CAux.localOutDefault.format(wp.timestamp) +
		  "\t"+ wp.wpos.toDatum(datum).toString(ff)+"\n",dos,ta);
	} 
      }
    } else if (ff==Pone.ffGARLINK){
      for (nrt=0; nrt < nRT; nrt++){
	tmpRoute = routes[nrt];    
	for (nw=0; nw < tmpRoute.wpts.nWP; nw++){
	  wp=tmpRoute.wpts.wayPoints[nw];
	  CAux.fo(CAux.spad(""+ nrt,-2,'0') + " " + 
		 CAux.spad(wp.name,6,' ') + " "+
		 wp.wpos.toString(ff)+
		 CAux.spad(wp.timestamp.toString(),14,' ')+" "+
		 CAux.spad(wp.name,20,' ') +
		 "\n",dos,ta);
	} 
      }
    }
    
    
    if (dos !=null){
      dos.close();    
    }
  }
}


