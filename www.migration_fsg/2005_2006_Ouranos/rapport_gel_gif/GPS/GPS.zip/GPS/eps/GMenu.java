// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>

class GMenv {

  String wpfile, rtfile, trfile, chartdir;

  URL codeBase, documentBase;

  Dimension naturalDim;

  int cw, ch;

  String ffs;

  String gtpgm;

  int UTC_off;

  int Chart_Datum;

  double initLat,initLong;

  GMenv(String W, String R, String T,  String cd, URL db, URL cbase, Dimension nd, int cw0, 

	int ch0, String ff, String gt, int off, int datum, double iLa, double iLo){

    wpfile = W;

    rtfile = R;

    trfile = T;

    chartdir = cd;

    codeBase = cbase;

    documentBase = db;

    naturalDim = nd;    

    cw=cw0;    

    ch=ch0;

    ffs=ff;        

    gtpgm=gt;

    UTC_off = off;

    Chart_Datum = datum;

    initLong = iLo;

    initLat = iLa;

  }



  public String toString() 

    {

      return("wf=" + wpfile+ " rf=" + rtfile + " tr="+trfile+ " cd ="+chartdir + 

	     "\n codeBase=" +codeBase  + "\ndocumentBase="+documentBase + "\nnd=" + 

	     naturalDim + "\nch " + ch + " cw " + cw + " ffs="+ffs+" gtpgm="+gtpgm+

	     " UTC_off="+UTC_off + " datum=" +Chart_Datum + 

	     " dlo="+initLong+" dLa="+initLat);      

    }

  

}



