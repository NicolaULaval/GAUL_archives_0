// EPS: Elgaard Positioning System: GPS navigation software.
// Copyright (C) 1997  Niels Elgaard Larsen

//     This program is free software; you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation; either version 2 of the License, or
//     (at your option) any later version.

//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.

//     You should have received a copy of the GNU General Public License
//     along with this program; if not, write to the Free Software
//     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

// Niels Elgaard Larsen, <URL:mailto:elgaard@diku.dk>
// <URL:http://www.diku.dk/users/elgaard/>

// Garmin communication code is based on Gpstrans by Carsten Tschach 
// (tschach@zedat.fu-berlin.de)


// FIXME:
// Assumes only one GPS per EPS


import java.net.*;
import java.io.*;
import java.awt.*;
import netscape.security.PrivilegeManager;
import netscape.security.ForbiddenTargetException;

class Garmincomm
{
  
/* define global variables */
  static byte gGarminMessage[] = new byte[Gpsmessage.MAX_LENGTH];

  static int NMEA_comm =48;  
  static int GRM_comm = 96;
  
  static int mode = Gpsmessage.GARMIN;
  static String portName="/dev/cua0" ;
  static Process gpsPrc;
  static int GPS_port =0;

  static String NMEA_Port_init[] = new String[3];
  static String  GRM_Port_init[] = new String[3];
  static File PortFile;  
  static RandomAccessFile epscommNMEA;
  static RandomAccessFile epscommGRM;
  //static BufferedInputStream epscommIn;
  
  static void setup() {
    if (ChartFrame1.isWin) {
      NMEA_Port_init[0] = GRM_Port_init[0]= "MODE.COM";
      NMEA_Port_init[1] = GRM_Port_init[1] = portName;        
      NMEA_Port_init[2] = " baud=4800 Parity=N XON=OFF DTR=OFF RTS=OFF Data=8";
      GRM_Port_init[2] = " baud=9600 Parity=N XON=OFF DTR=OFF RTS=OFF Data=8";
    } else {
      NMEA_Port_init[0] = GRM_Port_init[0] = "/bin/sh";
      NMEA_Port_init[1] = GRM_Port_init[1] = "-c";

      NMEA_Port_init[2] = "stty 4800 pass8 -parenb  -inlcr  ixany -ixon < " + portName;
      GRM_Port_init[2] =  "stty 9600 pass8 -parenb -echo raw -onlret < " + portName;      
      
    }
    //try {            
      PortFile = new File(portName);
      //   } catch( IOException e ) {
      //System.out.println( "Serial port init failure "+ e);
     //   }          
  }
  
  /****************************************************************************/
  /* Calculate checksum, prepare package and send to GPS.                     */
  /****************************************************************************/
  static void sendAndGetMessage(byte message[], int bytes) {
    int ml=5;
    int err;
      do {
	Garmincomm.sendGPSMessage(message, 60);
	/* make sure GPS respond */
	err=Garmincomm.getGPSMessage();   
      } while (gGarminMessage[1]==Gpsmessage.NACK && ml-- >0);
  }
  
  static void sendGPSMessage(byte message[], int bytes) {
    int         i,xi=0;
    int pi;
    
    int          nBytes;
    int          csum = 0;
    byte          pd[]   = new byte[Gpsmessage.MAX_LENGTH];  
    pd[0] = 0x10;                  /* Define start of message */
    
//     try { 
//       Thread.sleep(400L);
//     } catch( InterruptedException exp ) {
//       System.out.println( "int exp: " + exp );
//     }
    CAux.perr( "sGPS " + bytes +" bytes",4);
    System.out.flush();
    for (i = 0; i < bytes; i++) {
      xi++;    
      pd[xi]  = message[i];
      csum += Getgpsinfo.ubyte(message[i]);
      if (message[i] == 0x10){
	xi++;
	pd[xi] = 0x10;
      }    
    }
    
    xi++;
    pd[xi++] = (byte)(256-(csum%256)); /* i hate this */
    if (pd[xi-1] == 0x10) {
      pd[xi++] = 0x10;
    }
    CAux.perr( "csum "+csum + "="+(256-(csum%256)),9);
    
    pd[xi++] = 0x10;
    pd[xi++] = 0x03;
    nBytes = xi;
 
    int ii;
    CAux.perr( "sending="+nBytes,3);
    try { 
      int step = 100;
      //epscommGRM.flush();
      while (nBytes > 0) {	
	epscommGRM.write(pd,0,(nBytes>step)?step:nBytes);
	nBytes = nBytes-step;
	CAux.perr( "left="+nBytes,3);
	try {	  
	  epscommGRM.getFD().sync();
	} catch(SyncFailedException  exp ) {
	  System.out.println( "Sync failed: " + exp );
	}
	
// 	try { 
// 	  Thread.sleep(50L);
// 	} catch( InterruptedException exp ) {
// 	  System.out.println( "int exp: " + exp );
// 	}

      }
    } catch( IOException ex ) {
      System.out.println( "Failed write to port: " + ex );
      ex.printStackTrace();
      throw (new Error("Failed write to port"));
    }
    CAux.perr( "w sGPS ",4);
    System.out.flush(); 
  }


  /****************************************************************************/
  /* Sent a "are-you-ready" message to GPS - return TRUE if GPS responds or   */
  /* FALSE if GPS did not respond (GPS off? / incorrect format?)              */
  /****************************************************************************/
  static  boolean CheckGPS() {
    
    long		count = 1L;
    byte		p[] = gGarminMessage;
    byte		last  = 0;
    byte		c;
    int		err=0;
    byte theB;
    int px=0;
    
    int            igot, i;
    short          length = 0;
    
    /* Open device, FALSE if unable to open device */
    CAux.perr(" GPS CheckGPS " ,4);
    if ((err = serialOpen(Garmincomm.GRM_comm)) != 0) {
      CAux.perr( "The port initialization of ?? has failed.",4);
      serialClose();
      return false;
    }
    
    sendGPSMessage(Gpsmessage.test, 4);
    px=0;
    
    CAux.perr(" GPS check rcv: " ,7);
    while ( (px<2 || p[px-1] != 3 || p[px-2]!=0x10)) {
      if (px >= Gpsmessage.MAX_LENGTH-1) {
	CAux.perr("GPS check receiver communication protocol error.",4);
	mode = Gpsmessage.NONE;
	return (false);
      }
      try {
	theB =  epscommGRM.readByte();
	p[px] =  theB;
	//System.out.println("" + (int)theB );
      } catch (IOException  ee) {
	CAux.perr("read prb" + ee, 7);
	return(false);
      }
      
      if (px>0 && p[px] == 0x10 && p[px-1] == 0x10) {
	px--;
      } 
      px ++;
    }
    CAux.perr("Check GPSsend OK got"+  p + "  px=" +px, 6);
    serialClose();
    return(true);  
  }


  /****************************************************************************/
  /* Get respond from GPS - returns number of bytes received, 0 if timeout    */
  /* period elapsed without completing a package.                             */
  /****************************************************************************/
  static  int getGPSMessage() {
    
    CAux.perr( "get GPS* ",4);
     try { 
       Thread.sleep(50L);
     } catch( InterruptedException exp ) {
       System.out.println( "int exp: " + exp );
     }

    long          count  = 1L;
    byte          pd[]     = gGarminMessage;
    byte          last   = 0;
    byte          c;
    int px;
    short         length = 0;
    int           igot, i;

    /* exit if timeout exceeded */
    px = 0;
    while (px<2 || (pd[px-1] != 3 && pd[px-1] != 90) || pd[px-2]!=0x10) {
      if (px >= Gpsmessage.MAX_LENGTH-1) {
	CAux.perr(("GPS receiver communication protocol error. px " + px),4);
	mode = Gpsmessage.NONE;
	return 0;
      }
      try {
	epscommGRM.read(pd,px,1);
	//System.out.println("r"+px + "rd="+pd[px]);
      } catch (IOException  ee) {
	System.out.println("read" + ee);
	return(-1);
      }    
      if (px>0 && pd[px] == 0x10 && pd[px-1] == 0x10){
      px--;
      }       
      px ++;
    }
  

    CAux.perr("Receiving: ", 4);
    //  for (i = 0; i < length; i++){
    //CAux.perr((gGarminMessage + i)+"X",5);
      //}
    CAux.perr("got GPS* ",4);
    return px;
  }

  static  int serialOpen(int commType) {
    int err =0;      
    CAux.perr( "open Serial:  portName="+ 
	       portName + " commType=" + commType + " init= "+
	       GRM_Port_init[0]+ " " +GRM_Port_init[1]+" " +GRM_Port_init[2],1);
    try { 
      int ch=1;
      InputStream pIn;
      gpsPrc=Runtime.getRuntime().exec(commType==NMEA_comm?
				       NMEA_Port_init:GRM_Port_init);
      pIn = new DataInputStream(gpsPrc.getInputStream());
      while (ch>=0) { // Stupid DOS MODE
	ch = pIn.read();
      }
    } catch( IOException ex) {
      System.out.println( " exec error :"+ ex);
      ex.printStackTrace();
      } catch( SecurityException ex) {
	System.out.println( " security exec error :"+ ex);
	ex.printStackTrace();
      }
      try {
	try {
	  PrivilegeManager.enablePrivilege("UniversalFileAccess");
	} catch (ForbiddenTargetException me) {
	  CAux.perr("No COMM PM",3);
	  //me.printStackTrace();
	} catch (NoClassDefFoundError me) {
	  CAux.perr("No COMM PM -- NCDFE",3);
	  //me.printStackTrace();
	}
	if (commType == GRM_comm) {
	  FileDescriptor theFD;
	  epscommGRM = new RandomAccessFile(PortFile, "rw");
	  //theFD = epscommGRM.getFD();
	  //epscommIn = new BufferedInputStream(new FileInputStream(theFD));
	  CAux.perr("Get fd for "+portName,3);
	} else {
	  epscommNMEA = new RandomAccessFile(PortFile, "r");
	    //new BufferedReader((new FileReader(portName)),10);
	}
      } catch( IOException ex ) {
	System.out.println( "SERIAL port Failure "+ ex + "\n  portFile=\""+PortFile+"\"" );
	ex.printStackTrace();
      } catch( SecurityException ex) {
	System.out.println( " rd error :"+ ex + "URL=");
      }          
      return (err);      
  }

  static int serialClose() {
    // close the port neat and clean after releasing objects
    CAux.perr(" GPS serialClose: ",2);

    try {
      if (epscommGRM != null){
	epscommGRM.close();
	epscommGRM=null;
      }
    }  
    catch( IOException e ) {
      System.out.println( "Failed write to I port: " + e );
      throw (new Error("Failed write to port"));
    }
  
    try {
      if (epscommNMEA != null){
	epscommNMEA.close();
	epscommNMEA=null;
      }
    }
    catch( IOException e ) {
      System.out.println( "Failed write to NMEA port: " + e );
      throw (new Error("Failed write to port"));
    }  
    return(0);
  }
}
